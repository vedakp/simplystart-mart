(function () {
  function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

  function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

  function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab3-tab3-module"], {
    /***/
    "8ZFP":
    /*!**************************************************!*\
      !*** ./src/app/home/tab3/tab3-routing.module.ts ***!
      \**************************************************/

    /*! exports provided: Tab3PageRoutingModule */

    /***/
    function ZFP(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Tab3PageRoutingModule", function () {
        return Tab3PageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _tab3_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./tab3.page */
      "Vrg+");

      var routes = [{
        path: '',
        component: _tab3_page__WEBPACK_IMPORTED_MODULE_3__["Tab3Page"]
      }];

      var Tab3PageRoutingModule = function Tab3PageRoutingModule() {
        _classCallCheck(this, Tab3PageRoutingModule);
      };

      Tab3PageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], Tab3PageRoutingModule);
      /***/
    },

    /***/
    "J2kc":
    /*!********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/tab3/tab3.page.html ***!
      \********************************************************************************/

    /*! exports provided: default */

    /***/
    function J2kc(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\r\n  <ion-item>\r\n    <ion-label class=\"ion-padding\">\r\n      <h1>{{ 'My Cart' | translate }}</h1>\r\n    </ion-label>\r\n    <ion-icon \r\n      class=\"ion-text-right\"\r\n      slot=\"end\"\r\n      color=\"dark\"\r\n      name=\"bag-handle-outline\"\r\n    >\r\n    </ion-icon>\r\n  </ion-item>\r\n</ion-header>\r\n\r\n<ion-content [fullscreen]=\"true\" scroll=\"false\" no-padding>\r\n\r\n  <div class=\"cart ion-padding-top\" *ngIf=\"cart.length > 0\">\r\n    <ion-list>\r\n      <ion-item *ngFor=\"let item of cart; let i=index;\">\r\n        <ion-grid class=\"animate__animated animate__slideInUp animate__faster\">\r\n          <ion-row>\r\n            <ion-col size=\"3\">\r\n              <img class=\"round-edge\" src=\"{{ item?.productImage }}\" />\r\n              <small class=\"ion-text-uppercase text-muted\">\r\n                Qty: {{ item?.quantity }}</small\r\n              >\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n              <h6\r\n                class=\"text-oflow-lg no-gap\"\r\n                routerLink=\"/single-product-view\"\r\n              >\r\n                {{ item?.shortName }}\r\n              </h6>\r\n              <p class=\"text-oflow-lg text-muted no-gap\">{{ item?.brand }}</p>\r\n\r\n              <ion-row class=\"ion-margin-top\">\r\n                <ion-icon\r\n                  (click)=\"lessQty(i)\"\r\n                  size=\"small\"\r\n                  name=\"remove-circle-outline\"\r\n                ></ion-icon>\r\n                <span class=\"qty-padding\">{{ item?.quantity }}</span>\r\n                <ion-icon\r\n                  (click)=\"addQty(i)\"\r\n                  size=\"small\"\r\n                  name=\"add-circle-outline\"\r\n                ></ion-icon>\r\n              </ion-row>\r\n            </ion-col>\r\n            <ion-col size=\"3\" class=\"ion-text-right\">\r\n              <ion-icon\r\n                class=\"ion-text-right text-muted ion-margin-bottom\"\r\n                (click)=\"removeFromCart(i)\"\r\n                name=\"trash-outline\"\r\n              ></ion-icon>\r\n              <p\r\n                class=\"ion-text-uppercase no-gap x-small ion-margin-top text-muted\"\r\n              >\r\n                {{ item?.salesPrice }} X {{ item?.quantity }}\r\n              </p>\r\n              <h6 class=\"ion-text-right no-gap\">\r\n                ₹ {{ item?.salesPrice*item?.quantity }}\r\n              </h6>\r\n            </ion-col>\r\n          </ion-row>\r\n        </ion-grid>\r\n      </ion-item>\r\n    </ion-list>\r\n\r\n    <div class=\"bottom-bar animate__animated animate__fadeIn animate__faster\">\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col size=\"6\">\r\n            <small class=\"text-muted ion-text-uppercase no-gap\">{{ 'Subtotal' | translate }}</small>\r\n            <ion-text color=\"dark\"\r\n              ><h1 class=\"no-gap\">₹ {{ totalCost }}</h1></ion-text\r\n            >\r\n          </ion-col>\r\n\r\n          <ion-col size=\"6\">\r\n            <ion-button\r\n              color=\"primary\"\r\n              routerLink=\"/checkout\"\r\n              class=\"ion-text-uppercase\"\r\n              size=\"large\"\r\n              expand=\"block\"\r\n              >{{ 'Checkout' | translate }}</ion-button\r\n            >\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </div>\r\n  </div>\r\n\r\n  <div\r\n    class=\"empty-cart animate__animated animate__fadeIn animate__faster\"\r\n    *ngIf=\"cart.length == 0\"\r\n  >\r\n    <img src=\"../../../assets/empty-cart.svg\" alt=\"\" />\r\n    <h4 class=\"text-muted ion-text-center\">{{ 'Cart is empty' | translate }}!</h4>\r\n    <br />\r\n    <div class=\"ion-text-center\">\r\n      <ion-button\r\n        color=\"primary\"\r\n        routerLink=\"/home\"\r\n        class=\"ion-text-uppercase\"\r\n        shape=\"round\"\r\n        >{{ 'Start Shopping' | translate }}</ion-button\r\n      >\r\n    </div>\r\n  </div>\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "UdU2":
    /*!******************************************!*\
      !*** ./src/app/home/tab3/tab3.module.ts ***!
      \******************************************/

    /*! exports provided: Tab3PageModule */

    /***/
    function UdU2(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Tab3PageModule", function () {
        return Tab3PageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _tab3_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./tab3.page */
      "Vrg+");
      /* harmony import */


      var _tab3_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./tab3-routing.module */
      "8ZFP");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @ngx-translate/core */
      "sYmb");

      var Tab3PageModule = function Tab3PageModule() {
        _classCallCheck(this, Tab3PageModule);
      };

      Tab3PageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        imports: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([{
          path: '',
          component: _tab3_page__WEBPACK_IMPORTED_MODULE_6__["Tab3Page"]
        }]), _tab3_routing_module__WEBPACK_IMPORTED_MODULE_7__["Tab3PageRoutingModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateModule"]],
        declarations: [_tab3_page__WEBPACK_IMPORTED_MODULE_6__["Tab3Page"]]
      })], Tab3PageModule);
      /***/
    },

    /***/
    "Vrg+":
    /*!****************************************!*\
      !*** ./src/app/home/tab3/tab3.page.ts ***!
      \****************************************/

    /*! exports provided: Tab3Page */

    /***/
    function Vrg(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Tab3Page", function () {
        return Tab3Page;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_tab3_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./tab3.page.html */
      "J2kc");
      /* harmony import */


      var _tab3_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./tab3.page.scss */
      "tlVI");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");

      var Tab3Page = /*#__PURE__*/function () {
        function Tab3Page(toastController, alertController) {
          _classCallCheck(this, Tab3Page);

          this.toastController = toastController;
          this.alertController = alertController;
          this.totalCost = 0;
          this.cart = [{
            "product_id": 1,
            "productImage": "../../../assets/products/39ed8e8d-01b0-4d86-8cb0-305b4869bb48.__CR288,248,496,496_PT0_SX300_V1___.jpg",
            "productName": "WF Fashion",
            "brand": "Bagger IN",
            "shortName": "Women's Handbag",
            "off": 15,
            "quantity": 1,
            "productLongDescription": "A14 Bionic, the fastest chip in a smartphone. An edge-to-edge OLED display. Ceramic Shield with four times better drop performance. And Night mode on every camera. iPhone 12 has it all — in two perfect sizes.",
            "productShortDescription": "A14 Bionic, the fastest chip in a smartphone. An edge-to-edge OLED display.",
            "regularPrice": 980,
            "salesPrice": 850
          }, {
            "product_id": 2,
            "productImage": "../../../assets/products/b5b4e08c1b97e8ed0c403bebda20d789.jpg",
            "productName": "Halife Women's Long Sleeve Boat Neck Off Shoulder Blouse Tops",
            "brand": "Halife US",
            "off": 45,
            "quantity": 2,
            "shortName": "Women's Long Sleeve",
            "productLongDescription": "A14 Bionic rockets past every other smartphone chip. The Pro camera system takes low-light photography to the next level — with an even bigger jump on iPhone 12 Pro Max. And Ceramic Shield delivers four times better drop performance. Let’s see what this thing can do.",
            "productShortDescription": "A14 Bionic rockets past every other smartphone chip.",
            "regularPrice": 1200,
            "salesPrice": 999
          }];
        }

        _createClass(Tab3Page, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.doTotalCalculation();
          }
        }, {
          key: "lessQty",
          value: function lessQty(index) {
            if (this.cart[index].quantity > 0) {
              this.cart[index].quantity = this.cart[index].quantity - 1;
              this.doTotalCalculation();
            }

            if (this.cart[index].quantity == 0) {
              this.removeFromCart(index);
            }
          }
        }, {
          key: "addQty",
          value: function addQty(index) {
            if (this.cart[index].quantity >= 0 && this.cart[index].quantity <= 25) {
              this.cart[index].quantity = this.cart[index].quantity + 1;
            }

            this.doTotalCalculation();
          }
        }, {
          key: "doTotalCalculation",
          value: function doTotalCalculation() {
            this.totalCost = 0;

            var _iterator = _createForOfIteratorHelper(this.cart),
                _step;

            try {
              for (_iterator.s(); !(_step = _iterator.n()).done;) {
                var item = _step.value;
                this.totalCost += item.salesPrice * item.quantity;
              }
            } catch (err) {
              _iterator.e(err);
            } finally {
              _iterator.f();
            }
          }
        }, {
          key: "removeFromCart",
          value: function removeFromCart(i) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.alertController.create({
                        header: 'Do you want to remove this item from your cart?',
                        buttons: [{
                          text: 'Cancel',
                          role: 'cancel',
                          cssClass: 'secondary',
                          handler: function handler() {
                            console.log('Action cancelled');
                          }
                        }, {
                          text: 'Yes!',
                          handler: function handler() {
                            _this.toastAlert("Item removed from cart.", i);
                          }
                        }]
                      });

                    case 2:
                      alert = _context.sent;
                      _context.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "toastAlert",
          value: function toastAlert(msg, index) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var toast;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.toastController.create({
                        message: msg,
                        duration: 2000
                      });

                    case 2:
                      toast = _context2.sent;
                      toast.present();
                      this.cart.splice(index, 1);
                      this.doTotalCalculation();

                    case 6:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }]);

        return Tab3Page;
      }();

      Tab3Page.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]
        }];
      };

      Tab3Page = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-tab3',
        template: _raw_loader_tab3_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_tab3_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], Tab3Page);
      /***/
    },

    /***/
    "tlVI":
    /*!******************************************!*\
      !*** ./src/app/home/tab3/tab3.page.scss ***!
      \******************************************/

    /*! exports provided: default */

    /***/
    function tlVI(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".empty-cart img {\n  display: block;\n  margin: 0 auto;\n  margin-top: 45%;\n}\n\n.qty-padding {\n  padding: 0px 12px 0px 12px !important;\n}\n\n.text-muted {\n  color: #6c757d !important;\n}\n\n.x-small {\n  font-size: x-small !important;\n}\n\n.no-gap {\n  padding: 0 !important;\n  margin: 0 !important;\n}\n\n.text-oflow-lg {\n  display: inline-block;\n}\n\n.round-edge {\n  border-radius: 8px !important;\n  overflow: hidden;\n  box-shadow: 0px 1px 9px rgba(0, 0, 0, 0.15) !important;\n}\n\nion-icon {\n  font-size: 24px;\n}\n\n.bottom-bar {\n  position: fixed;\n  width: 100%;\n  bottom: 0;\n  background-color: #ffffff;\n  z-index: 999;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3RhYjMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsY0FBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBRUE7RUFDRSxxQ0FBQTtBQUNGOztBQUVBO0VBQ0UseUJBQUE7QUFDRjs7QUFFQTtFQUNFLDZCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxxQkFBQTtFQUNBLG9CQUFBO0FBQ0Y7O0FBRUE7RUFDRSxxQkFBQTtBQUNGOztBQUVBO0VBQ0UsNkJBQUE7RUFDQSxnQkFBQTtFQUNBLHNEQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7QUFDRiIsImZpbGUiOiJ0YWIzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5lbXB0eS1jYXJ0IGltZyB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgbWFyZ2luOiAwIGF1dG87XHJcbiAgbWFyZ2luLXRvcDogNDUlO1xyXG59XHJcblxyXG4ucXR5LXBhZGRpbmcge1xyXG4gIHBhZGRpbmc6IDBweCAxMnB4IDBweCAxMnB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi50ZXh0LW11dGVkIHtcclxuICBjb2xvcjogIzZjNzU3ZCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ueC1zbWFsbCB7XHJcbiAgZm9udC1zaXplOiB4LXNtYWxsICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5uby1nYXAge1xyXG4gIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcclxuICBtYXJnaW46IDAgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnRleHQtb2Zsb3ctbGcge1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxufVxyXG5cclxuLnJvdW5kLWVkZ2Uge1xyXG4gIGJvcmRlci1yYWRpdXM6IDhweCAhaW1wb3J0YW50O1xyXG4gIG92ZXJmbG93OiBoaWRkZW47ICAgIFxyXG4gIGJveC1zaGFkb3c6IDBweCAxcHggOXB4IHJnYmEoMCwgMCwgMCwgMC4xNSkgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWljb24ge1xyXG4gIGZvbnQtc2l6ZTogMjRweDtcclxufVxyXG5cclxuLmJvdHRvbS1iYXIge1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICB3aWR0aDogMTAwJTtcclxuICBib3R0b206IDA7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcclxuICB6LWluZGV4OiA5OTk7XHJcbn1cclxuIl19 */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=tab3-tab3-module-es5.js.map