(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["my-orders-my-orders-module"],{

/***/ "XuBv":
/*!***********************************************!*\
  !*** ./src/app/my-orders/my-orders.page.scss ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJteS1vcmRlcnMucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "it3G":
/*!*******************************************************!*\
  !*** ./src/app/my-orders/my-orders-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: MyOrdersPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyOrdersPageRoutingModule", function() { return MyOrdersPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _my_orders_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./my-orders.page */ "zjv7");




const routes = [
    {
        path: '',
        component: _my_orders_page__WEBPACK_IMPORTED_MODULE_3__["MyOrdersPage"]
    }
];
let MyOrdersPageRoutingModule = class MyOrdersPageRoutingModule {
};
MyOrdersPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MyOrdersPageRoutingModule);



/***/ }),

/***/ "xdvt":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/my-orders/my-orders.page.html ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>{{ 'My Orders' | translate }}</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-list>\r\n    <ion-item\r\n      routerLink=\"/track-order\"\r\n      class=\"animate__animated animate__slideInUp animate__faster\"\r\n    >\r\n      <ion-avatar slot=\"start\">\r\n        <img src=\"../../../assets/products/410wL1a4LML._SY300_QL70_ML2_.jpg\" />\r\n      </ion-avatar>\r\n      <ion-label>\r\n        <h2>Titan Mens Watch</h2>\r\n        <h3>Ordered on 22/10/2020 12:55 PM</h3>\r\n        <ion-text color=\"danger\"><p>Cancelled</p></ion-text>\r\n      </ion-label>\r\n    </ion-item>\r\n\r\n    <ion-item\r\n      routerLink=\"/track-order\"\r\n      class=\"animate__animated animate__slideInUp animate__faster\"\r\n    >\r\n      <ion-avatar slot=\"start\">\r\n        <img src=\"../../../assets/products/item_2.png\" />\r\n      </ion-avatar>\r\n      <ion-label>\r\n        <h2>Women's Top</h2>\r\n        <h3>Ordered on 29/10/2020 01:55 PM</h3>\r\n        <ion-text color=\"warning\"><p>Order Placed</p></ion-text>\r\n      </ion-label>\r\n    </ion-item>\r\n\r\n    <ion-item\r\n      routerLink=\"/track-order\"\r\n      class=\"animate__animated animate__slideInUp animate__faster\"\r\n    >\r\n      <ion-avatar slot=\"start\">\r\n        <img src=\"../../../assets/products/item_3.png\" />\r\n      </ion-avatar>\r\n      <ion-label>\r\n        <h2>Women's Fashion</h2>\r\n        <h3>Ordered on 10/09/2020 12:55 PM</h3>\r\n        <ion-text color=\"warning\"><p>Order Placed</p></ion-text>\r\n      </ion-label>\r\n    </ion-item>\r\n\r\n    <ion-item\r\n      routerLink=\"/track-order\"\r\n      class=\"animate__animated animate__slideInUp animate__faster\"\r\n    >\r\n      <ion-avatar slot=\"start\">\r\n        <img src=\"../../../assets/products/item_4.png\" />\r\n      </ion-avatar>\r\n      <ion-label>\r\n        <h2>Women's Skirt</h2>\r\n        <h3>Ordered on 01/02/2020 01:55 PM</h3>\r\n        <ion-text color=\"warning\"><p>Order Placed</p></ion-text>\r\n      </ion-label>\r\n    </ion-item>\r\n\r\n    <ion-item\r\n      routerLink=\"/track-order\"\r\n      class=\"animate__animated animate__slideInUp animate__faster\"\r\n    >\r\n      <ion-avatar slot=\"start\">\r\n        <img src=\"../../../assets/products/item_5.png\" />\r\n      </ion-avatar>\r\n      <ion-label>\r\n        <h2>Women's Stylish Dress</h2>\r\n        <h3>Ordered on 25/01/2020 01:51 PM</h3>\r\n        <ion-text color=\"warning\"><p>Order Placed</p></ion-text>\r\n      </ion-label>\r\n    </ion-item>\r\n  </ion-list>\r\n</ion-content>\r\n");

/***/ }),

/***/ "ybVn":
/*!***********************************************!*\
  !*** ./src/app/my-orders/my-orders.module.ts ***!
  \***********************************************/
/*! exports provided: MyOrdersPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyOrdersPageModule", function() { return MyOrdersPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _my_orders_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./my-orders-routing.module */ "it3G");
/* harmony import */ var _my_orders_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./my-orders.page */ "zjv7");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");








let MyOrdersPageModule = class MyOrdersPageModule {
};
MyOrdersPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _my_orders_routing_module__WEBPACK_IMPORTED_MODULE_5__["MyOrdersPageRoutingModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"]
        ],
        declarations: [_my_orders_page__WEBPACK_IMPORTED_MODULE_6__["MyOrdersPage"]]
    })
], MyOrdersPageModule);



/***/ }),

/***/ "zjv7":
/*!*********************************************!*\
  !*** ./src/app/my-orders/my-orders.page.ts ***!
  \*********************************************/
/*! exports provided: MyOrdersPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyOrdersPage", function() { return MyOrdersPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_my_orders_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./my-orders.page.html */ "xdvt");
/* harmony import */ var _my_orders_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./my-orders.page.scss */ "XuBv");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let MyOrdersPage = class MyOrdersPage {
    constructor() { }
    ngOnInit() {
    }
};
MyOrdersPage.ctorParameters = () => [];
MyOrdersPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-my-orders',
        template: _raw_loader_my_orders_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_my_orders_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], MyOrdersPage);



/***/ })

}]);
//# sourceMappingURL=my-orders-my-orders-module-es2015.js.map