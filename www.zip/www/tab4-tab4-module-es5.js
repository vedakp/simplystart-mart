(function () {
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab4-tab4-module"], {
    /***/
    "3IKK":
    /*!****************************************!*\
      !*** ./src/app/home/tab4/tab4.page.ts ***!
      \****************************************/

    /*! exports provided: Tab4Page */

    /***/
    function IKK(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Tab4Page", function () {
        return Tab4Page;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_tab4_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./tab4.page.html */
      "AAM5");
      /* harmony import */


      var _tab4_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./tab4.page.scss */
      "LYsn");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _translate_config_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../translate-config.service */
      "ZjVV");

      var Tab4Page = /*#__PURE__*/function () {
        function Tab4Page(translateConfigService, actionSheetController) {
          _classCallCheck(this, Tab4Page);

          this.translateConfigService = translateConfigService;
          this.actionSheetController = actionSheetController;
          this.selectedLanguage = this.translateConfigService.getDefaultLanguage();
        }

        _createClass(Tab4Page, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            if (!localStorage.getItem('appLanguage')) {
              localStorage.setItem('appLanguage', "en");
              this.selectedLanguage = "en";
            } else {
              this.selectedLanguage = localStorage.getItem('appLanguage');
            }

            this.translateConfigService.setLanguage(this.selectedLanguage);
          }
        }, {
          key: "updateLanguage",
          value: function updateLanguage(lang) {
            localStorage.setItem("appLanguage", lang);
            this.selectedLanguage = lang;
            this.translateConfigService.setLanguage(this.selectedLanguage);
          }
        }, {
          key: "changeLanguage",
          value: function changeLanguage() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this = this;

              var actionSheet;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.actionSheetController.create({
                        header: "Choose your primary address",
                        buttons: [{
                          text: "English",
                          handler: function handler() {
                            _this.updateLanguage("en");
                          }
                        }, {
                          text: "தமிழ்",
                          handler: function handler() {
                            _this.updateLanguage("ta");
                          }
                        }, {
                          text: "हिंदी",
                          handler: function handler() {
                            _this.updateLanguage("hi");
                          }
                        }, {
                          text: "عربى",
                          handler: function handler() {
                            _this.updateLanguage("ar");
                          }
                        }, {
                          text: "Spanish",
                          handler: function handler() {
                            _this.updateLanguage("es");
                          }
                        }, {
                          text: "Portuguese",
                          handler: function handler() {
                            _this.updateLanguage("pg");
                          }
                        }, {
                          text: "Indonesian",
                          handler: function handler() {
                            _this.updateLanguage("id");
                          }
                        }, {
                          text: "Urdu",
                          handler: function handler() {
                            _this.updateLanguage("ur");
                          }
                        }, {
                          text: "Cancel",
                          icon: "close",
                          role: "cancel",
                          handler: function handler() {
                            console.log("Cancelled");
                          }
                        }]
                      });

                    case 2:
                      actionSheet = _context.sent;
                      _context.next = 5;
                      return actionSheet.present();

                    case 5:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }]);

        return Tab4Page;
      }();

      Tab4Page.ctorParameters = function () {
        return [{
          type: _translate_config_service__WEBPACK_IMPORTED_MODULE_5__["TranslateConfigService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ActionSheetController"]
        }];
      };

      Tab4Page = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-tab4",
        template: _raw_loader_tab4_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_tab4_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], Tab4Page);
      /***/
    },

    /***/
    "AAM5":
    /*!********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/tab4/tab4.page.html ***!
      \********************************************************************************/

    /*! exports provided: default */

    /***/
    function AAM5(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-content [fullscreen]=\"true\">\r\n  <div class=\"account-img animate__animated animate__fadeInDown animate__faster\">\r\n    <img\r\n      src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAA9lBMVEXKKT7lEC319fXVGT7nDS319vb2+fnJKj7KJTv////HAynJIjn4///UGT/IEi/3+/vJHDXmvcDhpqvHACPOIz7RXWnt1tjMO0zPTlzenqTjs7fv3t/JIznYfobgFjHz7+/NP0/iwMbVbnjTIjncGjPDK0Hx5ufWdX/dlp3UanTbFTnarLPbs7rYgIjQU2HaiZHrz9KzMUa6TV+9X3HDeojJjZncmafOeYbOZ3fHRVrIT2HTiZjZoKzMW2y2KT7UsrfOgJO+anfLnKTDgYu7VWTJUmjgqrXTbobJPVrLcILuzNW7HjfSo67Kkp+8cHy7QVPFAAzEAAL2/0BIAAANIElEQVR4nO2dC1viOBfHS7FNQmtTUClStDDa4l10VMDrzjjjrqMz7vv9v8x7UlAReoWwNH3877OKWEp+nEtOTjNVkjIktL1UiNZSei0a6oPQVt4JJRwDKD6htJl3QrSde8KYQJwCMGOEcYGYA0IUHYh5IIx20xwQSjj3hNFumgvCSDfNA6Ek5d2G0dV3Lggjp8R8EEYZMR+EvI24aJwAcTbionGCFGHEnBCivVAj5oQwYk7MC2F4YZMXwvBkkxvC0GSTH8IwP80PYaif5ocQFoqBiDkiDAnFPBEiLe+EIdkmT4TBiLkiDETMF2EQYs4IeSAuGiFOaCvvhJOTRu4IJYTHqpvcEYI+1qh5JPwYjHkkHPPUPBL6ZlzKNyGYcXs6xEUPPIXQ1qur5pVQQm+MeSUcMi7lmZAx4u00gJt7ix7xFELS1mYyyM294nJx0cOdSggV9+IgCwxvuVgUkxAExgmnLGxu7xXZEUWBCVfZ4BnD3t7m5jC7wrdNYGNwQ7r/ihBjjEBY0jC/k74RLI+pOCZ+bxkiLLknp1/Pzi8uzrq9PsINTuddHScJE6f3CxNGJ939qicTQlVCHPuge+lysuSEsRZBiNHlRcfRqaooigz/qVQnzsHVpWs2OFAunhDjl2uPUkX+IGbK1tWNC8E54/kT+ikXlkBh98wm43xMikKI9+uq15wVMpmfcsKZFL69I2QS75WSEqdzcWNpMwXlQgmxe0cC7PcBkjrV9Z6Fp4/JRH7Kk2pE2KrHAL5asnrd609rSZQEkTPZUNjdD/fQcUi5+tBrTlkNJAhF3mwDaX8lBPQhIV69h8c+0qaoBhZEqP1w1OSEDFIlsr3/2E9vSbwQQux2wIROKkYGqdqtbt9F6d4sNhTnQah1mY+mJPQhKSHf3HRvFptt5kHoVmlquqFU+TStn8YhzgFQ66rxE0WISGuKnBqNyB8QP7VSJNJxE/a0Kd4yEpE7oIRfvHSJ9F0K2U+ZZwaKdFTefJLU6IZVM7G5h1T7/IsbznggnLScmRB1HqfxUaYIRK5wTNhtTZlJVXI1w0IjFJEf2lC4bwcRQmlGAleL7xaU72daLoZVN7zA3qTdBFVsKul8v7+2HUKUYEqFOGezNnCCy3A+WCPCp84kA3Ue+k8Iub3rjkxpwCdASac3excu0FM5MH1U49SbIFTk+8G6QdPcm/OWR8iHmoC1bu4tHh24IEQOp/2oRm/SS8nB0+v4Mdbcy7OWRwlVFVXxS1HSuX+ZuS811KSn8jnviLQbe5xQoQ99rfHuhA2MLrsPtufBmsmxW7+/NSV+zfAJM3I786twbbLuVtji73K0gdjQJPfkpvfj9KXvztaNGhcaNyPHcw+EmwHzoUJ14h1c9S3tve2EcQPYZm+bTmhs9ud9elg7PQTWNIoKkK2rn67Eo98do9W5EuIzOWxiZ0mzc96zuDT1o7U8T8KotQWzJK0+9PrztiTCy/MjvI1ZH6pUl+2Hbh9xzTATQnh1ToQSvgp106EhWeaRvYe//5mvJZEfj3M4MX6pxq+fFIVSsOTfrjlfb11dnsdZ0XmCjv7AXUnr0Z1/auUufNtJugiGRdWv0/9g+uCtxlc58SpY1Z37J+EQMb4iybtRlDw0xUNE18lCcWBG0roVD/FpPwWiQu4EdFSrnsJRFfIsIOLTuZy8rajK36ZtJC5OuPHNJolTKrVPhDMiLPdvL7zEjCL6KZjR7F97arJ4VOWvAhLC3I+a9y2HdZ3ijfhbSEKwI2sgdlgrOI7QfhEUEVIOdm/uGWR0TJI/ohIyNTT35f4gGpJ8F3GZMSJw1373wKYkJCYV2hFxwvgojNHln31PJnrQ9RnV+SEaIWuISsiVzNEuqYZOvn2HoAxoqspiBSLG7suP7u/n54eH86ub0X1rAOn2LjqT17zJ+SIHnFJYsh6vAYJdF9VhpqjuPzZHNnjjhvFz8iIcOZ9qn8JChK3HjsyuoQ0pVELk6n73fat+Q1qfrHQEIkS9X/J4ymTbLNm+NcSuVZjWRUCuId8FKU2xe+7oQbUou1joHXT7Vv9rK6hYJdeLHnoyYes5Yl6nhDhVO3jlSM54/XOTuYo19SNLUAX8NXi1Qb6JQIifnlM0aD6ip9+XuAg1/qRoz4yZ0Bah49Z4cabeW0runhY9/Hhhd/qdlwr5I0AzSvsac2EtQqongJPip7upTQgVjQgm/JGiRTom6onQxMCnd54a35EJNuF3AUwIcl/O7qpKot7aGGBHgCj0hbWnkx+wbqKBlWmoYH0vhgl9Yazd9q5anp5i7if1+W7M4C7WQLz868CLayAORUmLy+bL/1gNze2fd8b3kgYCyvei9hGx5v68atlq5AZvhXhdAfcqvAo3JNYl9eRQSPDQG3H5BmKt4K/PVXbTgQn7waKfz/7nRQs3zNvT545D9NfmlAIrYSgO7N8vHPcHL1aY7WK/bzF/BWOy3d2y3bq/RCIs6xMLa9jqdy/2O6DW/u+zXjNffL6gGsCue9KvWUjiu787U8Lz2N39qU996lOf+tSnPvWpT33qU5+aTUiYXTrTanMr74yFpakZsWkYhun3Itijt6c1LXWHl70eY2NE7FnNf4NZ2wHsHryb2jSIJmpXyuWdXWRK5k65XLcGTxtlXdfX0g3LPCyXy7Wj8ohYH2dtvVyubFjGbIyDu7hv49SMxoanU1WlurduAhV1hp1do67K6lG6QRkVXdXXdnX1VZRaZq3Kzq/qcnm2f9o2vBd/YSslorlBFYXqMAhaNYyyqrwRTmFDo0Jl/WhXp5T6nXAQajpUhvPrqiLXOBAyM0qpGLGnKE7bsg6retscEpp+zCDLsqTXdtrgG9bMYTixnwfHYfM9wnzCtVq9XocHileBB2YZANeb7m5ZLxuBI0hLmNKMeA0+6vUVDZsrXzSJEXoIbbSb5oCQ/c+umGH4bpkmWmO/gp9d9mOz3UbwXHuDHT1CyPLKv7qsVlfgQQk+weq/JtZKzZQuH0oIjHvJEfGaoijecQ1DMpUGhOsK+Oy6aVbAtY48XXdMAITHO7sdWQd/61iYebCzDo/l3UOZHW2MErLr3CuMkIEDoaxUjlDJnLVx/OFv1Gwnfx32VLCibJfbpm9D2b95kKIfGetUVpvH4GPgvRWqOGaLxZcq02rJqFN2HIzdUXR29DDCAgj9Q1XqdXaQGTmQVIQwbyTOqeauwkYKWcGuaYxQtQ/hK10vMcIa8hS1VTI8hVZKa3L5uA0ZVm+WYNhq9dBmiMfs6B0zjBBbtq74t5lwDjnF4TAYkyNaFYeybSWqg0pllvEMpMu0vuITlpj1mm34EJrYwGs76xUg/AKEcNzKIRj4eMUCwroRRgiZ6Nimvr3BGfgRgpLO/lCClGrHLVmR6eEKi0PIpTC88oDQbMLIjjsqLRsGCzwIPZluMEKnCRMN0JpNR4kiBMSS1a5DOKqzJdMJwoSIGIAwZNI22GNnZTBbaO+EmJnVcxRlzWzqilr+cqimJMRNAzJ1CYGjdjgTJkMsle3jWmkFVVhKKU0SNo50MC8MTvsCvvvlf/BsKkKz7VTWtBVjQ37zZX6ESWIR1yDRyY4jQ4rxXmuaUUKpVGX5tW3iJjiozDbWpiIsVSEGHcdRIZmtzbRfKoiwED8DabueSgcVpM3mOar6hAoFQvgKhGYbvNMrsbwP9Sa1YW44BEIVCA91hRHCZ/ROqLwSKnTgpVVI0/4byG2eufR10oh/nWbsVlq2bdc3oPQ3K7ZdtTD2bK9S2vFsm81zuGN7h/7Udtzx6jXb9tqlimdXm2Ybjts1raoNRbt/MhNe4/mlSwleXPafLNV26nD+Mt/58A1xO0EowuqtVCoZ/vub8AgGCF/N18fDn4a/NTT4SRv+bvAYv/1een8Ne9HQZHh4fg7rwyDEtEuNDCuYMPm0mH2FESYIRUEURpgoFIVQGGF+QjGUsFDIPWFe/DTChglKGxEUAZgTI0bZsLC1mq4Bl0lFAS5tLheLq6L7aqQNC4MbZK4uepAzKRJwaXt4F9Blgd012oaF97vVCssYDfhmRN+QYjLG2LDw4d7Rc7kZ6LwVA7i09/Hu2ALaMY5we/w+7sIl1jgvLRQntCqWGeMAx91UvHCMJZxwU9FcNdZLNwMAhTJjLGFAIIoVjbGAQYEoFGK8DQMDUSBPjScMDkRfix58IsUThgWiKJ4aD7gUQSgCYgLCsFQjCGISwsi/SZt5xASEoclUDMR4wsJmzN8VzjgiB8KMIyYgLMT+behMF+JcCItZ7qnyIcxydZMAcCkBYYYReRFmN9vwIsxutklAmCQOi9nNNvwIs7pc5EeY1VBMABhb02TbT3kSZnPKiAeMW1tk3U8TEEavDzNvxCSEiQEzmU8TECYHzOS8H08Y1WsTwU/jASP6pUIYMZ4weSr1lbl0Gh+GKRJNJo3IOQyL2YtEzmGYQSPGOmnKMMzenMg7DLNnRO5hmDkjcnfSYtZyDX8nzZqbxjnpFCbMlhH/D7DgWg0A3AKcAAAAAElFTkSuQmCC\"\r\n      alt=\"\"\r\n    />\r\n    <ion-text class=\"ion-text-center\">\r\n      <h3>Karthikeyan</h3>\r\n      <p class=\"text-muted small no-gap ion-text-center\">+91 9159000000</p>\r\n      <p class=\"text-muted small no-gap ion-text-center\">\r\n        support@shivamits.com\r\n      </p>\r\n    </ion-text>\r\n  </div>\r\n\r\n  <ion-list class=\"ion-padding-top\">\r\n    <ion-item\r\n      routerLink=\"/my-orders\"\r\n      class=\"animate__animated animate__slideInUp animate__faster\"\r\n    >\r\n      <ion-icon slot=\"start\" name=\"receipt-outline\"></ion-icon>\r\n      <ion-label>{{ 'My Orders' | translate }}</ion-label>\r\n    </ion-item>\r\n\r\n    <ion-item\r\n      routerLink=\"/my-addresses\"\r\n      class=\"animate__animated animate__slideInUp animate__faster\"\r\n    >\r\n      <ion-icon slot=\"start\" name=\"map-outline\"></ion-icon>\r\n      <ion-label>{{ 'My Addresses' | translate }}</ion-label>\r\n    </ion-item>\r\n\r\n    <ion-item\r\n      routerLink=\"/notifications\"\r\n      class=\"animate__animated animate__slideInUp animate__faster\"\r\n    >\r\n      <ion-icon slot=\"start\" name=\"notifications-outline\"></ion-icon>\r\n      <ion-label>{{ 'Notifications' | translate }}</ion-label>\r\n      <ion-badge color=\"danger\">1</ion-badge>\r\n    </ion-item>\r\n\r\n    <ion-item\r\n      routerLink=\"/account-settings\"\r\n      class=\"animate__animated animate__slideInUp animate__faster\"\r\n    >\r\n      <ion-icon slot=\"start\" name=\"settings-outline\"></ion-icon>\r\n      <ion-label>{{ 'Account Settings' | translate }}</ion-label>\r\n    </ion-item>\r\n\r\n    <ion-item\r\n      routerLink=\"/help\"\r\n      class=\"animate__animated animate__slideInUp animate__faster\"\r\n    >\r\n      <ion-icon slot=\"start\" name=\"help-buoy-outline\"></ion-icon>\r\n      <ion-label>{{ 'Help' | translate }}</ion-label>\r\n    </ion-item>\r\n\r\n    <ion-item class=\"animate__animated animate__slideInUp animate__faster\">\r\n      <ion-icon slot=\"start\" name=\"language-outline\"></ion-icon>\r\n      <ion-label>{{ 'App Language' | translate }}</ion-label>\r\n\r\n      <ion-label (click)=\"changeLanguage()\" class=\"ion-text-right ion-text-uppercase\">{{ selectedLanguage }}</ion-label>\r\n\r\n    </ion-item>\r\n\r\n    <ion-item\r\n      routerLink=\"/\"\r\n      class=\"animate__animated animate__slideInUp animate__faster\"\r\n    >\r\n      <ion-icon slot=\"start\" name=\"log-out-outline\"></ion-icon>\r\n      <ion-label>{{ 'Logout' | translate }}</ion-label>\r\n    </ion-item>\r\n  </ion-list>\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "LYsn":
    /*!******************************************!*\
      !*** ./src/app/home/tab4/tab4.page.scss ***!
      \******************************************/

    /*! exports provided: default */

    /***/
    function LYsn(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".account-img img {\n  display: block;\n  margin: 0 auto;\n  border-radius: 150px;\n  height: 100px;\n  margin-top: 10%;\n}\n\n.no-gap {\n  padding: 0 !important;\n  margin: 0 !important;\n}\n\n.text-muted {\n  color: #6c757d !important;\n}\n\n.small {\n  font-size: small;\n  font-weight: 600;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3RhYjQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsY0FBQTtFQUNBLGNBQUE7RUFDQSxvQkFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBRUE7RUFDRSxxQkFBQTtFQUNBLG9CQUFBO0FBQ0Y7O0FBRUE7RUFDRSx5QkFBQTtBQUNGOztBQUNBO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtBQUVGIiwiZmlsZSI6InRhYjQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmFjY291bnQtaW1nIGltZyB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgbWFyZ2luOiAwIGF1dG87XHJcbiAgYm9yZGVyLXJhZGl1czogMTUwcHg7XHJcbiAgaGVpZ2h0OiAxMDBweDtcclxuICBtYXJnaW4tdG9wOiAxMCU7XHJcbn1cclxuXHJcbi5uby1nYXAge1xyXG4gIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcclxuICBtYXJnaW46IDAgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnRleHQtbXV0ZWQge1xyXG4gIGNvbG9yOiAjNmM3NTdkICFpbXBvcnRhbnQ7XHJcbn1cclxuLnNtYWxsIHtcclxuICBmb250LXNpemU6IHNtYWxsO1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbn1cclxuIl19 */";
      /***/
    },

    /***/
    "bVwB":
    /*!******************************************!*\
      !*** ./src/app/home/tab4/tab4.module.ts ***!
      \******************************************/

    /*! exports provided: Tab4PageModule */

    /***/
    function bVwB(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Tab4PageModule", function () {
        return Tab4PageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _tab4_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./tab4.page */
      "3IKK");
      /* harmony import */


      var _tab4_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./tab4-routing.module */
      "e91h");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @ngx-translate/core */
      "sYmb");

      var Tab4PageModule = function Tab4PageModule() {
        _classCallCheck(this, Tab4PageModule);
      };

      Tab4PageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        imports: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([{
          path: '',
          component: _tab4_page__WEBPACK_IMPORTED_MODULE_6__["Tab4Page"]
        }]), _tab4_routing_module__WEBPACK_IMPORTED_MODULE_7__["Tab4PageRoutingModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateModule"]],
        declarations: [_tab4_page__WEBPACK_IMPORTED_MODULE_6__["Tab4Page"]]
      })], Tab4PageModule);
      /***/
    },

    /***/
    "e91h":
    /*!**************************************************!*\
      !*** ./src/app/home/tab4/tab4-routing.module.ts ***!
      \**************************************************/

    /*! exports provided: Tab4PageRoutingModule */

    /***/
    function e91h(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Tab4PageRoutingModule", function () {
        return Tab4PageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _tab4_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./tab4.page */
      "3IKK");

      var routes = [{
        path: '',
        component: _tab4_page__WEBPACK_IMPORTED_MODULE_3__["Tab4Page"]
      }];

      var Tab4PageRoutingModule = function Tab4PageRoutingModule() {
        _classCallCheck(this, Tab4PageRoutingModule);
      };

      Tab4PageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], Tab4PageRoutingModule);
      /***/
    }
  }]);
})();
//# sourceMappingURL=tab4-tab4-module-es5.js.map