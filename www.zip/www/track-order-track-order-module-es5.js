(function () {
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["track-order-track-order-module"], {
    /***/
    "3pHu":
    /*!*************************************************!*\
      !*** ./src/app/track-order/track-order.page.ts ***!
      \*************************************************/

    /*! exports provided: TrackOrderPage */

    /***/
    function pHu(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TrackOrderPage", function () {
        return TrackOrderPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_track_order_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./track-order.page.html */
      "hPJ1");
      /* harmony import */


      var _track_order_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./track-order.page.scss */
      "wNQ8");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var TrackOrderPage = /*#__PURE__*/function () {
        function TrackOrderPage() {
          _classCallCheck(this, TrackOrderPage);

          this.productDetails = [{
            "product_id": 1,
            "productImage": "../../../assets/products/iphone-12-mini-hero-150x150.jpeg",
            "productName": "Apple iPhone SE",
            "brand": "Apple",
            "shortName": "iPhone SE 32GB",
            "off": 15,
            "quantity": 1,
            "productLongDescription": "A14 Bionic, the fastest chip in a smartphone. An edge-to-edge OLED display. Ceramic Shield with four times better drop performance. And Night mode on every camera. iPhone 12 has it all — in two perfect sizes.",
            "productShortDescription": "A14 Bionic, the fastest chip in a smartphone. An edge-to-edge OLED display.",
            "regularPrice": 980,
            "salesPrice": 460
          }, {
            "product_id": 2,
            "productImage": "../../../assets/products/b5b4e08c1b97e8ed0c403bebda20d789.jpg",
            "productName": "Halife Women's Long Sleeve Boat Neck Off Shoulder Blouse Tops",
            "brand": "Halife US",
            "off": 45,
            "quantity": 2,
            "shortName": "Women's Long Sleeve",
            "productLongDescription": "A14 Bionic rockets past every other smartphone chip. The Pro camera system takes low-light photography to the next level — with an even bigger jump on iPhone 12 Pro Max. And Ceramic Shield delivers four times better drop performance. Let’s see what this thing can do.",
            "productShortDescription": "A14 Bionic rockets past every other smartphone chip.",
            "regularPrice": 1200,
            "salesPrice": 1000
          }];
          this.orderDetails = {
            "orderId": "OD5422SS5323EF",
            "grandTotal": 2500,
            "subTotal": 2460,
            "payMode": "Netbanking",
            "shippingCost": 40
          };
        }

        _createClass(TrackOrderPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return TrackOrderPage;
      }();

      TrackOrderPage.ctorParameters = function () {
        return [];
      };

      TrackOrderPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-track-order',
        template: _raw_loader_track_order_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_track_order_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], TrackOrderPage);
      /***/
    },

    /***/
    "hPJ1":
    /*!*****************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/track-order/track-order.page.html ***!
      \*****************************************************************************************/

    /*! exports provided: default */

    /***/
    function hPJ1(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\r\n  <ion-item>\r\n    <ion-label class=\"ion-padding\">\r\n      <h1>{{ 'Order Details' | translate }}</h1>\r\n    </ion-label>\r\n  </ion-item>\r\n</ion-header>\r\n\r\n<ion-content scroll=\"false\" no-padding>\r\n\r\n  <ion-list class=\"animate__animated animate__slideInUp animate__fast\">\r\n    <ion-item *ngFor=\"let item of productDetails; let i=index;\">\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col size=\"3\" routerLink=\"/single-product-view\">\r\n            <img class=\"cart-image\" src=\"{{ item?.productImage }}\" />\r\n            <small class=\"ion-text-uppercase text-muted\">\r\n              Qty: {{ item?.quantity }}</small\r\n            >\r\n          </ion-col>\r\n          <ion-col size=\"6\" routerLink=\"/single-product-view\">\r\n            <h6 class=\"text-oflow-lg no-gap\">{{ item?.shortName }}</h6>\r\n            <p class=\"text-muted no-gap\">{{ item?.brand }}</p>\r\n          </ion-col>\r\n          <ion-col size=\"3\" class=\"ion-text-right\">\r\n            <p\r\n              class=\"ion-text-uppercase no-gap x-small ion-margin-top text-muted\"\r\n            >\r\n              {{ item?.salesPrice }} X {{ item?.quantity }}\r\n            </p>\r\n            <h6 class=\"ion-text-right ion-margin-top\">\r\n              ₹ {{ item?.salesPrice*item?.quantity }}\r\n            </h6>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-item>\r\n  </ion-list>\r\n\r\n  <ion-grid\r\n    class=\"ion-padding animate__animated animate__fadeIn animate__faster\"\r\n  >\r\n    <ion-row>\r\n      <ion-col size=\"9\" class=\"ion-text-right\">\r\n        <small class=\"text-muted ion-text-uppercase no-gap\">{{ 'Subtotal' | translate }}</small>\r\n      </ion-col>\r\n      <ion-col size=\"3\" class=\"ion-text-right\">\r\n        ₹ {{ orderDetails?.subTotal }}\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <ion-row>\r\n      <ion-col size=\"9\" class=\"ion-text-right\">\r\n        <small class=\"text-muted ion-text-uppercase no-gap\"\r\n          >{{ 'Shipping Charge' | translate }}</small\r\n        >\r\n      </ion-col>\r\n      <ion-col size=\"3\" class=\"ion-text-right\">\r\n        ₹ {{ orderDetails?.shippingCost }}\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <ion-row>\r\n      <ion-col size=\"9\" class=\"ion-text-right\">\r\n        <small class=\"text-muted ion-text-uppercase no-gap\">{{ 'Grand Total' | translate }}</small>\r\n      </ion-col>\r\n      <ion-col size=\"3\" class=\"ion-text-right\">\r\n        ₹ {{ orderDetails?.grandTotal }}\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <h6>{{ 'Payment method' | translate }}: {{ orderDetails?.payMode }}</h6>\r\n  </ion-grid>\r\n\r\n  <ion-grid class=\"ion-padding\">\r\n    <small class=\"text-muted ion-text-uppercase\">{{ 'Delivery Address' | translate }}</small>\r\n  </ion-grid>\r\n\r\n  <ion-list class=\"animate__animated animate__fadeIn animate__faster\">\r\n    <ion-item>\r\n      <ion-avatar slot=\"start\">\r\n        <ion-icon size=\"large\" name=\"home-outline\"></ion-icon>\r\n      </ion-avatar>\r\n      <ion-label>\r\n        <h2>Mr. Karthikeyan</h2>\r\n        <h3>3423 Jehovah Drive</h3>\r\n        <p>Roanoke, Virginia - 24019</p>\r\n        <p>+1 540-529-3606</p>\r\n      </ion-label>\r\n    </ion-item>\r\n  </ion-list>\r\n\r\n  <div class=\"order-track animate__animated animate__fadeIn animate__faster\">\r\n    <div class=\"order-track-step\">\r\n      <div class=\"order-track-status\">\r\n        <span class=\"order-track-status-dot\"></span>\r\n        <span class=\"order-track-status-line\"></span>\r\n      </div>\r\n      <div class=\"order-track-text\">\r\n        <p class=\"order-track-text-stat no-gap\">Order Placed</p>\r\n        <span class=\"order-track-text-sub\">21st November, 2020</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"order-track-step\">\r\n      <div class=\"order-track-status\">\r\n        <span class=\"order-track-status-dot\"></span>\r\n        <span class=\"order-track-status-line\"></span>\r\n      </div>\r\n      <div class=\"order-track-text\">\r\n        <p class=\"order-track-text-stat no-gap\">Order Processed</p>\r\n        <span class=\"order-track-text-sub\">21st November, 2020</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"order-track-step\">\r\n      <div class=\"order-track-status\">\r\n        <span class=\"order-track-status-dot\"></span>\r\n        <span class=\"order-track-status-line\"></span>\r\n      </div>\r\n      <div class=\"order-track-text\">\r\n        <p class=\"order-track-text-stat no-gap\">Shipped to US</p>\r\n        <span class=\"order-track-text-sub\">21st November, 2020</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"order-track-step\">\r\n      <div class=\"order-track-status\">\r\n        <span class=\"order-track-status-dot\"></span>\r\n        <span class=\"order-track-status-line\"></span>\r\n      </div>\r\n      <div class=\"order-track-text\">\r\n        <p class=\"order-track-text-stat no-gap\">Order Dispatched at VA</p>\r\n        <span class=\"order-track-text-sub\">21st November, 2020</span>\r\n      </div>\r\n    </div>\r\n    <div class=\"order-track-step\">\r\n      <div class=\"order-track-status\">\r\n        <span class=\"order-track-status-dot\"></span>\r\n        <span class=\"order-track-status-line\"></span>\r\n      </div>\r\n      <div class=\"order-track-text\">\r\n        <p class=\"order-track-text-stat no-gap\">Order Deliverd</p>\r\n        <span class=\"order-track-text-sub\">21st November, 2020</span>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "mfCu":
    /*!***********************************************************!*\
      !*** ./src/app/track-order/track-order-routing.module.ts ***!
      \***********************************************************/

    /*! exports provided: TrackOrderPageRoutingModule */

    /***/
    function mfCu(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TrackOrderPageRoutingModule", function () {
        return TrackOrderPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _track_order_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./track-order.page */
      "3pHu");

      var routes = [{
        path: '',
        component: _track_order_page__WEBPACK_IMPORTED_MODULE_3__["TrackOrderPage"]
      }];

      var TrackOrderPageRoutingModule = function TrackOrderPageRoutingModule() {
        _classCallCheck(this, TrackOrderPageRoutingModule);
      };

      TrackOrderPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], TrackOrderPageRoutingModule);
      /***/
    },

    /***/
    "oKOb":
    /*!***************************************************!*\
      !*** ./src/app/track-order/track-order.module.ts ***!
      \***************************************************/

    /*! exports provided: TrackOrderPageModule */

    /***/
    function oKOb(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TrackOrderPageModule", function () {
        return TrackOrderPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _track_order_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./track-order-routing.module */
      "mfCu");
      /* harmony import */


      var _track_order_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./track-order.page */
      "3pHu");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @ngx-translate/core */
      "sYmb");

      var TrackOrderPageModule = function TrackOrderPageModule() {
        _classCallCheck(this, TrackOrderPageModule);
      };

      TrackOrderPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _track_order_routing_module__WEBPACK_IMPORTED_MODULE_5__["TrackOrderPageRoutingModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"]],
        declarations: [_track_order_page__WEBPACK_IMPORTED_MODULE_6__["TrackOrderPage"]]
      })], TrackOrderPageModule);
      /***/
    },

    /***/
    "wNQ8":
    /*!***************************************************!*\
      !*** ./src/app/track-order/track-order.page.scss ***!
      \***************************************************/

    /*! exports provided: default */

    /***/
    function wNQ8(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".text-muted {\n  color: #6c757d !important;\n}\n\n.no-gap {\n  padding: 0 !important;\n  margin: 0 !important;\n}\n\n.text-oflow-lg {\n  display: inline-block;\n}\n\n.cart-image {\n  height: 60px;\n  padding: 5px;\n}\n\n.x-small {\n  font-size: x-small !important;\n}\n\n.order-track {\n  margin-top: 2rem;\n  padding: 0 1rem;\n  padding-top: 1rem;\n  display: flex;\n  flex-direction: column;\n}\n\n.order-track-step {\n  display: flex;\n  height: 7rem;\n}\n\n.order-track-step:last-child {\n  overflow: hidden;\n  height: 4rem;\n}\n\n.order-track-step:last-child .order-track-status span:last-of-type {\n  display: none;\n}\n\n.order-track-status {\n  margin-right: 1.5rem;\n  position: relative;\n}\n\n.order-track-status-dot {\n  display: block;\n  width: 2.2rem;\n  height: 2.2rem;\n  border-radius: 50%;\n  background: #6800f0;\n}\n\n.order-track-status-line {\n  display: block;\n  margin: 0 auto;\n  width: 2px;\n  height: 7rem;\n  background: #6800f0;\n}\n\n.order-track-text-stat {\n  font-size: 1.3rem;\n  font-weight: 500;\n  margin-bottom: 3px;\n}\n\n.order-track-text-sub {\n  font-size: 1rem;\n  font-weight: 300;\n}\n\n.order-track-text {\n  padding-top: 0;\n  margin-top: 0;\n}\n\n.order-track {\n  transition: all 0.3s height 0.3s;\n  transform-origin: top center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3RyYWNrLW9yZGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxxQkFBQTtFQUNBLG9CQUFBO0FBRUY7O0FBQ0E7RUFDRSxxQkFBQTtBQUVGOztBQUNBO0VBQ0UsWUFBQTtFQUNBLFlBQUE7QUFFRjs7QUFDQTtFQUNFLDZCQUFBO0FBRUY7O0FBU0E7RUFDRSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtBQU5GOztBQVFFO0VBQ0UsYUFBQTtFQUNBLFlBQUE7QUFOSjs7QUFRSTtFQUNFLGdCQUFBO0VBQ0EsWUFBQTtBQU5OOztBQU9NO0VBQ0UsYUFBQTtBQUxSOztBQVVFO0VBQ0Usb0JBQUE7RUFDQSxrQkFBQTtBQVJKOztBQVNJO0VBQ0UsY0FBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFsQ1M7QUEyQmY7O0FBU0k7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBekNTO0FBa0NmOztBQVlJO0VBQ0UsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FBVk47O0FBYUk7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7QUFYTjs7QUFlQTtFQUNFLGNBQUE7RUFDQSxhQUFBO0FBWkY7O0FBZUE7RUFDRSxnQ0FBQTtFQUNBLDRCQUFBO0FBWkYiLCJmaWxlIjoidHJhY2stb3JkZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRleHQtbXV0ZWQge1xyXG4gIGNvbG9yOiAjNmM3NTdkICFpbXBvcnRhbnQ7XHJcbn1cclxuLm5vLWdhcCB7XHJcbiAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xyXG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4udGV4dC1vZmxvdy1sZyB7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG59XHJcblxyXG4uY2FydC1pbWFnZSB7XHJcbiAgaGVpZ2h0OiA2MHB4O1xyXG4gIHBhZGRpbmc6IDVweDtcclxufVxyXG5cclxuLngtc21hbGwge1xyXG4gIGZvbnQtc2l6ZTogeC1zbWFsbCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4vLyBPcmRlciBUYWNraW5nIFNDU1NcclxuXHJcbiRvcmRlclByaW1hcnk6ICM2ODAwZjA7XHJcbiRibHVlU2hhZGUxOiAjMmMzZTUwO1xyXG4kYmx1ZVNoYWRlMjogIzM0NDk1ZTtcclxuJGJveFNoYWRvd0xpZ2h0MTogMCAycmVtIDVyZW0gcmdiYSgwLCAwLCAwLCAwLjA2KTtcclxuJGJveFNoYWR3b0RhcmsxOiAwIDJyZW0gNnJlbSByZ2JhKDAsIDAsIDAsIDAuMyk7XHJcblxyXG4ub3JkZXItdHJhY2sge1xyXG4gIG1hcmdpbi10b3A6IDJyZW07XHJcbiAgcGFkZGluZzogMCAxcmVtO1xyXG4gIHBhZGRpbmctdG9wOiAxcmVtO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuXHJcbiAgJi1zdGVwIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBoZWlnaHQ6IDdyZW07XHJcblxyXG4gICAgJjpsYXN0LWNoaWxkIHtcclxuICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgICAgaGVpZ2h0OiA0cmVtO1xyXG4gICAgICAmIC5vcmRlci10cmFjay1zdGF0dXMgc3BhbjpsYXN0LW9mLXR5cGUge1xyXG4gICAgICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gICYtc3RhdHVzIHtcclxuICAgIG1hcmdpbi1yaWdodDogMS41cmVtO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgJi1kb3Qge1xyXG4gICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgd2lkdGg6IDIuMnJlbTtcclxuICAgICAgaGVpZ2h0OiAyLjJyZW07XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgYmFja2dyb3VuZDogJG9yZGVyUHJpbWFyeTtcclxuICAgIH1cclxuICAgICYtbGluZSB7XHJcbiAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICBtYXJnaW46IDAgYXV0bztcclxuICAgICAgd2lkdGg6IDJweDtcclxuICAgICAgaGVpZ2h0OiA3cmVtO1xyXG4gICAgICBiYWNrZ3JvdW5kOiAkb3JkZXJQcmltYXJ5O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgJi10ZXh0IHtcclxuICAgICYtc3RhdCB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMS4zcmVtO1xyXG4gICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiAzcHg7XHJcbiAgICB9XHJcblxyXG4gICAgJi1zdWIge1xyXG4gICAgICBmb250LXNpemU6IDFyZW07XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiAzMDA7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbi5vcmRlci10cmFjay10ZXh0IHtcclxuICBwYWRkaW5nLXRvcDogMDtcclxuICBtYXJnaW4tdG9wOiAwO1xyXG59XHJcblxyXG4ub3JkZXItdHJhY2sge1xyXG4gIHRyYW5zaXRpb246IGFsbCAwLjNzIGhlaWdodCAwLjNzO1xyXG4gIHRyYW5zZm9ybS1vcmlnaW46IHRvcCBjZW50ZXI7XHJcbiAgLy8gdHJhbnNmb3JtOiBzY2FsZSgwKTtcclxuICAvLyBoZWlnaHQ6IDA7XHJcbn1cclxuIl19 */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=track-order-track-order-module-es5.js.map