(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["order-validate-order-validate-module"], {
    /***/
    "38Z+":
    /*!*********************************************************!*\
      !*** ./src/app/order-validate/order-validate.module.ts ***!
      \*********************************************************/

    /*! exports provided: OrderValidatePageModule */

    /***/
    function Z(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "OrderValidatePageModule", function () {
        return OrderValidatePageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _order_validate_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./order-validate-routing.module */
      "4m4V");
      /* harmony import */


      var _order_validate_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./order-validate.page */
      "F16W");

      var OrderValidatePageModule = function OrderValidatePageModule() {
        _classCallCheck(this, OrderValidatePageModule);
      };

      OrderValidatePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _order_validate_routing_module__WEBPACK_IMPORTED_MODULE_5__["OrderValidatePageRoutingModule"]],
        declarations: [_order_validate_page__WEBPACK_IMPORTED_MODULE_6__["OrderValidatePage"]]
      })], OrderValidatePageModule);
      /***/
    },

    /***/
    "4m4V":
    /*!*****************************************************************!*\
      !*** ./src/app/order-validate/order-validate-routing.module.ts ***!
      \*****************************************************************/

    /*! exports provided: OrderValidatePageRoutingModule */

    /***/
    function m4V(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "OrderValidatePageRoutingModule", function () {
        return OrderValidatePageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _order_validate_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./order-validate.page */
      "F16W");

      var routes = [{
        path: '',
        component: _order_validate_page__WEBPACK_IMPORTED_MODULE_3__["OrderValidatePage"]
      }];

      var OrderValidatePageRoutingModule = function OrderValidatePageRoutingModule() {
        _classCallCheck(this, OrderValidatePageRoutingModule);
      };

      OrderValidatePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], OrderValidatePageRoutingModule);
      /***/
    },

    /***/
    "6Yf+":
    /*!***********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/order-validate/order-validate.page.html ***!
      \***********************************************************************************************/

    /*! exports provided: default */

    /***/
    function Yf(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-content>\r\n  <p class=\"ion-text-center\">Payment Gateway / Order Validation Page</p>\r\n\r\n  <div class=\"bottom-bar\">\r\n    <ion-grid>\r\n      <ion-row>\r\n        <ion-col size=\"6\">\r\n          <ion-button\r\n            color=\"success\"\r\n            routerLink=\"/order-success\"\r\n            class=\"ion-text-uppercase\"\r\n            size=\"full\"\r\n            expand=\"block\"\r\n            >Order Success</ion-button\r\n          >\r\n        </ion-col>\r\n\r\n        <ion-col size=\"6\">\r\n          <ion-button\r\n            color=\"danger\"\r\n            routerLink=\"/order-failed\"\r\n            class=\"ion-text-uppercase\"\r\n            size=\"full\"\r\n            expand=\"block\"\r\n            >Order Failed</ion-button\r\n          >\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </div>\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "C38j":
    /*!*********************************************************!*\
      !*** ./src/app/order-validate/order-validate.page.scss ***!
      \*********************************************************/

    /*! exports provided: default */

    /***/
    function C38j(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".bottom-bar {\n  position: fixed;\n  width: 100%;\n  bottom: 0;\n  background-color: #ffffff;\n  z-index: 999;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL29yZGVyLXZhbGlkYXRlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtBQUNGIiwiZmlsZSI6Im9yZGVyLXZhbGlkYXRlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ib3R0b20tYmFyIHtcclxuICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgYm90dG9tOiAwO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmY7XHJcbiAgei1pbmRleDogOTk5O1xyXG59XHJcbiJdfQ== */";
      /***/
    },

    /***/
    "F16W":
    /*!*******************************************************!*\
      !*** ./src/app/order-validate/order-validate.page.ts ***!
      \*******************************************************/

    /*! exports provided: OrderValidatePage */

    /***/
    function F16W(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "OrderValidatePage", function () {
        return OrderValidatePage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_order_validate_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./order-validate.page.html */
      "6Yf+");
      /* harmony import */


      var _order_validate_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./order-validate.page.scss */
      "C38j");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var OrderValidatePage = /*#__PURE__*/function () {
        function OrderValidatePage() {
          _classCallCheck(this, OrderValidatePage);
        }

        _createClass(OrderValidatePage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return OrderValidatePage;
      }();

      OrderValidatePage.ctorParameters = function () {
        return [];
      };

      OrderValidatePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-order-validate',
        template: _raw_loader_order_validate_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_order_validate_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], OrderValidatePage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=order-validate-order-validate-module-es5.js.map