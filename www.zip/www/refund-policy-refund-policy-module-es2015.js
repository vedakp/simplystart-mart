(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["refund-policy-refund-policy-module"],{

/***/ "JbcR":
/*!*******************************************************!*\
  !*** ./src/app/refund-policy/refund-policy.module.ts ***!
  \*******************************************************/
/*! exports provided: RefundPolicyPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RefundPolicyPageModule", function() { return RefundPolicyPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _refund_policy_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./refund-policy-routing.module */ "hINY");
/* harmony import */ var _refund_policy_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./refund-policy.page */ "PDk/");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");








let RefundPolicyPageModule = class RefundPolicyPageModule {
};
RefundPolicyPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _refund_policy_routing_module__WEBPACK_IMPORTED_MODULE_5__["RefundPolicyPageRoutingModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"]
        ],
        declarations: [_refund_policy_page__WEBPACK_IMPORTED_MODULE_6__["RefundPolicyPage"]]
    })
], RefundPolicyPageModule);



/***/ }),

/***/ "PDk/":
/*!*****************************************************!*\
  !*** ./src/app/refund-policy/refund-policy.page.ts ***!
  \*****************************************************/
/*! exports provided: RefundPolicyPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RefundPolicyPage", function() { return RefundPolicyPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_refund_policy_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./refund-policy.page.html */ "mLhu");
/* harmony import */ var _refund_policy_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./refund-policy.page.scss */ "Q+4R");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let RefundPolicyPage = class RefundPolicyPage {
    constructor() { }
    ngOnInit() {
    }
};
RefundPolicyPage.ctorParameters = () => [];
RefundPolicyPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-refund-policy',
        template: _raw_loader_refund_policy_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_refund_policy_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], RefundPolicyPage);



/***/ }),

/***/ "Q+4R":
/*!*******************************************************!*\
  !*** ./src/app/refund-policy/refund-policy.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".bottom-bar {\n  position: fixed;\n  width: 100%;\n  bottom: 0;\n  background-color: transparent;\n  z-index: 999;\n}\n\n.heading {\n  color: #42e695;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3JlZnVuZC1wb2xpY3kucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZUFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsNkJBQUE7RUFDQSxZQUFBO0FBQ0Y7O0FBRUE7RUFDRSxjQUFBO0FBQ0YiLCJmaWxlIjoicmVmdW5kLXBvbGljeS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYm90dG9tLWJhciB7XHJcbiAgcG9zaXRpb246IGZpeGVkO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGJvdHRvbTogMDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICB6LWluZGV4OiA5OTk7XHJcbn1cclxuXHJcbi5oZWFkaW5nIHtcclxuICBjb2xvcjogIzQyZTY5NTtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "hINY":
/*!***************************************************************!*\
  !*** ./src/app/refund-policy/refund-policy-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: RefundPolicyPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RefundPolicyPageRoutingModule", function() { return RefundPolicyPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _refund_policy_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./refund-policy.page */ "PDk/");




const routes = [
    {
        path: '',
        component: _refund_policy_page__WEBPACK_IMPORTED_MODULE_3__["RefundPolicyPage"]
    }
];
let RefundPolicyPageRoutingModule = class RefundPolicyPageRoutingModule {
};
RefundPolicyPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], RefundPolicyPageRoutingModule);



/***/ }),

/***/ "mLhu":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/refund-policy/refund-policy.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title class=\"ion-text-capitalize\"\r\n      >{{ 'Refund policy' | translate }}</ion-title\r\n    >\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content class=\"ion-padding\">\r\n  <ion-col>\r\n    <div class=\"ion-text-wrap\">\r\n      <h2 class=\"heading\">Content 1</h2>\r\n      <p>\r\n        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ac vehicula\r\n        lorem.\r\n      </p>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam at autem\r\n        neque dolores distinctio aut?\r\n      </p>\r\n    </div>\r\n  </ion-col>\r\n\r\n  <ion-col>\r\n    <div class=\"ion-text-wrap\">\r\n      <h2 class=\"heading\">Content 2</h2>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid atque\r\n        ipsa, molestias debitis similique excepturi est minus nostrum saepe id!\r\n      </p>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum suscipit\r\n        architecto labore, inventore deserunt illo nesciunt quos consectetur non\r\n        voluptatem rem ab officiis! Doloremque a enim amet voluptas, mollitia\r\n        expedita?\r\n      </p>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis\r\n        eveniet sint totam perspiciatis molestias eum quae odit. Amet dolorum\r\n        quam ipsam ad doloremque veniam, reiciendis eveniet, provident\r\n        perspiciatis, libero nobis.\r\n      </p>\r\n    </div>\r\n  </ion-col>\r\n\r\n  <ion-col>\r\n    <div class=\"ion-text-wrap\">\r\n      <h2 class=\"heading\">Content 3</h2>\r\n      <p>\r\n        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ac vehicula\r\n        lorem.\r\n      </p>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam at autem\r\n        neque dolores distinctio aut?\r\n      </p>\r\n    </div>\r\n  </ion-col>\r\n\r\n  <ion-col>\r\n    <div class=\"ion-text-wrap\">\r\n      <h2 class=\"heading\">Content 4</h2>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid atque\r\n        ipsa, molestias debitis similique excepturi est minus nostrum saepe id!\r\n      </p>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum suscipit\r\n        architecto labore, inventore deserunt illo nesciunt quos consectetur non\r\n        voluptatem rem ab officiis! Doloremque a enim amet voluptas, mollitia\r\n        expedita?\r\n      </p>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis\r\n        eveniet sint totam perspiciatis molestias eum quae odit. Amet dolorum\r\n        quam ipsam ad doloremque veniam, reiciendis eveniet, provident\r\n        perspiciatis, libero nobis.\r\n      </p>\r\n    </div>\r\n  </ion-col>\r\n\r\n  <ion-col>\r\n    <div class=\"ion-text-wrap\">\r\n      <h2 class=\"heading\">Content 5</h2>\r\n      <p>\r\n        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ac vehicula\r\n        lorem.\r\n      </p>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam at autem\r\n        neque dolores distinctio aut?\r\n      </p>\r\n    </div>\r\n  </ion-col>\r\n\r\n  <ion-col>\r\n    <div class=\"ion-text-wrap\">\r\n      <h2 class=\"heading\">Content 6</h2>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid atque\r\n        ipsa, molestias debitis similique excepturi est minus nostrum saepe id!\r\n      </p>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum suscipit\r\n        architecto labore, inventore deserunt illo nesciunt quos consectetur non\r\n        voluptatem rem ab officiis! Doloremque a enim amet voluptas, mollitia\r\n        expedita?\r\n      </p>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis\r\n        eveniet sint totam perspiciatis molestias eum quae odit. Amet dolorum\r\n        quam ipsam ad doloremque veniam, reiciendis eveniet, provident\r\n        perspiciatis, libero nobis.\r\n      </p>\r\n    </div>\r\n  </ion-col>\r\n</ion-content>\r\n");

/***/ })

}]);
//# sourceMappingURL=refund-policy-refund-policy-module-es2015.js.map