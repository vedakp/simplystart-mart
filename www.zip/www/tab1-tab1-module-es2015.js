(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab1-tab1-module"],{

/***/ "Fqdx":
/*!****************************************!*\
  !*** ./src/app/home/tab1/tab1.page.ts ***!
  \****************************************/
/*! exports provided: Tab1Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab1Page", function() { return Tab1Page; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_tab1_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./tab1.page.html */ "kprM");
/* harmony import */ var _tab1_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tab1.page.scss */ "eeSV");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var src_app_services_woocommerce_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/woocommerce.service */ "+GIV");






let Tab1Page = class Tab1Page {
    constructor(router, wc) {
        this.router = router;
        this.wc = wc;
        // categories = {
        //     "categories": [
        //         "Womens",
        //         "Mobiles",
        //         "Beauty",
        //         "Kids",
        //         "Skin care",
        //         "Home",
        //         "Fashion"
        //     ]
        // };
        this.slider = [];
        this.categories = [];
        this.mobiles = [
            {
                "product_id": 1,
                "productImage": "../../../assets/products/iphone-12-pro-blue-150x150.png",
                "productName": "Apple iPhone 12 32GB",
                "brand": "Apple",
                "shortName": "iPhone 12 32GB",
                "off": 45,
                "productLongDescription": "A14 Bionic, the fastest chip in a smartphone. An edge-to-edge OLED display. Ceramic Shield with four times better drop performance. And Night mode on every camera. iPhone 12 has it all — in two perfect sizes.",
                "productShortDescription": "A14 Bionic, the fastest chip in a smartphone. An edge-to-edge OLED display.",
                "regularPrice": 69000,
                "salesPrice": 69900
            },
            {
                "product_id": 2,
                "productImage": "../../../assets/products/iphone-12-mini-hero-150x150.jpeg",
                "productName": "Apple iPhone 12 Pro  64GB",
                "brand": "Apple",
                "off": 45,
                "shortName": "iPhone 12 Pro 64GB",
                "productLongDescription": "A14 Bionic rockets past every other smartphone chip. The Pro camera system takes low-light photography to the next level — with an even bigger jump on iPhone 12 Pro Max. And Ceramic Shield delivers four times better drop performance. Let’s see what this thing can do.",
                "productShortDescription": "A14 Bionic rockets past every other smartphone chip.",
                "regularPrice": 199000,
                "salesPrice": 119000
            },
            {
                "product_id": 3,
                "productImage": "../../../assets/products/iPhone-SE-2020-Red.jpg?resize=150%2C150&ssl=1",
                "productName": "Apple iPhone SE 32GB",
                "brand": "Apple",
                "off": 53,
                "shortName": "iPhone SE 32GB",
                "productLongDescription": "iPhone SE packs a remarkably powerful chip into our most popular size at our most affordable price. It’s just what you’ve been waiting for.",
                "productShortDescription": "iPhone SE packs a remarkably powerful chip into our most popular size at our most affordable price. ",
                "regularPrice": 39000,
                "salesPrice": 39000
            },
            {
                "product_id": 4,
                "productImage": "../../../assets/products/APPLE-IPHONE-11-PRO-MAX-Midnight-Green-CellucityPhoneHub-150x150.png",
                "productName": "Apple iPhone 11 32GB",
                "brand": "Apple",
                "off": 25,
                "shortName": "iPhone 11 32GB",
                "productLongDescription": "As part of our efforts to reach our environmental goals, iPhone 11 does not include a power adapter or EarPods. Included in the box is a USB‑C to Lightning cable that supports fast charging and is compatible with USB‑C power adapters and computer ports.",
                "productShortDescription": "As part of our efforts to reach our environmental goals, iPhone 11 does not include a power adapter or EarPods.",
                "regularPrice": 54000,
                "salesPrice": 50490
            },
            {
                "product_id": 5,
                "productImage": "../../../assets/products/apple-macbook-pro-silver-7-150x150.jpg",
                "productName": "iMac Intel Xeon 8GB 4K Retina",
                "brand": "Apple",
                "off": 45,
                "shortName": "Apple iMac",
                "productLongDescription": "The all-in-one for all. If you can dream it, you can do it on iMac. It’s beautifully designed, incredibly intuitive and packed with powerful tools that let you take any idea to the next level. And the new 27-inch model elevates the experience in every way, with faster processors and graphics, expanded memory and storage, enhanced audio and video capabilities, and an even more stunning Retina 5K display. It’s the desktop that does it all — better and faster than ever.",
                "productShortDescription": "The all-in-one for all. If you can dream it, you can do it on iMac.",
                "regularPrice": 99000,
                "salesPrice": 99900
            },
            {
                "product_id": 6,
                "productImage": "../../../assets/products/Apple-MacBook-Air-150x150.png",
                "productName": "Apple MacBook Air 128GB SSD",
                "brand": "Apple",
                "off": 15,
                "shortName": "MacBook Air",
                "productLongDescription": "The incredibly thin and light MacBook Air is now more powerful than ever. It features a brilliant Retina display, new Magic Keyboard, Touch ID, processors with up to twice the performance,1 faster graphics and double the storage capacity. The sleek wedge-shaped design is created from 100% recycled aluminium, making it the greenest Mac ever.2 And with all-day battery life, our most popular Mac is your perfectly portable, do-it-all notebook.",
                "productShortDescription": "The incredibly thin and light MacBook Air is now more powerful than ever.",
                "regularPrice": 99090,
                "salesPrice": 92900
            },
            {
                "product_id": 7,
                "productImage": "../../../assets/products/apple-macbook-pro-silver-7-150x150.jpg",
                "productName": "Apple MacBook Pro 512GB SSD",
                "brand": "Apple",
                "off": 22,
                "shortName": "MacBook Pro",
                "productLongDescription": "MacBook Pro elevates the notebook to a whole new level of performance and portability. Wherever your ideas take you, you’ll get there faster than ever with high‑performance processors and memory, advanced graphics, blazing‑fast storage and more — all in a compact 1.4-kilogram package.",
                "productShortDescription": "MacBook Pro elevates the notebook to a whole new level of performance and portability.",
                "regularPrice": 199000,
                "salesPrice": 199000
            }
        ];
        this.newArrivals = [
        // {
        //     "product_id": 1,
        //     "productImage": "../../../assets/products/39ed8e8d-01b0-4d86-8cb0-305b4869bb48.__CR288,248,496,496_PT0_SX300_V1___.jpg",
        //     "productName": "Women Fashion Handbags Tote Bag Shoulder Bag Top Handle Satchel Purse",
        //     "brand": "Bagger IN",
        //     "shortName": "Women Fashion Handbag",
        //     "off": 15,
        //     "productLongDescription": "A14 Bionic, the fastest chip in a smartphone. An edge-to-edge OLED display. Ceramic Shield with four times better drop performance. And Night mode on every camera. iPhone 12 has it all — in two perfect sizes.",
        //     "productShortDescription": "A14 Bionic, the fastest chip in a smartphone. An edge-to-edge OLED display.",
        //     "regularPrice": 980,
        //     "salesPrice": 850
        // },
        ];
        this.products = [];
    }
    doSearch() {
        this.router.navigateByUrl("/search");
    }
    ngOnInit() {
        this.getAppSlider();
        this.getCategories();
        this.getNewArrival();
        this.getProducts();
    }
    getCategories() {
        this.wc.getAllCategories().then((categoryData) => {
            categoryData.map((item) => {
                this.categories.push({ src: (item.image && item.image.src) ? item.image.src : '', name: item.name });
            });
        });
    }
    getProducts() {
        this.wc.getAllStoreProducts('on_sale', 1).then((productsRes) => {
            console.log("Products ", productsRes);
            productsRes.map((item) => {
                var prodObj = {
                    "product_id": item.id,
                    "productImage": (item.images && item.images[0] && item.images[0].src) ? item.images[0].src : '',
                    "productName": item.name,
                    "brand": "Bagger IN",
                    "shortName": item.name,
                    "off": parseInt(((item.sale_price / item.regular_price) * 100).toString()),
                    "productShortDescription": item.short_description,
                    "regularPrice": item.regular_price,
                    "salesPrice": item.sale_price
                };
                this.products.push(prodObj);
            });
        });
    }
    getNewArrival() {
        this.wc.getProductsByTags(90).then((productsRes) => {
            console.log("Products ", productsRes);
            productsRes.map((item) => {
                var prodObj = {
                    "product_id": item.id,
                    "productImage": (item.images && item.images[0] && item.images[0].src) ? item.images[0].src : '',
                    "productName": item.name,
                    "brand": "Bagger IN",
                    "shortName": item.name,
                    "off": parseInt(((item.sale_price / item.regular_price) * 100).toString()),
                    "productShortDescription": item.short_description,
                    "regularPrice": item.regular_price,
                    "salesPrice": item.sale_price
                };
                this.newArrivals.push(prodObj);
            });
        });
    }
    getAppSlider() {
        this.wc.getAppSliderBytags().then((res) => {
            console.log("App Slider", res);
            res.map((item) => {
                this.slider.push(item.featured_media_src_url);
            });
        });
    }
};
Tab1Page.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: src_app_services_woocommerce_service__WEBPACK_IMPORTED_MODULE_5__["WoocommerceService"] }
];
Tab1Page = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-tab1',
        template: _raw_loader_tab1_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_tab1_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], Tab1Page);



/***/ }),

/***/ "eeSV":
/*!******************************************!*\
  !*** ./src/app/home/tab1/tab1.page.scss ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".no-gap {\n  padding: 0 !important;\n  margin: 0 !important;\n}\n\n.left-text {\n  position: absolute;\n  bottom: 29px;\n  top: 10px;\n  left: 10px;\n  font-weight: 800;\n  font-size: x-small;\n  text-align: left !important;\n  width: auto;\n  color: #fff;\n}\n\n.top-nav {\n  background: var(--ion-color-primary-gradient);\n  padding-top: 25px !important;\n  padding-right: 25px !important;\n  padding-left: 25px !important;\n  padding-bottom: 5px !important;\n  position: fixed;\n  width: 100%;\n  z-index: 999;\n}\n\n.categories-grid {\n  padding-top: 90px !important;\n}\n\n.categories-row {\n  width: 100px;\n  height: 100px;\n  border-radius: 6px;\n}\n\n.text-oflow-sm {\n  display: inline-block;\n  width: 135px;\n  white-space: nowrap;\n  overflow: hidden !important;\n  text-overflow: ellipsis;\n}\n\n.text-oflow-lg {\n  display: inline-block;\n  width: 285px;\n  white-space: nowrap;\n  overflow: hidden !important;\n  text-overflow: ellipsis;\n}\n\n.text-oflow-md {\n  display: inline-block;\n  width: 155px !important;\n  white-space: nowrap;\n  overflow: hidden !important;\n  text-overflow: ellipsis;\n}\n\n.x-small-card {\n  width: 80px !important;\n  height: 80px !important;\n}\n\n.sm-cards {\n  width: 150px;\n  height: 240px;\n  border: 2px solid #f8f8f8;\n}\n\n.md-cards {\n  width: 300px;\n  height: 400px;\n  border: 2px solid #f8f8f8;\n}\n\n.lg-cards {\n  width: 300px;\n  height: 190px;\n}\n\n.card-border {\n  border: 2px solid #f8f8f8;\n}\n\n.card-image {\n  pointer-events: none;\n}\n\n.bottom-bar-padding {\n  padding-bottom: 80px;\n}\n\n.round-edge {\n  border-radius: 8px !important;\n  overflow: hidden;\n  box-shadow: 0px 1px 9px rgba(0, 0, 0, 0.15) !important;\n}\n\n.card-header-btn {\n  margin: 11px;\n}\n\n.text-muted {\n  color: #6c757d !important;\n}\n\n.x-small {\n  font-size: x-small;\n}\n\n.small {\n  font-size: small;\n}\n\n.xx-small {\n  font-size: xx-small;\n}\n\n.padding-l-r-0 {\n  padding-left: 0px !important;\n  padding-right: 0px !important;\n  height: 260px;\n}\n\n.preview_wrap {\n  height: 200px;\n  padding: 0;\n  overflow: hidden;\n}\n\n.frame_wrap {\n  width: 1280px;\n  height: 600px;\n  border: 0;\n  transform: scale(0.3);\n  transform-origin: 0 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3RhYjEucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UscUJBQUE7RUFDQSxvQkFBQTtBQUNGOztBQUVBO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMkJBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtBQUNGOztBQUVBO0VBQ0UsNkNBQUE7RUFDQSw0QkFBQTtFQUNBLDhCQUFBO0VBQ0EsNkJBQUE7RUFDQSw4QkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQUNGOztBQUVBO0VBQ0UsNEJBQUE7QUFDRjs7QUFFQTtFQUNFLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7QUFDRjs7QUFFQTtFQUNFLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsMkJBQUE7RUFDQSx1QkFBQTtBQUNGOztBQUVBO0VBQ0UscUJBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSwyQkFBQTtFQUNBLHVCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxxQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSwyQkFBQTtFQUNBLHVCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxzQkFBQTtFQUNBLHVCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLHlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLHlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxZQUFBO0VBQ0EsYUFBQTtBQUNGOztBQUVBO0VBQ0UseUJBQUE7QUFDRjs7QUFFQTtFQUNFLG9CQUFBO0FBQ0Y7O0FBRUE7RUFDRSxvQkFBQTtBQUNGOztBQUVBO0VBQ0UsNkJBQUE7RUFDQSxnQkFBQTtFQUNBLHNEQUFBO0FBQ0Y7O0FBRUE7RUFDRSxZQUFBO0FBQ0Y7O0FBRUE7RUFDRSx5QkFBQTtBQUNGOztBQUVBO0VBQ0Usa0JBQUE7QUFDRjs7QUFFQTtFQUNFLGdCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxtQkFBQTtBQUVGOztBQUNBO0VBQ0UsNEJBQUE7RUFDQSw2QkFBQTtFQUNBLGFBQUE7QUFFRjs7QUFFQTtFQUVFLGFBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7QUFBRjs7QUFFQTtFQUNFLGFBQUE7RUFDQSxhQUFBO0VBQ0EsU0FBQTtFQUtBLHFCQUFBO0VBTUEscUJBQUE7QUFBRiIsImZpbGUiOiJ0YWIxLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5uby1nYXAge1xyXG4gIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcclxuICBtYXJnaW46IDAgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmxlZnQtdGV4dCB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIGJvdHRvbTogMjlweDtcclxuICB0b3A6IDEwcHg7XHJcbiAgbGVmdDogMTBweDtcclxuICBmb250LXdlaWdodDogODAwO1xyXG4gIGZvbnQtc2l6ZTogeC1zbWFsbDtcclxuICB0ZXh0LWFsaWduOiBsZWZ0ICFpbXBvcnRhbnQ7XHJcbiAgd2lkdGg6IGF1dG87XHJcbiAgY29sb3I6ICNmZmY7XHJcbn1cclxuXHJcbi50b3AtbmF2IHtcclxuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1ncmFkaWVudCk7XHJcbiAgcGFkZGluZy10b3A6IDI1cHggIWltcG9ydGFudDtcclxuICBwYWRkaW5nLXJpZ2h0OiAyNXB4ICFpbXBvcnRhbnQ7XHJcbiAgcGFkZGluZy1sZWZ0OiAyNXB4ICFpbXBvcnRhbnQ7XHJcbiAgcGFkZGluZy1ib3R0b206IDVweCAhaW1wb3J0YW50O1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICB3aWR0aDogMTAwJTtcclxuICB6LWluZGV4OiA5OTk7XHJcbn1cclxuXHJcbi5jYXRlZ29yaWVzLWdyaWQge1xyXG4gIHBhZGRpbmctdG9wOiA5MHB4ICFpbXBvcnRhbnQ7IFxyXG59XHJcblxyXG4uY2F0ZWdvcmllcy1yb3cge1xyXG4gIHdpZHRoOiAxMDBweDtcclxuICBoZWlnaHQ6IDEwMHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDZweDtcclxufVxyXG5cclxuLnRleHQtb2Zsb3ctc20ge1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICB3aWR0aDogMTM1cHg7XHJcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICBvdmVyZmxvdzogaGlkZGVuICFpbXBvcnRhbnQ7XHJcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XHJcbn1cclxuXHJcbi50ZXh0LW9mbG93LWxnIHtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgd2lkdGg6IDI4NXB4O1xyXG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgb3ZlcmZsb3c6IGhpZGRlbiAhaW1wb3J0YW50O1xyXG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xyXG59XHJcblxyXG4udGV4dC1vZmxvdy1tZCB7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gIHdpZHRoOiAxNTVweCAhaW1wb3J0YW50O1xyXG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgb3ZlcmZsb3c6IGhpZGRlbiAhaW1wb3J0YW50O1xyXG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xyXG59XHJcblxyXG4ueC1zbWFsbC1jYXJkIHtcclxuICB3aWR0aDogODBweCAhaW1wb3J0YW50O1xyXG4gIGhlaWdodDogODBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uc20tY2FyZHMge1xyXG4gIHdpZHRoOiAxNTBweDtcclxuICBoZWlnaHQ6IDI0MHB4O1xyXG4gIGJvcmRlcjogMnB4IHNvbGlkICNmOGY4Zjg7XHJcbn1cclxuXHJcbi5tZC1jYXJkcyB7XHJcbiAgd2lkdGg6IDMwMHB4O1xyXG4gIGhlaWdodDogNDAwcHg7XHJcbiAgYm9yZGVyOiAycHggc29saWQgI2Y4ZjhmODtcclxufVxyXG5cclxuLmxnLWNhcmRzIHtcclxuICB3aWR0aDogMzAwcHg7XHJcbiAgaGVpZ2h0OiAxOTBweDtcclxufVxyXG5cclxuLmNhcmQtYm9yZGVyIHtcclxuICBib3JkZXI6IDJweCBzb2xpZCAjZjhmOGY4O1xyXG59XHJcblxyXG4uY2FyZC1pbWFnZSB7XHJcbiAgcG9pbnRlci1ldmVudHM6IG5vbmU7XHJcbn1cclxuXHJcbi5ib3R0b20tYmFyLXBhZGRpbmcge1xyXG4gIHBhZGRpbmctYm90dG9tOiA4MHB4O1xyXG59XHJcblxyXG4ucm91bmQtZWRnZSB7XHJcbiAgYm9yZGVyLXJhZGl1czogOHB4ICFpbXBvcnRhbnQ7XHJcbiAgb3ZlcmZsb3c6IGhpZGRlbjsgICAgXHJcbiAgYm94LXNoYWRvdzogMHB4IDFweCA5cHggcmdiYSgwLCAwLCAwLCAwLjE1KSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uY2FyZC1oZWFkZXItYnRuIHtcclxuICBtYXJnaW46IDExcHg7XHJcbn1cclxuXHJcbi50ZXh0LW11dGVkIHtcclxuICBjb2xvcjogIzZjNzU3ZCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ueC1zbWFsbCB7XHJcbiAgZm9udC1zaXplOiB4LXNtYWxsO1xyXG59XHJcblxyXG4uc21hbGwge1xyXG4gIGZvbnQtc2l6ZTogc21hbGw7XHJcbn1cclxuLnh4LXNtYWxsIHtcclxuICBmb250LXNpemU6IHh4LXNtYWxsO1xyXG59XHJcblxyXG4ucGFkZGluZy1sLXItMHtcclxuICBwYWRkaW5nLWxlZnQ6IDBweCAhaW1wb3J0YW50O1xyXG4gIHBhZGRpbmctcmlnaHQ6IDBweCAhaW1wb3J0YW50O1xyXG4gIGhlaWdodDogMjYwcHg7XHJcblxyXG59XHJcblxyXG4ucHJldmlld193cmFwIHtcclxuICAvLyB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDIwMHB4O1xyXG4gIHBhZGRpbmc6IDA7XHJcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcclxufVxyXG4uZnJhbWVfd3JhcCB7XHJcbiAgd2lkdGg6IDEyODBweDtcclxuICBoZWlnaHQ6IDYwMHB4O1xyXG4gIGJvcmRlcjogMDtcclxuICAtbXMtdHJhbnNmb3JtOiBzY2FsZSgwLjMpO1xyXG4gIC1tb3otdHJhbnNmb3JtOiBzY2FsZSgwLjMpO1xyXG4gIC1vLXRyYW5zZm9ybTogc2NhbGUoMC4zKTtcclxuICAtd2Via2l0LXRyYW5zZm9ybTogc2NhbGUoMC4zKTtcclxuICB0cmFuc2Zvcm06IHNjYWxlKDAuMyk7XHJcblxyXG4gIC1tcy10cmFuc2Zvcm0tb3JpZ2luOiAwIDA7XHJcbiAgLW1vei10cmFuc2Zvcm0tb3JpZ2luOiAwIDA7XHJcbiAgLW8tdHJhbnNmb3JtLW9yaWdpbjogMCAwO1xyXG4gIC13ZWJraXQtdHJhbnNmb3JtLW9yaWdpbjogMCAwO1xyXG4gIHRyYW5zZm9ybS1vcmlnaW46IDAgMDtcclxufSJdfQ== */");

/***/ }),

/***/ "iwjE":
/*!**************************************************!*\
  !*** ./src/app/home/tab1/tab1-routing.module.ts ***!
  \**************************************************/
/*! exports provided: Tab1PageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab1PageRoutingModule", function() { return Tab1PageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./tab1.page */ "Fqdx");




const routes = [
    {
        path: '',
        component: _tab1_page__WEBPACK_IMPORTED_MODULE_3__["Tab1Page"],
    }
];
let Tab1PageRoutingModule = class Tab1PageRoutingModule {
};
Tab1PageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], Tab1PageRoutingModule);



/***/ }),

/***/ "kprM":
/*!********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/tab1/tab1.page.html ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content [fullscreen]=\"true\">\r\n\r\n  <!-- Nav Bar -->\r\n  <ion-grid class=\"top-nav\">\r\n    <ion-row\r\n      class=\"animate__animated animate__fadeIn animate__faster\"\r\n    >\r\n      <ion-col size=\"8\">\r\n        <ion-text color=\"light\">\r\n          {{ 'Hello' | translate }}, Karthikeyan!\r\n          <h1 class=\"no-gap\" color=\"dark\">{{ 'Welcome' | translate }}</h1>\r\n        </ion-text>\r\n      </ion-col>\r\n\r\n      <ion-col size=\"2\" class=\"ion-text-end\">\r\n        <ion-icon\r\n          size=\"large\"\r\n          color=\"light\"\r\n          (click)=\"doSearch()\"\r\n          name=\"search-outline\"\r\n        ></ion-icon>\r\n      </ion-col>\r\n      <ion-col size=\"2\" class=\"ion-text-end\" routerLink=\"/home/tabs/tab3\">\r\n        <ion-icon\r\n          size=\"large\"\r\n          color=\"light\"\r\n          name=\"bag-handle-outline\"\r\n        ></ion-icon>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n \r\n  </ion-grid>\r\n\r\n  <!-- Large Banners Card -->\r\n  <ion-grid class=\"padding-l-r-0 categories-grid animate__animated animate__fadeIn animate__faster\">\r\n    <!-- <ion-slides\r\n      autoplay=\"1000\"\r\n      [options]=\"{ slidesPerView: 'auto', zoom: false, grabCursor: true }\"\r\n    >\r\n      <ion-slide\r\n        *ngFor=\"let card of [2,1,0]\"\r\n        class=\"lg-cards\"\r\n        routerLink=\"/single-product-view\"\r\n      >\r\n        <ion-col>\r\n          <ion-img\r\n            class=\"card-image round-edge\"\r\n            src=\"../../../assets/products/banner{{card}}.png\"\r\n          ></ion-img>\r\n        </ion-col>\r\n      </ion-slide>\r\n    </ion-slides> -->\r\n    <div class=\"padding-l-r-0 tab-pane\" id=\"preview_site\">\r\n      <div class=\"preview_wrap\">\r\n          <iframe id=\"site_previewer\" class=\"frame_wrap\" src=\"https://grocery.simplystart.in/app-slider\" ></iframe>\r\n      </div>\r\n  </div>\r\n  </ion-grid>\r\n\r\n  <!-- Categories Grid -->\r\n  <ion-grid class=\"animate__animated animate__fadeIn animate__faster\" >\r\n    <ion-row>\r\n      <ion-col class=\"ion-padding-top\">\r\n        <ion-text color=\"dark\">\r\n          <h4 class=\"no-gap\">{{ 'TOP CATEGORIES' | translate }}</h4>\r\n        </ion-text>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <ion-slides\r\n      [options]=\"{ slidesPerView: 'auto', zoom: false, grabCursor: true }\"\r\n    >\r\n      <ion-slide\r\n        *ngFor=\"let category of categories; let i = index;\"\r\n        class=\"x-small-card\"\r\n      >\r\n        <ion-col routerLink=\"/product-list\">\r\n          <ion-img\r\n            class=\"card-image round-edge\"\r\n            [src]=\"category.src\"\r\n          ></ion-img>\r\n          <p class=\"ion-text-uppercase left-text no-gap\">{{ category.name }}</p>\r\n        </ion-col>\r\n      </ion-slide>\r\n    </ion-slides>\r\n  </ion-grid>\r\n\r\n  <!-- Small Products Card -->\r\n  <!-- <ion-grid class=\"animate__animated animate__fadeIn animate__faster\">\r\n    <!- - Card Title - ->\r\n    <ion-row>\r\n      <ion-col size=\"9\">\r\n        <ion-text color=\"dark\">\r\n          <h4 color=\"dark\">🔥 {{ 'Apple Thiruvizha' | translate }}!</h4>\r\n        </ion-text>\r\n      </ion-col>\r\n\r\n      <ion-col size=\"3\" class=\"ion-text-end\">\r\n        <ion-button\r\n          class=\"card-header-btn\"\r\n          routerLink=\"/product-list\"\r\n          color=\"primary\"\r\n          size=\"small\"\r\n          >{{ 'More' | translate }}</ion-button\r\n        >\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <!- - Card Slides -- >\r\n    <ion-slides\r\n      [options]=\"{ slidesPerView: 'auto', zoom: false, grabCursor: true }\"\r\n    >\r\n      <ion-slide\r\n        routerLink=\"/single-product-view\"\r\n        *ngFor=\"let mobile of mobiles\"\r\n        class=\"sm-cards\"\r\n      >\r\n        <ion-col>\r\n          <ion-img\r\n            class=\"card-image\"\r\n            src=\"{{ mobile?.productImage }}\"\r\n          ></ion-img>\r\n          <div class=\"ion-padding-top ion-padding-bottom\">\r\n            <h6 class=\"ion-text-start no-gap text-oflow-sm\">\r\n              {{ mobile?.shortName }}\r\n            </h6>\r\n            <small\r\n              class=\"ion-text-start no-gap text-oflow-sm text-muted x-small\"\r\n              >{{ mobile?.productName }}</small\r\n            >\r\n            <h6 class=\"ion-text-start small no-gap\" color=\"dark\">\r\n              ₹{{ mobile?.salesPrice }}\r\n\r\n              <small class=\"text-muted xx-small\"\r\n                ><del>₹{{ mobile?.regularPrice }}</del></small\r\n              >\r\n              <ion-text color=\"danger\"\r\n                ><b class=\"ion-float-right x-small\"\r\n                  >{{ mobile?.off }}% Off</b\r\n                ></ion-text\r\n              >\r\n            </h6>\r\n          </div>\r\n        </ion-col>\r\n      </ion-slide>\r\n    </ion-slides>\r\n  </ion-grid> -->\r\n\r\n  <!-- Medium Products Card -->\r\n  <ion-grid class=\"animate__animated animate__fadeIn animate__faster\" *ngIf=\"newArrivals && newArrivals.length > 0\">\r\n    <!-- Card Title -->\r\n    <ion-row>\r\n      <ion-col size=\"9\">\r\n        <ion-text color=\"dark\">\r\n          <h4 color=\"dark\">✨ {{ 'New Arrivals' | translate }}</h4>\r\n        </ion-text>\r\n      </ion-col>\r\n\r\n      <ion-col size=\"3\" class=\"ion-text-end\">\r\n        <ion-button\r\n          class=\"card-header-btn\"\r\n          routerLink=\"/product-list\"\r\n          color=\"primary\"\r\n          size=\"small\"\r\n          >{{ 'More' | translate }}</ion-button\r\n        >\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <ion-slides\r\n      [options]=\"{ slidesPerView: 'auto', zoom: false, grabCursor: true }\"\r\n    >\r\n      <ion-slide\r\n        *ngFor=\"let item of newArrivals\"\r\n        class=\"md-cards\"\r\n        [routerLink]=\"['/single-product-view',item.product_id]\"\r\n      >\r\n        <ion-col>\r\n          <ion-img class=\"card-image round-edge\" src=\"{{ item?.productImage }}\"></ion-img>\r\n          <div class=\"ion-padding-top\">\r\n            <h6 class=\"ion-text-start no-gap text-oflow-lg\">\r\n              {{ item?.shortName }}\r\n            </h6>\r\n            <small\r\n              class=\"ion-text-start no-gap text-oflow-lg text-muted x-small\"\r\n              >{{ item?.productName }}</small\r\n            >\r\n            <h6 class=\"ion-text-start no-gap\" color=\"dark\">\r\n              ₹{{ item?.salesPrice }}\r\n\r\n              <small class=\"text-muted x-small\"\r\n                ><del>₹{{ item?.regularPrice }}</del></small\r\n              >\r\n              <ion-text color=\"danger\"\r\n                ><b class=\"ion-float-right x-small\"\r\n                  >{{ item?.off }}% Off</b\r\n                ></ion-text\r\n              >\r\n            </h6>\r\n          </div>\r\n        </ion-col>\r\n      </ion-slide>\r\n    </ion-slides>\r\n  </ion-grid>\r\n\r\n  <!-- Large Banners Card -->\r\n  <ion-grid class=\"animate__animated animate__fadeIn animate__faster\">\r\n    <ion-slides\r\n      [options]=\"{ slidesPerView: 'auto', zoom: false, grabCursor: true }\"\r\n    >\r\n      <ion-slide\r\n        *ngFor=\"let card of [0,1,2]\"\r\n        class=\"lg-cards\"\r\n        routerLink=\"/single-product-view\"\r\n      >\r\n        <ion-col>\r\n          <ion-img\r\n            class=\"card-image round-edge\"\r\n            src=\"../../../assets/products/banner{{card}}.png\"\r\n          ></ion-img>\r\n        </ion-col>\r\n      </ion-slide>\r\n    </ion-slides>\r\n  </ion-grid>\r\n\r\n  <!-- Products Area -->\r\n\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col size=\"9\">\r\n        <ion-text color=\"dark\">\r\n          <h4 color=\"dark\">🍂 {{ 'Great Autumn Sale' | translate }}!</h4>\r\n        </ion-text>\r\n      </ion-col>\r\n\r\n      <ion-col size=\"3\" class=\"ion-text-end\">\r\n        <ion-button\r\n          class=\"card-header-btn\"\r\n          routerLink=\"/product-list\"\r\n          color=\"primary\"\r\n          size=\"small\"\r\n          >{{ 'More' | translate }}</ion-button\r\n        >\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <ion-row class=\"animate__animated animate__fadeIn animate__faster\">\r\n      <ion-col\r\n        size-xs=\"6\"\r\n        size-sm=\"6\"\r\n        size-md=\"3\"\r\n        size-lg=\"3\"\r\n        class=\"card-border\"\r\n        *ngFor=\"let product of products\"\r\n        [routerLink]=\"['/single-product-view',product.product_id]\"\r\n      >\r\n        <ion-img\r\n          class=\"card-image\"\r\n          src=\"{{ product?.productImage }}\"\r\n        ></ion-img>\r\n        <div class=\"ion-padding-top\">\r\n          <h6 class=\"ion-text-start no-gap text-oflow-md\">{{ product?.shortName }} }}</h6>\r\n          <small class=\"ion-text-start no-gap text-oflow-md text-muted x-small\"\r\n            >{{ product.name }}</small\r\n          >\r\n          <h6 class=\"ion-text-start no-gap\" color=\"dark\">\r\n            ₹{{ product?.regularPrice }}\r\n\r\n            <small class=\"text-muted\"><del>₹{{ product?.salesPrice }}</del></small>\r\n            <ion-text color=\"danger\"\r\n              ><b class=\"ion-float-right small\">{{ product?.off }}% Off</b></ion-text\r\n            >\r\n          </h6>\r\n        </div>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <!-- Products Area -->\r\n<!-- \r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col size=\"9\">\r\n        <ion-text color=\"dark\">\r\n          <h4 color=\"dark\">{{ 'Trendy Fashion Sale' | translate }}</h4>\r\n        </ion-text>\r\n      </ion-col>\r\n\r\n      <ion-col size=\"3\" class=\"ion-text-end\">\r\n        <ion-button\r\n          class=\"card-header-btn\"\r\n          routerLink=\"/product-list\"\r\n          color=\"primary\"\r\n          size=\"small\"\r\n          >{{ 'More' | translate }}</ion-button\r\n        >\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <ion-row class=\"animate__animated animate__fadeIn animate__faster\">\r\n      <ion-col\r\n        size-xs=\"6\"\r\n        size-sm=\"6\"\r\n        size-md=\"3\"\r\n        size-lg=\"3\"\r\n        class=\"card-border\"\r\n        *ngFor=\"let card of [0,1,2,3,4,5]\"\r\n        routerLink=\"/single-product-view\"\r\n      >\r\n        <ion-img\r\n          class=\"card-image\"\r\n          src=\"../../../assets/products/{{card}}.png\"\r\n        ></ion-img>\r\n        <div class=\"ion-padding-top\">\r\n          <h6 class=\"ion-text-start no-gap text-oflow-md\">{{ 'Product' | translate }} #{{card}}</h6>\r\n          <small class=\"ion-text-start no-gap text-oflow-md text-muted x-small\"\r\n            >{{ 'Product' | translate }} {{ card }}</small\r\n          >\r\n          <h6 class=\"ion-text-start no-gap\" color=\"dark\">\r\n            ₹11{{ card }}\r\n\r\n            <small class=\"text-muted\"><del>₹112{{ card }}</del></small>\r\n            <ion-text color=\"danger\"\r\n              ><b class=\"ion-float-right small\">5{{ card }}% Off</b></ion-text\r\n            >\r\n          </h6>\r\n        </div>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid> -->\r\n</ion-content>\r\n\r\n<!-- <div class=\"bottom-bar-padding\"></div> -->\r\n");

/***/ }),

/***/ "xSnB":
/*!******************************************!*\
  !*** ./src/app/home/tab1/tab1.module.ts ***!
  \******************************************/
/*! exports provided: Tab1PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab1PageModule", function() { return Tab1PageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./tab1.page */ "Fqdx");
/* harmony import */ var _tab1_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tab1-routing.module */ "iwjE");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");








let Tab1PageModule = class Tab1PageModule {
};
Tab1PageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _tab1_routing_module__WEBPACK_IMPORTED_MODULE_6__["Tab1PageRoutingModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"]
        ],
        declarations: [_tab1_page__WEBPACK_IMPORTED_MODULE_5__["Tab1Page"]]
    })
], Tab1PageModule);



/***/ })

}]);
//# sourceMappingURL=tab1-tab1-module-es2015.js.map