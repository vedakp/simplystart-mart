(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["product-list-product-list-module"],{

/***/ "AByV":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/product-list/product-list.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-item>\r\n    <ion-label class=\"ion-padding\">\r\n      <h1>{{ categoryTitle | translate }}</h1>\r\n    </ion-label>\r\n    <ion-icon\r\n      class=\"ion-text-right\"\r\n      slot=\"end\"\r\n      color=\"dark\"\r\n      name=\"bag-handle-outline\"\r\n    >\r\n    </ion-icon>\r\n  </ion-item>\r\n</ion-header>\r\n\r\n<ion-content scroll=\"false\" no-padding>\r\n\r\n  <ion-grid>\r\n    <ion-row class=\"animate__animated animate__fadeIn animate__faster\">\r\n      <ion-col\r\n        size-xs=\"6\"\r\n        size-sm=\"6\"\r\n        size-md=\"3\"\r\n        size-lg=\"3\"\r\n        class=\"card-border\"\r\n        *ngFor=\"let card of [0,1,2,3,4,5,6]\"\r\n        routerLink=\"/single-product-view\"\r\n      >\r\n        <ion-img\r\n          class=\"card-image\"\r\n          src=\"../../../assets/products/item_{{card}}.png\"\r\n        ></ion-img>\r\n        <div class=\"ion-padding-top\">\r\n          <h6 class=\"ion-text-start no-gap text-oflow-md\">\r\n            {{ 'Product' | translate }}\r\n          </h6>\r\n          <small class=\"ion-text-start no-gap text-oflow-md text-muted x-small\"\r\n            >{{ 'Product' | translate }} #{{ card }}</small\r\n          >\r\n          <h6 class=\"ion-text-start no-gap\" color=\"dark\">\r\n            ₹141{{ card }}\r\n\r\n            <small class=\"text-muted\"><del>₹119{{ card }}</del></small>\r\n            <ion-text color=\"danger\"\r\n              ><b class=\"ion-float-right small\">5{{ card }}% Off</b></ion-text\r\n            >\r\n          </h6>\r\n        </div>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <ion-fab vertical=\"bottom\" horizontal=\"end\" (click)=\"doFilter()\" slot=\"fixed\">\r\n    <ion-fab-button color=\"dark\">\r\n      <ion-icon name=\"filter-outline\"></ion-icon>\r\n    </ion-fab-button>\r\n  </ion-fab>\r\n</ion-content>\r\n");

/***/ }),

/***/ "b6OO":
/*!*****************************************************!*\
  !*** ./src/app/product-list/product-list.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".text-oflow-md {\n  display: inline-block;\n  width: 155px !important;\n  white-space: nowrap;\n  overflow: hidden !important;\n  text-overflow: ellipsis;\n}\n\n.no-gap {\n  padding: 0 !important;\n  margin: 0 !important;\n}\n\n.text-muted {\n  color: #6c757d !important;\n}\n\n.x-small {\n  font-size: x-small;\n}\n\n.small {\n  font-size: small;\n}\n\n.card-border {\n  border: 2px solid #f8f8f8;\n}\n\n.card-image {\n  pointer-events: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3Byb2R1Y3QtbGlzdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxxQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSwyQkFBQTtFQUNBLHVCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxxQkFBQTtFQUNBLG9CQUFBO0FBQ0Y7O0FBQ0E7RUFDRSx5QkFBQTtBQUVGOztBQUFBO0VBQ0Usa0JBQUE7QUFHRjs7QUFBQTtFQUNFLGdCQUFBO0FBR0Y7O0FBQUE7RUFDRSx5QkFBQTtBQUdGOztBQUFBO0VBQ0Usb0JBQUE7QUFHRiIsImZpbGUiOiJwcm9kdWN0LWxpc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRleHQtb2Zsb3ctbWQge1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICB3aWR0aDogMTU1cHggIWltcG9ydGFudDtcclxuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xyXG4gIG92ZXJmbG93OiBoaWRkZW4gIWltcG9ydGFudDtcclxuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcclxufVxyXG5cclxuLm5vLWdhcCB7XHJcbiAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xyXG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xyXG59XHJcbi50ZXh0LW11dGVkIHtcclxuICBjb2xvcjogIzZjNzU3ZCAhaW1wb3J0YW50O1xyXG59XHJcbi54LXNtYWxsIHtcclxuICBmb250LXNpemU6IHgtc21hbGw7XHJcbn1cclxuXHJcbi5zbWFsbCB7XHJcbiAgZm9udC1zaXplOiBzbWFsbDtcclxufVxyXG5cclxuLmNhcmQtYm9yZGVyIHtcclxuICBib3JkZXI6IDJweCBzb2xpZCAjZjhmOGY4O1xyXG59XHJcblxyXG4uY2FyZC1pbWFnZSB7XHJcbiAgcG9pbnRlci1ldmVudHM6IG5vbmU7XHJcbiAgLy8gYm9yZGVyLXJhZGl1czogMThweDtcclxuICAvLyBib3gtc2hhZG93OiAwIDEwcHggMTVweCAtM3B4IHJnYmEoMCwgMCwgMCwgMC4xKSwgMCA0cHggNnB4IC0ycHggcmdiYSgwLCAwLCAwLCAwLjA1KTtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "bj+n":
/*!*****************************************************!*\
  !*** ./src/app/product-list/product-list.module.ts ***!
  \*****************************************************/
/*! exports provided: ProductListPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductListPageModule", function() { return ProductListPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _product_list_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./product-list-routing.module */ "blOi");
/* harmony import */ var _product_list_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./product-list.page */ "lvsR");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");








let ProductListPageModule = class ProductListPageModule {
};
ProductListPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _product_list_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProductListPageRoutingModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"]
        ],
        declarations: [_product_list_page__WEBPACK_IMPORTED_MODULE_6__["ProductListPage"]]
    })
], ProductListPageModule);



/***/ }),

/***/ "blOi":
/*!*************************************************************!*\
  !*** ./src/app/product-list/product-list-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: ProductListPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductListPageRoutingModule", function() { return ProductListPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _product_list_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./product-list.page */ "lvsR");




const routes = [
    {
        path: '',
        component: _product_list_page__WEBPACK_IMPORTED_MODULE_3__["ProductListPage"]
    }
];
let ProductListPageRoutingModule = class ProductListPageRoutingModule {
};
ProductListPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ProductListPageRoutingModule);



/***/ }),

/***/ "lvsR":
/*!***************************************************!*\
  !*** ./src/app/product-list/product-list.page.ts ***!
  \***************************************************/
/*! exports provided: ProductListPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductListPage", function() { return ProductListPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_product_list_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./product-list.page.html */ "AByV");
/* harmony import */ var _product_list_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./product-list.page.scss */ "b6OO");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");





let ProductListPage = class ProductListPage {
    constructor(actionSheetController) {
        this.actionSheetController = actionSheetController;
        this.categoryTitle = "Fashion";
    }
    ngOnInit() { }
    doFilter() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                header: "Sort by",
                buttons: [
                    {
                        text: "Featured Products",
                        icon: "funnel-outline",
                        handler: () => {
                            console.log("Sort by: Featured");
                        },
                    },
                    {
                        text: "Price High to Low",
                        icon: "trending-down-outline",
                        handler: () => {
                            console.log("Sort by: Price High to Low");
                        },
                    },
                    {
                        text: "Price Low to High",
                        icon: "trending-up-outline",
                        handler: () => {
                            console.log("Sort by: Price Low to High");
                        },
                    },
                    {
                        text: "Cancel",
                        icon: "close",
                        role: "cancel",
                        handler: () => {
                            console.log("Cancelled");
                        },
                    },
                ],
            });
            yield actionSheet.present();
        });
    }
};
ProductListPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ActionSheetController"] }
];
ProductListPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-product-list",
        template: _raw_loader_product_list_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_product_list_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ProductListPage);



/***/ })

}]);
//# sourceMappingURL=product-list-product-list-module-es2015.js.map