(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["order-failed-order-failed-module"],{

/***/ "SQ0v":
/*!*************************************************************!*\
  !*** ./src/app/order-failed/order-failed-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: OrderFailedPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderFailedPageRoutingModule", function() { return OrderFailedPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _order_failed_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./order-failed.page */ "e8SF");




const routes = [
    {
        path: '',
        component: _order_failed_page__WEBPACK_IMPORTED_MODULE_3__["OrderFailedPage"]
    }
];
let OrderFailedPageRoutingModule = class OrderFailedPageRoutingModule {
};
OrderFailedPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], OrderFailedPageRoutingModule);



/***/ }),

/***/ "e8SF":
/*!***************************************************!*\
  !*** ./src/app/order-failed/order-failed.page.ts ***!
  \***************************************************/
/*! exports provided: OrderFailedPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderFailedPage", function() { return OrderFailedPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_order_failed_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./order-failed.page.html */ "hvRn");
/* harmony import */ var _order_failed_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./order-failed.page.scss */ "gBJv");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let OrderFailedPage = class OrderFailedPage {
    constructor() { }
    ngOnInit() {
    }
};
OrderFailedPage.ctorParameters = () => [];
OrderFailedPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-order-failed',
        template: _raw_loader_order_failed_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_order_failed_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], OrderFailedPage);



/***/ }),

/***/ "gBJv":
/*!*****************************************************!*\
  !*** ./src/app/order-failed/order-failed.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".empty-cart img {\n  display: block;\n  margin: 0 auto;\n  margin-top: 8vh;\n}\n\nimg {\n  height: auto;\n  width: 35%;\n}\n\n.text-muted {\n  color: #6c757d !important;\n}\n\n.bottom-bar {\n  position: fixed;\n  width: 100%;\n  bottom: 0;\n  background-color: #ffffff;\n  z-index: 999;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL29yZGVyLWZhaWxlZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7QUFDRjs7QUFFQTtFQUNFLFlBQUE7RUFDQSxVQUFBO0FBQ0Y7O0FBRUE7RUFDRSx5QkFBQTtBQUNGOztBQUVBO0VBQ0UsZUFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0FBQ0YiLCJmaWxlIjoib3JkZXItZmFpbGVkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5lbXB0eS1jYXJ0IGltZyB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgbWFyZ2luOiAwIGF1dG87XHJcbiAgbWFyZ2luLXRvcDogOHZoO1xyXG59XHJcblxyXG5pbWcge1xyXG4gIGhlaWdodDogYXV0bztcclxuICB3aWR0aDogMzUlO1xyXG59XHJcblxyXG4udGV4dC1tdXRlZCB7XHJcbiAgY29sb3I6ICM2Yzc1N2QgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmJvdHRvbS1iYXIge1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICB3aWR0aDogMTAwJTtcclxuICBib3R0b206IDA7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcclxuICB6LWluZGV4OiA5OTk7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ "hvRn":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/order-failed/order-failed.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content class=\"ion-padding\">\r\n  <ion-grid\r\n    class=\"ion-padding animate__animated animate__fadeIn animate__faster\"\r\n  >\r\n    <div class=\"empty-cart\">\r\n      <img src=\"../../assets/failed.gif\" alt=\"\" />\r\n      <h4 class=\"ion-text-center\">{{ 'Oops! Something went wrong.' | translate }}</h4>\r\n    </div>\r\n  </ion-grid>\r\n\r\n  <ion-grid\r\n    class=\"ion-text-center animate__animated animate__fadeIn animate__faster\"\r\n  >\r\n    <p class=\"text-muted\">\r\n      {{ 'Sorry for the inconvenience, Please try again to place your order.' | translate }}\r\n    </p>\r\n  </ion-grid>\r\n</ion-content>\r\n\r\n<div class=\"bottom-bar\">\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col size=\"6\">\r\n        <ion-button\r\n          expand=\"full\"\r\n          size=\"default\"\r\n          routerLink=\"/home/tabs/tab3\"\r\n          color=\"primary\"\r\n          >{{ 'Retry' | translate }}</ion-button\r\n        >\r\n      </ion-col>\r\n\r\n      <ion-col size=\"6\">\r\n        <ion-button\r\n          expand=\"full\"\r\n          size=\"default\"\r\n          routerLink=\"/home\"\r\n          color=\"tertiary\"\r\n          >{{ 'Goto Home' | translate }}</ion-button\r\n        >\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</div>\r\n");

/***/ }),

/***/ "oK0y":
/*!*****************************************************!*\
  !*** ./src/app/order-failed/order-failed.module.ts ***!
  \*****************************************************/
/*! exports provided: OrderFailedPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderFailedPageModule", function() { return OrderFailedPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _order_failed_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./order-failed-routing.module */ "SQ0v");
/* harmony import */ var _order_failed_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./order-failed.page */ "e8SF");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");








let OrderFailedPageModule = class OrderFailedPageModule {
};
OrderFailedPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _order_failed_routing_module__WEBPACK_IMPORTED_MODULE_5__["OrderFailedPageRoutingModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"]
        ],
        declarations: [_order_failed_page__WEBPACK_IMPORTED_MODULE_6__["OrderFailedPage"]]
    })
], OrderFailedPageModule);



/***/ })

}]);
//# sourceMappingURL=order-failed-order-failed-module-es2015.js.map