(function () {
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["order-success-order-success-module"], {
    /***/
    "60ou":
    /*!*********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/order-success/order-success.page.html ***!
      \*********************************************************************************************/

    /*! exports provided: default */

    /***/
    function ou(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-content class=\"ion-padding\">\r\n  <ion-grid\r\n    class=\"ion-padding animate__animated animate__fadeIn animate__faster\"\r\n  >\r\n    <div class=\"empty-cart\">\r\n      <img src=\"../../assets/success.gif\" alt=\"\" />\r\n      <h3 class=\"ion-text-center\">{{ 'Your order was placed successfully' | translate }}!</h3>\r\n    </div>\r\n  </ion-grid>\r\n\r\n  <ion-grid\r\n    class=\"ion-padding animate__animated animate__slideInUp animate__faster\"\r\n  >\r\n    <h6 class=\"text-muted\">\r\n      {{ 'Your order will be delivered by' | translate }} Fri 01, Nov 2020.\r\n    </h6>\r\n    <p class=\"text-muted\">{{ 'Order ID' | translate }}: ODR00124212150FF42</p>\r\n    <br />\r\n    <p class=\"text-muted\">{{ 'Thank you for choosing GoMart' | translate }}!</p>\r\n  </ion-grid>\r\n\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col size=\"6\">\r\n        <ion-button expand=\"full\" routerLink=\"/my-orders\" color=\"primary\"\r\n          >{{ 'My Orders' | translate }}</ion-button\r\n        >\r\n      </ion-col>\r\n\r\n      <ion-col size=\"6\">\r\n        <ion-button expand=\"full\" routerLink=\"/home\" color=\"tertiary\"\r\n          >{{ 'Shop more' | translate }}</ion-button\r\n        >\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-content>\r\n\r\n<div class=\"bottom-bar\">\r\n  <ion-grid size=\"12\">\r\n    <ion-button\r\n      expand=\"full\"\r\n      size=\"large\"\r\n      routerLink=\"/track-order\"\r\n      color=\"dark\"\r\n      >{{ 'Track Order' | translate }}</ion-button\r\n    >\r\n  </ion-grid>\r\n</div>\r\n";
      /***/
    },

    /***/
    "cp09":
    /*!*******************************************************!*\
      !*** ./src/app/order-success/order-success.page.scss ***!
      \*******************************************************/

    /*! exports provided: default */

    /***/
    function cp09(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".empty-cart img {\n  display: block;\n  margin: 0 auto;\n  margin-top: 8vh;\n}\n\nimg {\n  height: auto;\n  width: 45%;\n}\n\n.text-muted {\n  color: #6c757d !important;\n}\n\n.bottom-bar {\n  position: fixed;\n  width: 100%;\n  bottom: 0;\n  background-color: #ffffff;\n  z-index: 999;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL29yZGVyLXN1Y2Nlc3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsY0FBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBRUE7RUFDRSxZQUFBO0VBQ0EsVUFBQTtBQUNGOztBQUVBO0VBQ0UseUJBQUE7QUFDRjs7QUFFQTtFQUNFLGVBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtBQUNGIiwiZmlsZSI6Im9yZGVyLXN1Y2Nlc3MucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmVtcHR5LWNhcnQgaW1nIHtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICBtYXJnaW46IDAgYXV0bztcclxuICBtYXJnaW4tdG9wOiA4dmg7XHJcbn1cclxuXHJcbmltZyB7XHJcbiAgaGVpZ2h0OiBhdXRvO1xyXG4gIHdpZHRoOiA0NSU7XHJcbn1cclxuXHJcbi50ZXh0LW11dGVkIHtcclxuICBjb2xvcjogIzZjNzU3ZCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYm90dG9tLWJhciB7XHJcbiAgcG9zaXRpb246IGZpeGVkO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGJvdHRvbTogMDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xyXG4gIHotaW5kZXg6IDk5OTtcclxufVxyXG4iXX0= */";
      /***/
    },

    /***/
    "gc0W":
    /*!*****************************************************!*\
      !*** ./src/app/order-success/order-success.page.ts ***!
      \*****************************************************/

    /*! exports provided: OrderSuccessPage */

    /***/
    function gc0W(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "OrderSuccessPage", function () {
        return OrderSuccessPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_order_success_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./order-success.page.html */
      "60ou");
      /* harmony import */


      var _order_success_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./order-success.page.scss */
      "cp09");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var OrderSuccessPage = /*#__PURE__*/function () {
        function OrderSuccessPage() {
          _classCallCheck(this, OrderSuccessPage);
        }

        _createClass(OrderSuccessPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return OrderSuccessPage;
      }();

      OrderSuccessPage.ctorParameters = function () {
        return [];
      };

      OrderSuccessPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-order-success',
        template: _raw_loader_order_success_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_order_success_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], OrderSuccessPage);
      /***/
    },

    /***/
    "sYBs":
    /*!*******************************************************!*\
      !*** ./src/app/order-success/order-success.module.ts ***!
      \*******************************************************/

    /*! exports provided: OrderSuccessPageModule */

    /***/
    function sYBs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "OrderSuccessPageModule", function () {
        return OrderSuccessPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _order_success_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./order-success-routing.module */
      "zZWP");
      /* harmony import */


      var _order_success_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./order-success.page */
      "gc0W");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @ngx-translate/core */
      "sYmb");

      var OrderSuccessPageModule = function OrderSuccessPageModule() {
        _classCallCheck(this, OrderSuccessPageModule);
      };

      OrderSuccessPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _order_success_routing_module__WEBPACK_IMPORTED_MODULE_5__["OrderSuccessPageRoutingModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"]],
        declarations: [_order_success_page__WEBPACK_IMPORTED_MODULE_6__["OrderSuccessPage"]]
      })], OrderSuccessPageModule);
      /***/
    },

    /***/
    "zZWP":
    /*!***************************************************************!*\
      !*** ./src/app/order-success/order-success-routing.module.ts ***!
      \***************************************************************/

    /*! exports provided: OrderSuccessPageRoutingModule */

    /***/
    function zZWP(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "OrderSuccessPageRoutingModule", function () {
        return OrderSuccessPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _order_success_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./order-success.page */
      "gc0W");

      var routes = [{
        path: '',
        component: _order_success_page__WEBPACK_IMPORTED_MODULE_3__["OrderSuccessPage"]
      }];

      var OrderSuccessPageRoutingModule = function OrderSuccessPageRoutingModule() {
        _classCallCheck(this, OrderSuccessPageRoutingModule);
      };

      OrderSuccessPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], OrderSuccessPageRoutingModule);
      /***/
    }
  }]);
})();
//# sourceMappingURL=order-success-order-success-module-es5.js.map