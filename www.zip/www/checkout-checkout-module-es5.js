(function () {
  function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

  function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

  function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["checkout-checkout-module"], {
    /***/
    "/6ko":
    /*!***********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/checkout/checkout.page.html ***!
      \***********************************************************************************/

    /*! exports provided: default */

    /***/
    function ko(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-item>\r\n  <ion-label class=\"ion-padding\">\r\n    <h1>{{ 'Order Checkout' | translate }}</h1>\r\n  </ion-label>\r\n</ion-item>\r\n\r\n<ion-content [fullscreen]=\"true\">\r\n  <div class=\"cart\" *ngIf=\"cart.length > 0\">\r\n    <ion-grid class=\"ion-padding\">\r\n      <h4>{{ 'Delivery Address' | translate }}</h4>\r\n    </ion-grid>\r\n\r\n    <ion-list class=\"animate__animated animate__fadeIn animate__faster\">\r\n      <ion-radio-group value=\"address\">\r\n        <ion-item>\r\n          <ion-label\r\n            ><small class=\"ion-text-uppercase text-muted\">{{ 'HOME' | translate }}</small>\r\n            <h2>Mr. Surendhar</h2>\r\n            <h3>849 Koontz Lane</h3>\r\n            <p>Burbank, California - 91502</p>\r\n            <p>+1 818-840-1357</p>\r\n          </ion-label>\r\n          <ion-radio slot=\"start\" color=\"dark\" value=\"address_1\"></ion-radio>\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label\r\n            ><small class=\"ion-text-uppercase text-muted\">{{ 'WORK' | translate }}</small>\r\n            <h2>Mr. Karthikeyan</h2>\r\n            <h3>866 Tannie Way</h3>\r\n            <p>Burbank, California - 91502</p>\r\n            <p>+1 818-123-7745</p>\r\n          </ion-label>\r\n          <ion-radio slot=\"start\" color=\"dark\" value=\"address_2\"></ion-radio>\r\n        </ion-item>\r\n      </ion-radio-group>\r\n    </ion-list>\r\n\r\n    <ion-grid class=\"ion-padding\">\r\n      <h4>{{ 'Item(s) in cart' | translate }}</h4>\r\n    </ion-grid>\r\n\r\n    <ion-list class=\"animate__animated animate__fadeIn animate__faster\">\r\n      <ion-item *ngFor=\"let item of cart; let i=index;\">\r\n        <ion-grid>\r\n          <ion-row>\r\n            <ion-col size=\"3\">\r\n              <img class=\"cart-image\" src=\"{{ item?.productImage }}\" />\r\n              <small class=\"ion-text-uppercase text-muted\">\r\n                Qty: {{ item?.quantity }}</small\r\n              >\r\n            </ion-col>\r\n            <ion-col size=\"6\">\r\n              <h6 class=\"text-oflow-lg no-gap\">{{ item?.shortName }}</h6>\r\n              <p class=\"text-oflow-lg text-muted no-gap\">{{ item?.brand }}</p>\r\n            </ion-col>\r\n            <ion-col size=\"3\" class=\"ion-text-right\">\r\n              <ion-icon\r\n                class=\"ion-text-right text-muted ion-margin-bottom\"\r\n                (click)=\"removeFromCart(i)\"\r\n                name=\"trash-outline\"\r\n              ></ion-icon>\r\n\r\n              <p\r\n                class=\"ion-text-uppercase no-gap x-small ion-margin-top text-muted\"\r\n              >\r\n                {{ item?.salesPrice }} X {{ item?.quantity }}\r\n              </p>\r\n              <h6 class=\"ion-text-right no-gap\">\r\n                ₹ {{ item?.salesPrice*item?.quantity }}\r\n              </h6>\r\n            </ion-col>\r\n          </ion-row>\r\n        </ion-grid>\r\n      </ion-item>\r\n    </ion-list>\r\n\r\n    <ion-grid\r\n      class=\"ion-padding animate__animated animate__fadeIn animate__faster\"\r\n    >\r\n      <ion-row>\r\n        <ion-col size=\"9\" class=\"ion-text-right\">\r\n          <small class=\"text-muted ion-text-uppercase no-gap\">{{ 'Subtotal' | translate }}</small>\r\n        </ion-col>\r\n        <ion-col size=\"3\" class=\"ion-text-right\"> ₹ {{ totalCost }} </ion-col>\r\n      </ion-row>\r\n\r\n      <ion-row>\r\n        <ion-col size=\"9\" class=\"ion-text-right\">\r\n          <small class=\"text-muted ion-text-uppercase no-gap\"\r\n            >{{ 'Shipping Charge' | translate }}</small\r\n          >\r\n        </ion-col>\r\n        <ion-col size=\"3\" class=\"ion-text-right\">\r\n          ₹ {{ shippingCost }}\r\n        </ion-col>\r\n      </ion-row>\r\n\r\n      <ion-row>\r\n        <ion-col size=\"9\" class=\"ion-text-right\">\r\n          <small class=\"text-muted ion-text-uppercase no-gap\"\r\n            >{{ 'Grand Total' | translate }}</small\r\n          >\r\n        </ion-col>\r\n        <ion-col size=\"3\" class=\"ion-text-right\"> ₹ {{ grandTotal }} </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n\r\n    <ion-grid class=\"ion-padding\">\r\n      <h4>{{ 'Payment method' | translate }}</h4>\r\n      <ion-list>\r\n        <ion-radio-group value=\"pay_mode\">\r\n          <ion-item>\r\n            <ion-label> <h4>Cash on delivery</h4> </ion-label>\r\n            <ion-radio slot=\"start\" color=\"dark\" value=\"cod\"></ion-radio>\r\n          </ion-item>\r\n          <ion-item>\r\n            <ion-label> <h4>Netbanking</h4> </ion-label>\r\n            <ion-radio slot=\"start\" color=\"dark\" value=\"netbanking\"></ion-radio>\r\n          </ion-item>\r\n          <ion-item>\r\n            <ion-label> <h4>PayPal</h4> </ion-label>\r\n            <ion-radio slot=\"start\" color=\"dark\" value=\"paytm\"></ion-radio>\r\n          </ion-item>\r\n        </ion-radio-group>\r\n      </ion-list>\r\n    </ion-grid>\r\n\r\n    <div class=\"bottom-bar\">\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col size=\"6\">\r\n            <small class=\"text-muted ion-text-uppercase no-gap\"\r\n              >{{ 'Grand Total' | translate }}</small\r\n            >\r\n            <ion-text color=\"dark\"\r\n              ><h4 class=\"no-gap\">₹ {{ grandTotal }}</h4></ion-text\r\n            >\r\n          </ion-col>\r\n\r\n          <ion-col size=\"6\">\r\n            <ion-button\r\n              color=\"primary\"\r\n              routerLink=\"/order-validate\"\r\n              class=\"ion-text-uppercase\"\r\n              size=\"default\"\r\n              expand=\"block\"\r\n              >{{ 'Place Order' | translate }}</ion-button\r\n            >\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </div>\r\n  </div>\r\n\r\n  <div\r\n    class=\"empty-cart animate__animated animate__fadeIn animate__faster\"\r\n    *ngIf=\"cart.length == 0\"\r\n  >\r\n    <img src=\"../../../assets/empty-cart.svg\" alt=\"\" />\r\n    <h4 class=\"text-muted ion-text-center\">{{ 'Sorry! your cart is empty' | translate }} :(</h4>\r\n    <br />\r\n    <div class=\"ion-text-center\">\r\n      <ion-button\r\n        color=\"primary\"\r\n        routerLink=\"/home\"\r\n        class=\"ion-text-uppercase\"\r\n        shape=\"round\"\r\n        >{{ 'Start Shopping' | translate }}</ion-button\r\n      >\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"bottom-space\"></div>\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "8y03":
    /*!*********************************************!*\
      !*** ./src/app/checkout/checkout.module.ts ***!
      \*********************************************/

    /*! exports provided: CheckoutPageModule */

    /***/
    function y03(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CheckoutPageModule", function () {
        return CheckoutPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _checkout_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./checkout-routing.module */
      "v3IU");
      /* harmony import */


      var _checkout_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./checkout.page */
      "E2Rb");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @ngx-translate/core */
      "sYmb");

      var CheckoutPageModule = function CheckoutPageModule() {
        _classCallCheck(this, CheckoutPageModule);
      };

      CheckoutPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _checkout_routing_module__WEBPACK_IMPORTED_MODULE_5__["CheckoutPageRoutingModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"]],
        declarations: [_checkout_page__WEBPACK_IMPORTED_MODULE_6__["CheckoutPage"]]
      })], CheckoutPageModule);
      /***/
    },

    /***/
    "E2Rb":
    /*!*******************************************!*\
      !*** ./src/app/checkout/checkout.page.ts ***!
      \*******************************************/

    /*! exports provided: CheckoutPage */

    /***/
    function E2Rb(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CheckoutPage", function () {
        return CheckoutPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_checkout_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./checkout.page.html */
      "/6ko");
      /* harmony import */


      var _checkout_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./checkout.page.scss */
      "pA2R");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");

      var CheckoutPage = /*#__PURE__*/function () {
        function CheckoutPage(toastController, alertController) {
          _classCallCheck(this, CheckoutPage);

          this.toastController = toastController;
          this.alertController = alertController;
          this.totalCost = 0;
          this.grandTotal = 0;
          this.shippingCost = 45;
          this.cart = [{
            "product_id": 1,
            "productImage": "https://m.media-amazon.com/images/S/aplus-media/sota/39ed8e8d-01b0-4d86-8cb0-305b4869bb48.__CR288,248,496,496_PT0_SX300_V1___.jpg",
            "productName": "Women Fashion Handbags Tote Bag Shoulder Bag",
            "brand": "Bagger IN",
            "shortName": "Women Fashion Handbag",
            "off": 15,
            "quantity": 1,
            "productLongDescription": "A14 Bionic, the fastest chip in a smartphone. An edge-to-edge OLED display. Ceramic Shield with four times better drop performance. And Night mode on every camera. iPhone 12 has it all — in two perfect sizes.",
            "productShortDescription": "A14 Bionic, the fastest chip in a smartphone. An edge-to-edge OLED display.",
            "regularPrice": 980,
            "salesPrice": 850
          }, {
            "product_id": 2,
            "productImage": "https://i.pinimg.com/474x/b5/b4/e0/b5b4e08c1b97e8ed0c403bebda20d789.jpg",
            "productName": "Halife Women's Long Sleeve Boat Neck Off Shoulder Blouse Tops",
            "brand": "Halife US",
            "off": 45,
            "quantity": 2,
            "shortName": "Women's Long Sleeve",
            "productLongDescription": "A14 Bionic rockets past every other smartphone chip. The Pro camera system takes low-light photography to the next level — with an even bigger jump on iPhone 12 Pro Max. And Ceramic Shield delivers four times better drop performance. Let’s see what this thing can do.",
            "productShortDescription": "A14 Bionic rockets past every other smartphone chip.",
            "regularPrice": 1200,
            "salesPrice": 999
          }];
        }

        _createClass(CheckoutPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.doTotalCalculation();
          }
        }, {
          key: "lessQty",
          value: function lessQty(index) {
            if (this.cart[index].quantity > 0) {
              this.cart[index].quantity = this.cart[index].quantity - 1;
              this.doTotalCalculation();
            }

            if (this.cart[index].quantity == 0) {
              this.removeFromCart(index);
            }
          }
        }, {
          key: "addQty",
          value: function addQty(index) {
            if (this.cart[index].quantity >= 0 && this.cart[index].quantity <= 25) {
              this.cart[index].quantity = this.cart[index].quantity + 1;
            }

            this.doTotalCalculation();
          }
        }, {
          key: "doTotalCalculation",
          value: function doTotalCalculation() {
            this.totalCost = 0;
            this.grandTotal = 0;

            var _iterator = _createForOfIteratorHelper(this.cart),
                _step;

            try {
              for (_iterator.s(); !(_step = _iterator.n()).done;) {
                var item = _step.value;
                this.totalCost += item.salesPrice * item.quantity;
              }
            } catch (err) {
              _iterator.e(err);
            } finally {
              _iterator.f();
            }

            this.grandTotal = this.shippingCost + this.totalCost;
          }
        }, {
          key: "removeFromCart",
          value: function removeFromCart(i) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.alertController.create({
                        header: 'Do you want to remove this item?',
                        buttons: [{
                          text: 'Cancel',
                          role: 'cancel',
                          cssClass: 'secondary',
                          handler: function handler() {
                            console.log('Action cancelled');
                          }
                        }, {
                          text: 'Yes!',
                          handler: function handler() {
                            _this.toastAlert("Item removed from cart.", i);
                          }
                        }]
                      });

                    case 2:
                      alert = _context.sent;
                      _context.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "toastAlert",
          value: function toastAlert(msg, index) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var toast;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.toastController.create({
                        message: msg,
                        duration: 2000
                      });

                    case 2:
                      toast = _context2.sent;
                      toast.present();
                      this.cart.splice(index, 1);
                      this.doTotalCalculation();

                    case 6:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }]);

        return CheckoutPage;
      }();

      CheckoutPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]
        }];
      };

      CheckoutPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-checkout',
        template: _raw_loader_checkout_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_checkout_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], CheckoutPage);
      /***/
    },

    /***/
    "pA2R":
    /*!*********************************************!*\
      !*** ./src/app/checkout/checkout.page.scss ***!
      \*********************************************/

    /*! exports provided: default */

    /***/
    function pA2R(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".empty-cart img {\n  display: block;\n  margin: 0 auto;\n  margin-top: 45%;\n}\n\n.text-muted {\n  color: #6c757d !important;\n}\n\n.no-gap {\n  padding: 0 !important;\n  margin: 0 !important;\n}\n\n.text-oflow-lg {\n  display: inline-block;\n}\n\n.cart-image {\n  height: 60px;\n  padding: 5px;\n}\n\n.x-small {\n  font-size: x-small !important;\n}\n\n.bottom-bar {\n  position: fixed;\n  width: 100%;\n  bottom: 0;\n  background-color: #ffffff;\n  z-index: 999;\n}\n\n.bottom-space {\n  padding: 35px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL2NoZWNrb3V0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBQUNGOztBQUVBO0VBQ0UseUJBQUE7QUFDRjs7QUFFQTtFQUNFLHFCQUFBO0VBQ0Esb0JBQUE7QUFDRjs7QUFFQTtFQUNFLHFCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxZQUFBO0VBQ0EsWUFBQTtBQUNGOztBQUVBO0VBQ0UsNkJBQUE7QUFDRjs7QUFFQTtFQUNFLGVBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtBQUNGOztBQUVBO0VBQ0UsYUFBQTtBQUNGIiwiZmlsZSI6ImNoZWNrb3V0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5lbXB0eS1jYXJ0IGltZyB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgbWFyZ2luOiAwIGF1dG87XHJcbiAgbWFyZ2luLXRvcDogNDUlO1xyXG59XHJcblxyXG4udGV4dC1tdXRlZCB7XHJcbiAgY29sb3I6ICM2Yzc1N2QgIWltcG9ydGFudDtcclxufVxyXG5cclxuLm5vLWdhcCB7XHJcbiAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xyXG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4udGV4dC1vZmxvdy1sZyB7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG59XHJcblxyXG4uY2FydC1pbWFnZSB7XHJcbiAgaGVpZ2h0OiA2MHB4O1xyXG4gIHBhZGRpbmc6IDVweDtcclxufVxyXG5cclxuLngtc21hbGwge1xyXG4gIGZvbnQtc2l6ZTogeC1zbWFsbCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYm90dG9tLWJhciB7XHJcbiAgcG9zaXRpb246IGZpeGVkO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGJvdHRvbTogMDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xyXG4gIHotaW5kZXg6IDk5OTtcclxufVxyXG5cclxuLmJvdHRvbS1zcGFjZSB7XHJcbiAgcGFkZGluZzogMzVweDtcclxufVxyXG4iXX0= */";
      /***/
    },

    /***/
    "v3IU":
    /*!*****************************************************!*\
      !*** ./src/app/checkout/checkout-routing.module.ts ***!
      \*****************************************************/

    /*! exports provided: CheckoutPageRoutingModule */

    /***/
    function v3IU(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CheckoutPageRoutingModule", function () {
        return CheckoutPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _checkout_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./checkout.page */
      "E2Rb");

      var routes = [{
        path: '',
        component: _checkout_page__WEBPACK_IMPORTED_MODULE_3__["CheckoutPage"]
      }];

      var CheckoutPageRoutingModule = function CheckoutPageRoutingModule() {
        _classCallCheck(this, CheckoutPageRoutingModule);
      };

      CheckoutPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], CheckoutPageRoutingModule);
      /***/
    }
  }]);
})();
//# sourceMappingURL=checkout-checkout-module-es5.js.map