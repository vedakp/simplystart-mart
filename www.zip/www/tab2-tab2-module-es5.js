(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab2-tab2-module"], {
    /***/
    "53MP":
    /*!******************************************!*\
      !*** ./src/app/home/tab2/tab2.module.ts ***!
      \******************************************/

    /*! exports provided: Tab2PageModule */

    /***/
    function MP(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Tab2PageModule", function () {
        return Tab2PageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _tab2_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./tab2.page */
      "afWa");
      /* harmony import */


      var _tab2_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./tab2-routing.module */
      "rwmv");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @ngx-translate/core */
      "sYmb");

      var Tab2PageModule = function Tab2PageModule() {
        _classCallCheck(this, Tab2PageModule);
      };

      Tab2PageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _tab2_routing_module__WEBPACK_IMPORTED_MODULE_6__["Tab2PageRoutingModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"]],
        declarations: [_tab2_page__WEBPACK_IMPORTED_MODULE_5__["Tab2Page"]]
      })], Tab2PageModule);
      /***/
    },

    /***/
    "IyYd":
    /*!******************************************!*\
      !*** ./src/app/home/tab2/tab2.page.scss ***!
      \******************************************/

    /*! exports provided: default */

    /***/
    function IyYd(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".empty-wish img {\n  display: block;\n  margin: 0 auto;\n  margin-top: 20%;\n  width: 70%;\n}\n\n.text-muted {\n  color: #6c757d !important;\n}\n\n.x-small {\n  font-size: x-small !important;\n}\n\n.no-gap {\n  padding: 0 !important;\n  margin: 0 !important;\n}\n\n.text-oflow-lg {\n  display: inline-block;\n}\n\nion-icon {\n  font-size: 24px;\n}\n\n.round-edge {\n  border-radius: 8px !important;\n  overflow: hidden;\n  box-shadow: 0px 1px 9px rgba(0, 0, 0, 0.15) !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3RhYjIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsY0FBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsVUFBQTtBQUNGOztBQUVBO0VBQ0UseUJBQUE7QUFDRjs7QUFFQTtFQUNFLDZCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxxQkFBQTtFQUNBLG9CQUFBO0FBQ0Y7O0FBRUE7RUFDRSxxQkFBQTtBQUNGOztBQUVBO0VBQ0UsZUFBQTtBQUNGOztBQUVBO0VBQ0UsNkJBQUE7RUFDQSxnQkFBQTtFQUNBLHNEQUFBO0FBQ0YiLCJmaWxlIjoidGFiMi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZW1wdHktd2lzaCBpbWcge1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG4gIG1hcmdpbi10b3A6IDIwJTtcclxuICB3aWR0aDogNzAlO1xyXG59XHJcblxyXG4udGV4dC1tdXRlZCB7XHJcbiAgY29sb3I6ICM2Yzc1N2QgIWltcG9ydGFudDtcclxufVxyXG5cclxuLngtc21hbGwge1xyXG4gIGZvbnQtc2l6ZTogeC1zbWFsbCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ubm8tZ2FwIHtcclxuICBwYWRkaW5nOiAwICFpbXBvcnRhbnQ7XHJcbiAgbWFyZ2luOiAwICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi50ZXh0LW9mbG93LWxnIHtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbn1cclxuXHJcbmlvbi1pY29uIHtcclxuICBmb250LXNpemU6IDI0cHg7XHJcbn1cclxuXHJcbi5yb3VuZC1lZGdlIHtcclxuICBib3JkZXItcmFkaXVzOiA4cHggIWltcG9ydGFudDtcclxuICBvdmVyZmxvdzogaGlkZGVuOyAgICBcclxuICBib3gtc2hhZG93OiAwcHggMXB4IDlweCByZ2JhKDAsIDAsIDAsIDAuMTUpICFpbXBvcnRhbnQ7XHJcbn0iXX0= */";
      /***/
    },

    /***/
    "V46e":
    /*!********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/tab2/tab2.page.html ***!
      \********************************************************************************/

    /*! exports provided: default */

    /***/
    function V46e(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\r\n    <ion-item>\r\n      <ion-label class=\"ion-padding\">\r\n        <h1>{{ 'My Wishlist' | translate }}</h1>\r\n      </ion-label>\r\n      <ion-icon\r\n        class=\"ion-text-right\"\r\n        slot=\"end\"\r\n        color=\"dark\"\r\n        name=\"bag-handle-outline\"\r\n      >\r\n      </ion-icon>\r\n    </ion-item>\r\n</ion-header>\r\n\r\n<ion-content [fullscreen]=\"true\" scroll=\"false\" no-padding>\r\n\r\n  <div class=\"cart ion-padding-top\" *ngIf=\"wishlist.length > 0\">\r\n    <ion-list>\r\n      <ion-item *ngFor=\"let item of wishlist; let i=index;\">\r\n        <ion-grid class=\"animate__animated animate__slideInUp animate__faster\">\r\n          <ion-row>\r\n            <ion-col size=\"3\" routerLink=\"/single-product-view\">\r\n              <img class=\"round-edge\" src=\"{{ item?.productImage }}\" />\r\n            </ion-col>\r\n            <ion-col size=\"6\" routerLink=\"/single-product-view\">\r\n              <h6 class=\"text-oflow-lg no-gap\">{{ item?.shortName }}</h6>\r\n              <p class=\"text-oflow-lg text-muted no-gap\">{{ item?.brand }}</p>\r\n            </ion-col>\r\n            <ion-col size=\"3\" class=\"ion-text-right\">\r\n              <p class=\"no-gap\">\r\n                <ion-icon\r\n                  class=\"ion-text-right text-muted\"\r\n                  (click)=\"removeFromWishlist(i)\"\r\n                  color=\"danger\"\r\n                  name=\"heart\"\r\n                ></ion-icon>\r\n              </p>\r\n              <small class=\"ion-text-uppercase no-gap ion-margin-top text-muted\"\r\n                >{{ item?.off }}% Off</small\r\n              >\r\n              <p class=\"ion-text-uppercase no-gap x-small text-muted\">\r\n                <del>{{ item?.regularPrice }}</del>\r\n              </p>\r\n              <h6 class=\"ion-text-right no-gap\">₹ {{ item?.salesPrice }}</h6>\r\n            </ion-col>\r\n          </ion-row>\r\n          <ion-row> </ion-row>\r\n        </ion-grid>\r\n      </ion-item>\r\n    </ion-list>\r\n  </div>\r\n\r\n  <div\r\n    class=\"empty-wish animate__animated animate__fadeIn animate__faster\"\r\n    *ngIf=\"wishlist.length == 0\"\r\n  >\r\n    <img src=\"../../../assets/empty-wishlist.png\" alt=\"\" />\r\n    <h4 class=\"text-muted ion-text-center\">{{ 'Wishlist is empty' | translate }}!</h4>\r\n    <br />\r\n    <div class=\"ion-text-center\">\r\n      <ion-button\r\n        color=\"primary\"\r\n        routerLink=\"/home\"\r\n        class=\"ion-text-uppercase\"\r\n        shape=\"round\"\r\n        >{{ 'Start Shopping' | translate }}</ion-button\r\n      >\r\n    </div>\r\n  </div>\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "afWa":
    /*!****************************************!*\
      !*** ./src/app/home/tab2/tab2.page.ts ***!
      \****************************************/

    /*! exports provided: Tab2Page */

    /***/
    function afWa(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Tab2Page", function () {
        return Tab2Page;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_tab2_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./tab2.page.html */
      "V46e");
      /* harmony import */


      var _tab2_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./tab2.page.scss */
      "IyYd");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");

      var Tab2Page = /*#__PURE__*/function () {
        function Tab2Page(toastController, alertController) {
          _classCallCheck(this, Tab2Page);

          this.toastController = toastController;
          this.alertController = alertController;
          this.wishlist = [{
            "product_id": 1,
            "productImage": "../../../assets/products/39ed8e8d-01b0-4d86-8cb0-305b4869bb48.__CR288,248,496,496_PT0_SX300_V1___.jpg",
            "productName": "Women Fashion Handbags Tote Bag Shoulder Bag Top Handle Satchel Purse",
            "brand": "Bagger IN",
            "shortName": "Women's Handbag",
            "off": 15,
            "productLongDescription": "A14 Bionic, the fastest chip in a smartphone. An edge-to-edge OLED display. Ceramic Shield with four times better drop performance. And Night mode on every camera. iPhone 12 has it all — in two perfect sizes.",
            "productShortDescription": "A14 Bionic, the fastest chip in a smartphone. An edge-to-edge OLED display.",
            "regularPrice": 980,
            "salesPrice": 850
          }, {
            "product_id": 2,
            "productImage": "../../../assets/products/b5b4e08c1b97e8ed0c403bebda20d789.jpg",
            "productName": "Halife Women's Long Sleeve Boat Neck Off Shoulder Blouse Tops",
            "brand": "Halife US",
            "off": 45,
            "shortName": "Women's Long Sleeve",
            "productLongDescription": "A14 Bionic rockets past every other smartphone chip. The Pro camera system takes low-light photography to the next level — with an even bigger jump on iPhone 12 Pro Max. And Ceramic Shield delivers four times better drop performance. Let’s see what this thing can do.",
            "productShortDescription": "A14 Bionic rockets past every other smartphone chip.",
            "regularPrice": 1200,
            "salesPrice": 999
          }];
        }

        _createClass(Tab2Page, [{
          key: "removeFromWishlist",
          value: function removeFromWishlist(i) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.alertController.create({
                        header: 'Do you want to remove this item from your wishlist?',
                        buttons: [{
                          text: 'Cancel',
                          role: 'cancel',
                          cssClass: 'secondary',
                          handler: function handler() {
                            console.log('Action cancelled');
                          }
                        }, {
                          text: 'Yes!',
                          handler: function handler() {
                            _this.toastAlert("Item removed from wishlist.", i);
                          }
                        }]
                      });

                    case 2:
                      alert = _context.sent;
                      _context.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "toastAlert",
          value: function toastAlert(msg, index) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var toast;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.toastController.create({
                        message: msg,
                        duration: 2000
                      });

                    case 2:
                      toast = _context2.sent;
                      toast.present();
                      this.wishlist.splice(index, 1);

                    case 5:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }]);

        return Tab2Page;
      }();

      Tab2Page.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]
        }];
      };

      Tab2Page = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-tab2',
        template: _raw_loader_tab2_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_tab2_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], Tab2Page);
      /***/
    },

    /***/
    "rwmv":
    /*!**************************************************!*\
      !*** ./src/app/home/tab2/tab2-routing.module.ts ***!
      \**************************************************/

    /*! exports provided: Tab2PageRoutingModule */

    /***/
    function rwmv(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Tab2PageRoutingModule", function () {
        return Tab2PageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _tab2_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./tab2.page */
      "afWa");

      var routes = [{
        path: '',
        component: _tab2_page__WEBPACK_IMPORTED_MODULE_3__["Tab2Page"]
      }];

      var Tab2PageRoutingModule = function Tab2PageRoutingModule() {
        _classCallCheck(this, Tab2PageRoutingModule);
      };

      Tab2PageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], Tab2PageRoutingModule);
      /***/
    }
  }]);
})();
//# sourceMappingURL=tab2-tab2-module-es5.js.map