(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["register-register-module"], {
    /***/
    "2t07":
    /*!*****************************************************!*\
      !*** ./src/app/register/register-routing.module.ts ***!
      \*****************************************************/

    /*! exports provided: RegisterPageRoutingModule */

    /***/
    function t07(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RegisterPageRoutingModule", function () {
        return RegisterPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _register_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./register.page */
      "b0Bx");

      var routes = [{
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_3__["RegisterPage"]
      }];

      var RegisterPageRoutingModule = function RegisterPageRoutingModule() {
        _classCallCheck(this, RegisterPageRoutingModule);
      };

      RegisterPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], RegisterPageRoutingModule);
      /***/
    },

    /***/
    "UgDh":
    /*!***********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.page.html ***!
      \***********************************************************************************/

    /*! exports provided: default */

    /***/
    function UgDh(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-content [fullscreen]=\"true\">\r\n  <!-- Nav Bar -->\r\n\r\n  <div class=\"top-nav\">\r\n    <form #registerform = \"ngForm\">\r\n    <ion-grid class=\"padding\">\r\n      <ion-row>\r\n        <ion-col class=\"animate__animated animate__fadeIn animate__faster\">\r\n          <ion-text color=\"dark\">\r\n            <h1 class=\"head\" color=\"dark\">{{ 'Welcome' | translate }}!</h1>\r\n            {{ 'Create a new account.' | translate }}\r\n          </ion-text>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n \r\n    <ion-grid\r\n      class=\"padding login-form animate__animated animate__slideInUp animate__faster\"\r\n    >\r\n      <ion-item>\r\n        <ion-input type=\"text\" name=\"username\" ngModel #uname=\"ngModel\" [(ngModel)] = username required minlength=\"6\" placeholder=\"{{ 'Username' | translate }}\"\r\n          ><ion-icon class=\"icon-padding\" name=\"at-outline\"></ion-icon\r\n        ></ion-input>\r\n      </ion-item>\r\n      <ion-col *ngIf=\"uname.touched && !uname.valid\">\r\n        <ion-text color=\"danger\">\r\n          <p *ngIf=\"uname.errors.required\">Please Enter Username</p>\r\n          <p *ngIf=\"uname.errors.minlength\">Username should be minimum of 6 character letter</p>\r\n        </ion-text>\r\n      </ion-col>\r\n      <ion-item>\r\n        <ion-input type=\"text\" name=\"email\" ngModel #uemail=\"ngModel\" [(ngModel)] = email required  placeholder=\"{{ 'Email' | translate }}\"\r\n          ><ion-icon class=\"icon-padding\" name=\"mail-outline\"></ion-icon\r\n        ></ion-input>\r\n      </ion-item>\r\n      <ion-col *ngIf=\"uemail.touched && !uemail.valid\">\r\n        <ion-text color=\"danger\">\r\n          <p>Please Enter Email Id</p>\r\n        </ion-text>\r\n      </ion-col>\r\n      <ion-item>\r\n        <ion-input type=\"password\" name=\"password\" ngModel #upass=\"ngModel\" [(ngModel)] = password required placeholder=\"{{ 'Password' | translate }}\"\r\n          ><ion-icon class=\"icon-padding\" name=\"lock-closed-outline\"></ion-icon\r\n        ></ion-input>\r\n      </ion-item>\r\n      <ion-col *ngIf=\"upass.touched && !upass.valid\">\r\n        <ion-text color=\"danger\">\r\n          <p>Please Enter Password</p>\r\n        </ion-text>\r\n      </ion-col>\r\n    </ion-grid>\r\n    <ion-button\r\n      color=\"tertiary\"\r\n      routerLink=\"/home\"\r\n      class=\"ion-text-capitalize ion-margin-top no-gap\"\r\n      size=\"large\"\r\n      expand=\"full\"\r\n      [disabled]=\"!registerform.valid\"\r\n      >{{ 'Signup' | translate }}</ion-button\r\n    >\r\n    </form>\r\n  </div>\r\n\r\n  <!-- <ion-grid class=\"ion-text-center\">\r\n    <ion-text class=\"ion-text-center padding text-muted\"\r\n      ><h6>{{ 'Or Continue with' | translate }}</h6></ion-text\r\n    >\r\n  </ion-grid> -->\r\n</ion-content>\r\n\r\n<!-- <div class=\"bottom-bar no-gap\">\r\n  <ion-row class=\"no-gap\">\r\n    <ion-grid size=\"6\" class=\"no-gap\">\r\n      <ion-button\r\n        color=\"secondary\"\r\n        routerLink=\"/home\"\r\n        class=\"ion-text-capitalize no-gap\"\r\n        size=\"large\"\r\n        expand=\"full\"\r\n      >\r\n      {{ 'Facebook' | translate }}</ion-button\r\n      >\r\n    </ion-grid>\r\n\r\n    <ion-grid size=\"6\" class=\"no-gap\">\r\n      <ion-button\r\n        color=\"danger\"\r\n        routerLink=\"/home\"\r\n        class=\"ion-text-capitalize no-gap\"\r\n        size=\"large\"\r\n        expand=\"full\"\r\n      >\r\n        {{ 'Google' | translate }}</ion-button\r\n      >\r\n    </ion-grid>\r\n  </ion-row>\r\n</div> -->\r\n";
      /***/
    },

    /***/
    "b0Bx":
    /*!*******************************************!*\
      !*** ./src/app/register/register.page.ts ***!
      \*******************************************/

    /*! exports provided: RegisterPage */

    /***/
    function b0Bx(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RegisterPage", function () {
        return RegisterPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_register_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./register.page.html */
      "UgDh");
      /* harmony import */


      var _register_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./register.page.scss */
      "x/mg");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var RegisterPage = /*#__PURE__*/function () {
        function RegisterPage() {
          _classCallCheck(this, RegisterPage);
        }

        _createClass(RegisterPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return RegisterPage;
      }();

      RegisterPage.ctorParameters = function () {
        return [];
      };

      RegisterPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-register',
        template: _raw_loader_register_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_register_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], RegisterPage);
      /***/
    },

    /***/
    "x/mg":
    /*!*********************************************!*\
      !*** ./src/app/register/register.page.scss ***!
      \*********************************************/

    /*! exports provided: default */

    /***/
    function xMg(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".head {\n  padding: 0 !important;\n  margin: 0 !important;\n  font-weight: 800;\n}\n\n.top-nav {\n  padding-top: 20vh !important;\n}\n\n.padding {\n  padding: 26px !important;\n}\n\n.text-muted {\n  color: #6c757d !important;\n}\n\n.login-form {\n  padding-top: 25px !important;\n}\n\n.icon-padding {\n  padding-right: 8px;\n}\n\n.no-gap {\n  padding: 0 !important;\n  margin: 0 !important;\n}\n\n.bottom-bar {\n  position: fixed;\n  width: 100%;\n  bottom: 0;\n  background-color: transparent;\n  z-index: 999;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3JlZ2lzdGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0VBQ0Esb0JBQUE7RUFDQSxnQkFBQTtBQUNGOztBQUVBO0VBQ0UsNEJBQUE7QUFDRjs7QUFFQTtFQUNFLHdCQUFBO0FBQ0Y7O0FBRUE7RUFDRSx5QkFBQTtBQUNGOztBQUVBO0VBQ0UsNEJBQUE7QUFDRjs7QUFFQTtFQUNFLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxxQkFBQTtFQUNBLG9CQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSw2QkFBQTtFQUNBLFlBQUE7QUFDRiIsImZpbGUiOiJyZWdpc3Rlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZCB7XHJcbiAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xyXG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xyXG4gIGZvbnQtd2VpZ2h0OiA4MDA7XHJcbn1cclxuXHJcbi50b3AtbmF2IHtcclxuICBwYWRkaW5nLXRvcDogMjB2aCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ucGFkZGluZyB7XHJcbiAgcGFkZGluZzogMjZweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4udGV4dC1tdXRlZCB7XHJcbiAgY29sb3I6ICM2Yzc1N2QgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmxvZ2luLWZvcm0ge1xyXG4gIHBhZGRpbmctdG9wOiAyNXB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5pY29uLXBhZGRpbmcge1xyXG4gIHBhZGRpbmctcmlnaHQ6IDhweDtcclxufVxyXG5cclxuLm5vLWdhcCB7XHJcbiAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xyXG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYm90dG9tLWJhciB7XHJcbiAgcG9zaXRpb246IGZpeGVkO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGJvdHRvbTogMDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICB6LWluZGV4OiA5OTk7XHJcbn1cclxuIl19 */";
      /***/
    },

    /***/
    "x5bZ":
    /*!*********************************************!*\
      !*** ./src/app/register/register.module.ts ***!
      \*********************************************/

    /*! exports provided: RegisterPageModule */

    /***/
    function x5bZ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RegisterPageModule", function () {
        return RegisterPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _register_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./register-routing.module */
      "2t07");
      /* harmony import */


      var _register_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./register.page */
      "b0Bx");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @ngx-translate/core */
      "sYmb");

      var RegisterPageModule = function RegisterPageModule() {
        _classCallCheck(this, RegisterPageModule);
      };

      RegisterPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _register_routing_module__WEBPACK_IMPORTED_MODULE_5__["RegisterPageRoutingModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"]],
        declarations: [_register_page__WEBPACK_IMPORTED_MODULE_6__["RegisterPage"]]
      })], RegisterPageModule);
      /***/
    }
  }]);
})();
//# sourceMappingURL=register-register-module-es5.js.map