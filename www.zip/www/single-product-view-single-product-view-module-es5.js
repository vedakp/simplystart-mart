(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["single-product-view-single-product-view-module"], {
    /***/
    "/qVa":
    /*!***************************************************************************!*\
      !*** ./src/app/single-product-view/single-product-view-routing.module.ts ***!
      \***************************************************************************/

    /*! exports provided: SingleProductViewPageRoutingModule */

    /***/
    function qVa(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SingleProductViewPageRoutingModule", function () {
        return SingleProductViewPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _single_product_view_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./single-product-view.page */
      "EAeQ");

      var routes = [{
        path: '',
        component: _single_product_view_page__WEBPACK_IMPORTED_MODULE_3__["SingleProductViewPage"]
      }];

      var SingleProductViewPageRoutingModule = function SingleProductViewPageRoutingModule() {
        _classCallCheck(this, SingleProductViewPageRoutingModule);
      };

      SingleProductViewPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], SingleProductViewPageRoutingModule);
      /***/
    },

    /***/
    "EAeQ":
    /*!*****************************************************************!*\
      !*** ./src/app/single-product-view/single-product-view.page.ts ***!
      \*****************************************************************/

    /*! exports provided: SingleProductViewPage */

    /***/
    function EAeQ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SingleProductViewPage", function () {
        return SingleProductViewPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_single_product_view_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./single-product-view.page.html */
      "io0E");
      /* harmony import */


      var _single_product_view_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./single-product-view.page.scss */
      "Twgg");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _services_commonfunction_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../services/commonfunction.service */
      "HifY");
      /* harmony import */


      var _services_woocommerce_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../services/woocommerce.service */
      "+GIV");

      var SingleProductViewPage = /*#__PURE__*/function () {
        function SingleProductViewPage(toastController, activatedRoute, wc, appComm) {
          _classCallCheck(this, SingleProductViewPage);

          this.toastController = toastController;
          this.activatedRoute = activatedRoute;
          this.wc = wc;
          this.appComm = appComm;
          this.pId = "";
          this.is_fav = false;
          this.currentProduct = [];
          this.relatedProducts = [{
            "product_id": 1,
            "productImage": "../../../assets/products/iphone-12-pro-blue-150x150.png",
            "productName": "Apple iPhone 12 32GB",
            "brand": "Apple",
            "shortName": "iPhone 12 32GB",
            "off": 45,
            "productLongDescription": "A14 Bionic, the fastest chip in a smartphone. An edge-to-edge OLED display. Ceramic Shield with four times better drop performance. And Night mode on every camera. iPhone 12 has it all — in two perfect sizes.",
            "productShortDescription": "A14 Bionic, the fastest chip in a smartphone. An edge-to-edge OLED display.",
            "regularPrice": 69000,
            "salesPrice": 69900
          }];
        }

        _createClass(SingleProductViewPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.activatedRoute.paramMap.subscribe(function (paramMap) {
              _this.pId = paramMap.get('id');

              _this.wc.getSingleProduct(_this.pId).then(function (productRes) {
                console.log("Product ", productRes);
                _this.currentProduct = [{
                  "product_id": productRes['id'],
                  "productImage": productRes['images'] && productRes['images'][0] && productRes['images'][0].src ? productRes['images'][0].src : '',
                  "productName": productRes['name'],
                  "brand": "Bagger IN",
                  "shortName": productRes['name'],
                  "off": parseInt((productRes['sale_price'] / productRes['regular_price'] * 100).toString()),
                  "productLongDescription": productRes['short_description'],
                  "productShortDescription": productRes['short_description'],
                  "regularPrice": productRes['regular_price'],
                  "salesPrice": productRes['sale_price']
                }, {
                  "images": productRes['images'].map(function (img) {
                    return img.src;
                  })
                }]; // this.getProductVariation();
              });
            });
          }
        }, {
          key: "getProductVariation",
          value: function getProductVariation() {
            this.wc.getProductVariation(this.pId).then(function (productsRes) {
              productsRes.forEach(function (product) {
                product.attributes.forEach(function (attr) {
                  if (attr.name == 'Color') {// this.colorsAvaliable.push(attr.option)
                  }

                  if (attr.name == 'Size') {// this.sizesAvaliable.push(attr.option)
                  }
                });
              });
            });
          }
        }, {
          key: "toastAlert",
          value: function toastAlert(msg) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var toast;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.toastController.create({
                        message: msg,
                        duration: 2000
                      });

                    case 2:
                      toast = _context.sent;
                      toast.present();

                    case 4:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "addFav",
          value: function addFav() {
            if (this.is_fav == false) {
              this.is_fav = true;
              this.toastAlert("Item added to wishlist.");
            } else {
              this.is_fav = false;
              this.toastAlert("Item removed from wishlist.");
            }
          }
        }]);

        return SingleProductViewPage;
      }();

      SingleProductViewPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"]
        }, {
          type: _services_woocommerce_service__WEBPACK_IMPORTED_MODULE_7__["WoocommerceService"]
        }, {
          type: _services_commonfunction_service__WEBPACK_IMPORTED_MODULE_6__["CommonfunctionService"]
        }];
      };

      SingleProductViewPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-single-product-view',
        template: _raw_loader_single_product_view_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_single_product_view_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], SingleProductViewPage);
      /***/
    },

    /***/
    "HifY":
    /*!****************************************************!*\
      !*** ./src/app/services/commonfunction.service.ts ***!
      \****************************************************/

    /*! exports provided: CommonfunctionService */

    /***/
    function HifY(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CommonfunctionService", function () {
        return CommonfunctionService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./constants */
      "/+cT");

      var CommonfunctionService = /*#__PURE__*/function () {
        function CommonfunctionService(toastController) {
          _classCallCheck(this, CommonfunctionService);

          this.toastController = toastController;
        }

        _createClass(CommonfunctionService, [{
          key: "validateEmail",
          value: function validateEmail(email) {
            return _constants__WEBPACK_IMPORTED_MODULE_3__["REGEX"].email.test(String(email).toLowerCase());
          }
        }, {
          key: "showToast",
          value: function showToast(message, showCancelbutton, position) {
            var duration = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 5000;
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var toastObj, toast;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      toastObj = {
                        message: message,
                        position: position,
                        duration: duration
                      };

                      if (showCancelbutton) {
                        toastObj['buttons'] = [{
                          text: 'Close',
                          role: 'cancel',
                          handler: function handler() {
                            console.log('Cancel clicked');
                          }
                        }];
                      }

                      _context2.next = 4;
                      return this.toastController.create(toastObj);

                    case 4:
                      toast = _context2.sent;
                      toast.present();

                    case 6:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "setLocalstorageItem",
          value: function setLocalstorageItem(key, value) {
            var _this2 = this;

            return new Promise(function (resolve, reject) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                return regeneratorRuntime.wrap(function _callee3$(_context3) {
                  while (1) {
                    switch (_context3.prev = _context3.next) {
                      case 0:
                        _context3.prev = 0;
                        _context3.next = 3;
                        return localStorage.setItem(key, value);

                      case 3:
                        resolve(true);
                        _context3.next = 9;
                        break;

                      case 6:
                        _context3.prev = 6;
                        _context3.t0 = _context3["catch"](0);
                        reject(_context3.t0);

                      case 9:
                      case "end":
                        return _context3.stop();
                    }
                  }
                }, _callee3, null, [[0, 6]]);
              }));
            });
          }
        }, {
          key: "getLocalstorageItem",
          value: function getLocalstorageItem(key) {
            var _this3 = this;

            return new Promise(function (resolve, reject) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this3, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
                var res;
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                  while (1) {
                    switch (_context4.prev = _context4.next) {
                      case 0:
                        _context4.prev = 0;
                        _context4.next = 3;
                        return localStorage.getItem(key);

                      case 3:
                        res = _context4.sent;
                        resolve(res);
                        _context4.next = 10;
                        break;

                      case 7:
                        _context4.prev = 7;
                        _context4.t0 = _context4["catch"](0);
                        reject(_context4.t0);

                      case 10:
                      case "end":
                        return _context4.stop();
                    }
                  }
                }, _callee4, null, [[0, 7]]);
              }));
            });
          }
        }, {
          key: "clearLocalstorage",
          value: function clearLocalstorage() {
            var _this4 = this;

            return new Promise(function (resolve, reject) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this4, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                return regeneratorRuntime.wrap(function _callee5$(_context5) {
                  while (1) {
                    switch (_context5.prev = _context5.next) {
                      case 0:
                        _context5.next = 2;
                        return localStorage.clear();

                      case 2:
                        resolve(true);

                      case 3:
                      case "end":
                        return _context5.stop();
                    }
                  }
                }, _callee5);
              }));
            });
          }
        }]);

        return CommonfunctionService;
      }();

      CommonfunctionService.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
        }];
      };

      CommonfunctionService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], CommonfunctionService);
      /***/
    },

    /***/
    "Twgg":
    /*!*******************************************************************!*\
      !*** ./src/app/single-product-view/single-product-view.page.scss ***!
      \*******************************************************************/

    /*! exports provided: default */

    /***/
    function Twgg(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".right-space {\n  margin-right: 12px;\n}\n\n.product-view {\n  width: 350px;\n  height: 350px;\n  border: 2px solid #f8f8f8;\n}\n\n.card-image {\n  pointer-events: none;\n}\n\n.no-gap {\n  padding: 0 !important;\n  margin: 0 !important;\n}\n\n.x-small {\n  font-size: x-small;\n}\n\n.small {\n  font-size: small;\n}\n\n.xx-small {\n  font-size: xx-small;\n}\n\n.text-muted {\n  color: #6c757d !important;\n}\n\n.bottom-bar {\n  position: fixed;\n  width: 100%;\n  bottom: 0;\n  background-color: #ffffff;\n  z-index: 999;\n}\n\n.top-bar {\n  position: fixed;\n  width: 100%;\n  top: 0;\n  background-color: transparent;\n  z-index: 999;\n}\n\n.bottom-bar-space {\n  padding-bottom: 80px;\n}\n\n.sm-cards {\n  width: 150px;\n  height: 240px;\n  border: 2px solid #f8f8f8;\n}\n\n.fav_icon {\n  font-size: 24px;\n  float: right;\n}\n\n.text-oflow-sm {\n  display: inline-block;\n  width: 135px;\n  white-space: nowrap;\n  overflow: hidden !important;\n  text-overflow: ellipsis;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NpbmdsZS1wcm9kdWN0LXZpZXcucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7QUFDRjs7QUFDQTtFQUNFLFlBQUE7RUFDQSxhQUFBO0VBQ0EseUJBQUE7QUFFRjs7QUFDQTtFQUNFLG9CQUFBO0FBRUY7O0FBQ0E7RUFDRSxxQkFBQTtFQUNBLG9CQUFBO0FBRUY7O0FBQ0E7RUFDRSxrQkFBQTtBQUVGOztBQUNBO0VBQ0UsZ0JBQUE7QUFFRjs7QUFDQTtFQUNFLG1CQUFBO0FBRUY7O0FBQ0E7RUFDRSx5QkFBQTtBQUVGOztBQUNBO0VBQ0UsZUFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0FBRUY7O0FBQ0E7RUFDRSxlQUFBO0VBQ0EsV0FBQTtFQUNBLE1BQUE7RUFDQSw2QkFBQTtFQUNBLFlBQUE7QUFFRjs7QUFDQTtFQUNFLG9CQUFBO0FBRUY7O0FBQ0E7RUFDRSxZQUFBO0VBQ0EsYUFBQTtFQUNBLHlCQUFBO0FBRUY7O0FBQ0E7RUFDRSxlQUFBO0VBQ0EsWUFBQTtBQUVGOztBQUNBO0VBQ0UscUJBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSwyQkFBQTtFQUNBLHVCQUFBO0FBRUYiLCJmaWxlIjoic2luZ2xlLXByb2R1Y3Qtdmlldy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucmlnaHQtc3BhY2Uge1xyXG4gIG1hcmdpbi1yaWdodDogMTJweDtcclxufVxyXG4ucHJvZHVjdC12aWV3IHtcclxuICB3aWR0aDogMzUwcHg7XHJcbiAgaGVpZ2h0OiAzNTBweDtcclxuICBib3JkZXI6IDJweCBzb2xpZCAjZjhmOGY4O1xyXG59XHJcblxyXG4uY2FyZC1pbWFnZSB7XHJcbiAgcG9pbnRlci1ldmVudHM6IG5vbmU7XHJcbn1cclxuXHJcbi5uby1nYXAge1xyXG4gIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcclxuICBtYXJnaW46IDAgIWltcG9ydGFudDtcclxufVxyXG5cclxuLngtc21hbGwge1xyXG4gIGZvbnQtc2l6ZTogeC1zbWFsbDtcclxufVxyXG5cclxuLnNtYWxsIHtcclxuICBmb250LXNpemU6IHNtYWxsO1xyXG59XHJcblxyXG4ueHgtc21hbGwge1xyXG4gIGZvbnQtc2l6ZTogeHgtc21hbGw7XHJcbn1cclxuXHJcbi50ZXh0LW11dGVkIHtcclxuICBjb2xvcjogIzZjNzU3ZCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYm90dG9tLWJhciB7XHJcbiAgcG9zaXRpb246IGZpeGVkO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGJvdHRvbTogMDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xyXG4gIHotaW5kZXg6IDk5OTtcclxufVxyXG5cclxuLnRvcC1iYXIge1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICB3aWR0aDogMTAwJTtcclxuICB0b3A6IDA7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgei1pbmRleDogOTk5O1xyXG59XHJcblxyXG4uYm90dG9tLWJhci1zcGFjZSB7XHJcbiAgcGFkZGluZy1ib3R0b206IDgwcHg7XHJcbn1cclxuXHJcbi5zbS1jYXJkcyB7XHJcbiAgd2lkdGg6IDE1MHB4O1xyXG4gIGhlaWdodDogMjQwcHg7XHJcbiAgYm9yZGVyOiAycHggc29saWQgI2Y4ZjhmODtcclxufVxyXG5cclxuLmZhdl9pY29ue1xyXG4gIGZvbnQtc2l6ZTogMjRweDtcclxuICBmbG9hdDogcmlnaHQ7XHJcbn1cclxuXHJcbi50ZXh0LW9mbG93LXNtIHtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgd2lkdGg6IDEzNXB4O1xyXG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgb3ZlcmZsb3c6IGhpZGRlbiAhaW1wb3J0YW50O1xyXG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xyXG59XHJcbiJdfQ== */";
      /***/
    },

    /***/
    "io0E":
    /*!*********************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/single-product-view/single-product-view.page.html ***!
      \*********************************************************************************************************/

    /*! exports provided: default */

    /***/
    function io0E(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-content [fullscreen]=\"true\">\r\n  <div class=\"top-bar animate__animated animate__fadeIn animate__faster\">\r\n    <ion-grid>\r\n      <ion-row>\r\n        <ion-col size=\"6\" class=\"ion-text-left ion-padding\">\r\n          <h1 class=\"no-gap\">\r\n            <ion-icon\r\n              routerLink=\"/home\"\r\n              color=\"dark\"\r\n              name=\"chevron-back-outline\"\r\n            ></ion-icon>\r\n          </h1>\r\n        </ion-col>\r\n        <ion-col size=\"6\" class=\"ion-text-right ion-padding\">\r\n          <h1 class=\"no-gap\">\r\n            <ion-icon\r\n              routerLink=\"/home/tabs/tab3\"\r\n              color=\"dark\"\r\n              name=\"bag-handle-outline\"\r\n            ></ion-icon>\r\n          </h1>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </div>\r\n\r\n  <!-- Large Banners Card -->\r\n  <ion-grid class=\"animate__animated animate__fadeIn animate__faster\">\r\n    <ion-slides *ngIf=\"currentProduct && currentProduct[1] && currentProduct[1].images\"\r\n      [options]=\"{ slidesPerView: 'auto', zoom: false, grabCursor: true }\"\r\n    >\r\n      <ion-slide\r\n        *ngFor=\"let image of currentProduct[1].images\"\r\n        class=\"product-view\"\r\n      >\r\n        <ion-col>\r\n          <ion-img class=\"card-image\" src=\"{{ image }}\"></ion-img>\r\n        </ion-col>\r\n      </ion-slide>\r\n    </ion-slides>\r\n  </ion-grid>\r\n\r\n  <div class=\"ion-padding animate__animated animate__fadeIn animate__faster\">\r\n    <ion-grid class=\"ion-padding\" class=\"bottom-bar-space\">\r\n      <ion-row>\r\n        <ion-col class=\"no-gap\">\r\n          <ion-text color=\"dark\">\r\n            <h4 class=\"no-gap\">{{ currentProduct[0]?.productName }}</h4>\r\n            <small class=\"ion-text-start text-muted no-gap\"\r\n              >{{ currentProduct[0]?.shortName }}</small\r\n            >\r\n          </ion-text>\r\n        </ion-col>\r\n      </ion-row>\r\n\r\n      <ion-row>\r\n        <ion-col class=\"no-gap\">\r\n          <!-- <ion-chip color=\"success\">\r\n            <ion-text class=\"xx-small\" color=\"success\"\r\n              >{{ 'Extra ₹3500 Off' | translate }}</ion-text\r\n            >\r\n          </ion-chip>\r\n\r\n          <ion-chip color=\"danger\">\r\n            <ion-text class=\"xx-small\" color=\"danger\"\r\n              >{{ 'EMI Starts from' | translate }} ₹451</ion-text\r\n            >\r\n          </ion-chip> -->\r\n\r\n            <ion-icon\r\n              class=\"fav_icon animate__animated animate__bounceIn animate__faster\"\r\n              *ngIf=\"!is_fav\"\r\n              (click)=\"addFav()\"\r\n              color=\"danger\"\r\n              name=\"heart-outline\"\r\n            ></ion-icon>\r\n\r\n            <ion-icon\r\n              class=\"fav_icon animate__animated animate__bounceIn animate__faster\"\r\n              *ngIf=\"is_fav\"\r\n              (click)=\"addFav()\"\r\n              color=\"danger\"\r\n              name=\"heart\"\r\n            ></ion-icon>\r\n\r\n        </ion-col>\r\n      </ion-row>\r\n\r\n      <ion-row>\r\n        <ion-col class=\"no-gap\">\r\n          <h4 class=\"ion-text-start no-gap\" color=\"dark\">\r\n            ₹{{ currentProduct[0]?.salesPrice }}\r\n            <small class=\"text-muted x-small\"\r\n              ><del>₹{{ currentProduct[0]?.regularPrice }}</del></small\r\n            >\r\n            <ion-text color=\"danger\"\r\n              ><b class=\"ion-float-right small\"\r\n                >{{ currentProduct[0]?.off }}% Off</b\r\n              ></ion-text\r\n            >\r\n          </h4>\r\n        </ion-col>\r\n      </ion-row>\r\n\r\n      <ion-row class=\"ion-padding-top\" *ngIf=\"currentProduct && currentProduct[0] && currentProduct[0].productLongDescription\">\r\n        <ion-col class=\"no-gap\">\r\n          <ion-text color=\"dark\">\r\n            <h6 class=\"no-gap ion-text-uppercase\">{{ 'Product Description' | translate }}</h6>\r\n            <small class=\"ion-text-start text-muted no-gap ion-text-justify\"\r\n              >{{ currentProduct[0]?.productLongDescription }}</small\r\n            >\r\n          </ion-text>\r\n        </ion-col>\r\n      </ion-row>\r\n\r\n      <!-- Card Title -->\r\n      <ion-row class=\"animate__animated animate__fadeIn animate__faster\">\r\n        <ion-col size=\"9\">\r\n          <ion-text color=\"dark\">\r\n            <h6 class=\"ion-text-uppercase\">{{ 'Related Products' | translate }}</h6>\r\n          </ion-text>\r\n        </ion-col>\r\n\r\n        <ion-col size=\"3\" class=\"ion-text-end\">\r\n          <ion-button\r\n            class=\"card-header-btn\"\r\n            color=\"primary\"\r\n            routerLink=\"/product-list\"\r\n            size=\"small\"\r\n            >{{ 'More' | translate }}</ion-button\r\n          >\r\n        </ion-col>\r\n      </ion-row>\r\n\r\n      <!-- Card Slides -->\r\n      <ion-slides\r\n        [options]=\"{ slidesPerView: 'auto', zoom: false, grabCursor: true }\"\r\n      >\r\n        <ion-slide\r\n          routerLink=\"/single-product-view\"\r\n          *ngFor=\"let mobile of relatedProducts\"\r\n          class=\"sm-cards\"\r\n        >\r\n          <ion-col>\r\n            <ion-img\r\n              class=\"card-image\"\r\n              src=\"{{ mobile?.productImage }}\"\r\n            ></ion-img>\r\n            <div class=\"ion-padding-top ion-padding-bottom\">\r\n              <h6 class=\"ion-text-start no-gap text-oflow-sm\">\r\n                {{ mobile?.shortName }}\r\n              </h6>\r\n              <small\r\n                class=\"ion-text-start no-gap text-oflow-sm text-muted x-small\"\r\n                >{{ mobile?.productName }}</small\r\n              >\r\n              <h6 class=\"ion-text-start small no-gap\" color=\"dark\">\r\n                ₹{{ mobile?.salesPrice }}\r\n\r\n                <small class=\"text-muted xx-small\"\r\n                  ><del>₹{{ mobile?.regularPrice }}</del></small\r\n                >\r\n                <ion-text color=\"danger\"\r\n                  ><b class=\"ion-float-right x-small\"\r\n                    >{{ mobile?.off }}% Off</b\r\n                  ></ion-text\r\n                >\r\n              </h6>\r\n            </div>\r\n          </ion-col>\r\n        </ion-slide>\r\n      </ion-slides>\r\n    </ion-grid>\r\n  </div>\r\n\r\n  <div class=\"bottom-bar animate__animated animate__slideInUp animate__faster\">\r\n    <ion-grid>\r\n      <ion-row>\r\n        <ion-col size=\"6\">\r\n          <ion-button\r\n            color=\"dark\"\r\n            routerLink=\"/home\"\r\n            class=\"ion-text-uppercase small\"\r\n            size=\"large\"\r\n            expand=\"block\"\r\n            >{{ 'Add to cart' | translate }}</ion-button\r\n          >\r\n        </ion-col>\r\n\r\n        <ion-col size=\"6\">\r\n          <ion-button\r\n            color=\"primary\"\r\n            routerLink=\"/home/tabs/tab3\"\r\n            class=\"ion-text-uppercase small\"\r\n            size=\"large\"\r\n            expand=\"block\"\r\n            >{{ 'Buy now' | translate }}</ion-button\r\n          >\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </div>\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "upyQ":
    /*!*******************************************************************!*\
      !*** ./src/app/single-product-view/single-product-view.module.ts ***!
      \*******************************************************************/

    /*! exports provided: SingleProductViewPageModule */

    /***/
    function upyQ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SingleProductViewPageModule", function () {
        return SingleProductViewPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _single_product_view_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./single-product-view-routing.module */
      "/qVa");
      /* harmony import */


      var _single_product_view_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./single-product-view.page */
      "EAeQ");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @ngx-translate/core */
      "sYmb");

      var SingleProductViewPageModule = function SingleProductViewPageModule() {
        _classCallCheck(this, SingleProductViewPageModule);
      };

      SingleProductViewPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _single_product_view_routing_module__WEBPACK_IMPORTED_MODULE_5__["SingleProductViewPageRoutingModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"]],
        declarations: [_single_product_view_page__WEBPACK_IMPORTED_MODULE_6__["SingleProductViewPage"]]
      })], SingleProductViewPageModule);
      /***/
    }
  }]);
})();
//# sourceMappingURL=single-product-view-single-product-view-module-es5.js.map