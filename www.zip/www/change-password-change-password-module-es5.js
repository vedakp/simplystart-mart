(function () {
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["change-password-change-password-module"], {
    /***/
    "/ujS":
    /*!*********************************************************!*\
      !*** ./src/app/change-password/change-password.page.ts ***!
      \*********************************************************/

    /*! exports provided: ChangePasswordPage */

    /***/
    function ujS(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ChangePasswordPage", function () {
        return ChangePasswordPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_change_password_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./change-password.page.html */
      "YQwf");
      /* harmony import */


      var _change_password_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./change-password.page.scss */
      "Gr1o");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var ChangePasswordPage = /*#__PURE__*/function () {
        function ChangePasswordPage() {
          _classCallCheck(this, ChangePasswordPage);
        }

        _createClass(ChangePasswordPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return ChangePasswordPage;
      }();

      ChangePasswordPage.ctorParameters = function () {
        return [];
      };

      ChangePasswordPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-change-password',
        template: _raw_loader_change_password_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_change_password_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ChangePasswordPage);
      /***/
    },

    /***/
    "6+Cs":
    /*!*******************************************************************!*\
      !*** ./src/app/change-password/change-password-routing.module.ts ***!
      \*******************************************************************/

    /*! exports provided: ChangePasswordPageRoutingModule */

    /***/
    function Cs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ChangePasswordPageRoutingModule", function () {
        return ChangePasswordPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _change_password_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./change-password.page */
      "/ujS");

      var routes = [{
        path: '',
        component: _change_password_page__WEBPACK_IMPORTED_MODULE_3__["ChangePasswordPage"]
      }];

      var ChangePasswordPageRoutingModule = function ChangePasswordPageRoutingModule() {
        _classCallCheck(this, ChangePasswordPageRoutingModule);
      };

      ChangePasswordPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], ChangePasswordPageRoutingModule);
      /***/
    },

    /***/
    "8oFo":
    /*!***********************************************************!*\
      !*** ./src/app/change-password/change-password.module.ts ***!
      \***********************************************************/

    /*! exports provided: ChangePasswordPageModule */

    /***/
    function oFo(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ChangePasswordPageModule", function () {
        return ChangePasswordPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _change_password_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./change-password-routing.module */
      "6+Cs");
      /* harmony import */


      var _change_password_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./change-password.page */
      "/ujS");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @ngx-translate/core */
      "sYmb");

      var ChangePasswordPageModule = function ChangePasswordPageModule() {
        _classCallCheck(this, ChangePasswordPageModule);
      };

      ChangePasswordPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _change_password_routing_module__WEBPACK_IMPORTED_MODULE_5__["ChangePasswordPageRoutingModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"]],
        declarations: [_change_password_page__WEBPACK_IMPORTED_MODULE_6__["ChangePasswordPage"]]
      })], ChangePasswordPageModule);
      /***/
    },

    /***/
    "Gr1o":
    /*!***********************************************************!*\
      !*** ./src/app/change-password/change-password.page.scss ***!
      \***********************************************************/

    /*! exports provided: default */

    /***/
    function Gr1o(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".head {\n  padding: 0 !important;\n  margin: 0 !important;\n  font-weight: 800;\n}\n\n.top-nav {\n  padding-top: 20vh !important;\n}\n\n.padding {\n  padding: 26px !important;\n}\n\n.text-muted {\n  color: #6c757d !important;\n}\n\n.login-form {\n  padding-top: 25px !important;\n}\n\n.icon-padding {\n  padding-right: 8px;\n}\n\n.no-gap {\n  padding: 0 !important;\n  margin: 0 !important;\n}\n\n.medium {\n  font-size: medium !important;\n}\n\n.bottom-bar {\n  position: fixed;\n  width: 100%;\n  bottom: 0;\n  background-color: transparent;\n  z-index: 999;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL2NoYW5nZS1wYXNzd29yZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxxQkFBQTtFQUNBLG9CQUFBO0VBQ0EsZ0JBQUE7QUFDRjs7QUFFQTtFQUNFLDRCQUFBO0FBQ0Y7O0FBRUE7RUFDRSx3QkFBQTtBQUNGOztBQUVBO0VBQ0UseUJBQUE7QUFDRjs7QUFFQTtFQUNFLDRCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UscUJBQUE7RUFDQSxvQkFBQTtBQUNGOztBQUVBO0VBQ0UsNEJBQUE7QUFDRjs7QUFFQTtFQUNFLGVBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLDZCQUFBO0VBQ0EsWUFBQTtBQUNGIiwiZmlsZSI6ImNoYW5nZS1wYXNzd29yZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZCB7XHJcbiAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xyXG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xyXG4gIGZvbnQtd2VpZ2h0OiA4MDA7XHJcbn1cclxuXHJcbi50b3AtbmF2IHtcclxuICBwYWRkaW5nLXRvcDogMjB2aCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ucGFkZGluZyB7XHJcbiAgcGFkZGluZzogMjZweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4udGV4dC1tdXRlZCB7XHJcbiAgY29sb3I6ICM2Yzc1N2QgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmxvZ2luLWZvcm0ge1xyXG4gIHBhZGRpbmctdG9wOiAyNXB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5pY29uLXBhZGRpbmcge1xyXG4gIHBhZGRpbmctcmlnaHQ6IDhweDtcclxufVxyXG5cclxuLm5vLWdhcCB7XHJcbiAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xyXG4gIG1hcmdpbjogMCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ubWVkaXVtIHtcclxuICBmb250LXNpemU6IG1lZGl1bSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYm90dG9tLWJhciB7XHJcbiAgcG9zaXRpb246IGZpeGVkO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGJvdHRvbTogMDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICB6LWluZGV4OiA5OTk7XHJcbn1cclxuIl19 */";
      /***/
    },

    /***/
    "YQwf":
    /*!*************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/change-password/change-password.page.html ***!
      \*************************************************************************************************/

    /*! exports provided: default */

    /***/
    function YQwf(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-content [fullscreen]=\"true\">\r\n  <!-- Nav Bar -->\r\n\r\n  <div class=\"top-nav\">\r\n    <ion-grid class=\"padding\">\r\n      <ion-row>\r\n        <ion-col\r\n          size=\"12\"\r\n          class=\"animate__animated animate__fadeIn animate__faster\"\r\n        >\r\n          <ion-text color=\"primary\">\r\n            <h1 class=\"head\" color=\"primary\">\r\n              {{ 'New Credentials' | translate }}\r\n            </h1>\r\n          </ion-text>\r\n        </ion-col>\r\n\r\n        <ion-col\r\n          size=\"12\"\r\n          class=\"animate__animated animate__fadeIn animate__faster\"\r\n        >\r\n          <ion-text color=\"dark\">\r\n            <h6 class=\"head\" color=\"dark\">\r\n              {{ 'Your identity has been verified!' | translate }}\r\n            </h6>\r\n            <h6 class=\"head\" color=\"dark\">\r\n              {{ 'Set your new password' | translate }}\r\n            </h6>\r\n          </ion-text>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n\r\n    <ion-grid class=\"padding\">\r\n      <ion-item>\r\n        <ion-input\r\n          type=\"password\"\r\n          placeholder=\"{{ 'New Password' | translate }}\"\r\n          ><ion-icon class=\"icon-padding\" name=\"lock-closed-outline\"></ion-icon\r\n        ></ion-input>\r\n      </ion-item>\r\n\r\n      <ion-item>\r\n        <ion-input\r\n          type=\"password\"\r\n          placeholder=\"{{ 'Confirm Password' | translate }}\"\r\n          ><ion-icon class=\"icon-padding\" name=\"lock-closed-outline\"></ion-icon\r\n        ></ion-input>\r\n      </ion-item>\r\n\r\n      <ion-button\r\n        color=\"primary\"\r\n        routerLink=\"/password-success\"\r\n        size=\"large\"\r\n        class=\"ion-text-capitalize medium ion-margin-top\"\r\n        expand=\"full\"\r\n        >{{ 'Update' | translate }}</ion-button\r\n      >\r\n    </ion-grid>\r\n  </div>\r\n</ion-content>\r\n\r\n<div class=\"bottom-bar\">\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col size=\"6\">\r\n        <ion-button\r\n          expand=\"full\"\r\n          size=\"default\"\r\n          routerLink=\"/password-success\"\r\n          color=\"primary\"\r\n          >{{ 'Success' | translate }}</ion-button\r\n        >\r\n      </ion-col>\r\n\r\n      <ion-col size=\"6\">\r\n        <ion-button\r\n          expand=\"full\"\r\n          size=\"default\"\r\n          routerLink=\"/password-failed\"\r\n          color=\"tertiary\"\r\n          >{{ 'Failed' | translate }}</ion-button\r\n        >\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</div>\r\n";
      /***/
    }
  }]);
})();
//# sourceMappingURL=change-password-change-password-module-es5.js.map