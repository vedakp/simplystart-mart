(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["privacy-policy-privacy-policy-module"], {
    /***/
    "Grmv":
    /*!***********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/privacy-policy/privacy-policy.page.html ***!
      \***********************************************************************************************/

    /*! exports provided: default */

    /***/
    function Grmv(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title class=\"ion-text-capitalize\"\r\n      >{{ 'Privacy policy' | translate }}</ion-title\r\n    >\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content class=\"ion-padding\">\r\n  <ion-col>\r\n    <div class=\"ion-text-wrap\">\r\n      <h2 class=\"heading\">Content 1</h2>\r\n      <p>\r\n        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ac vehicula\r\n        lorem.\r\n      </p>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam at autem\r\n        neque dolores distinctio aut?\r\n      </p>\r\n    </div>\r\n  </ion-col>\r\n\r\n  <ion-col>\r\n    <div class=\"ion-text-wrap\">\r\n      <h2 class=\"heading\">Content 2</h2>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid atque\r\n        ipsa, molestias debitis similique excepturi est minus nostrum saepe id!\r\n      </p>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum suscipit\r\n        architecto labore, inventore deserunt illo nesciunt quos consectetur non\r\n        voluptatem rem ab officiis! Doloremque a enim amet voluptas, mollitia\r\n        expedita?\r\n      </p>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis\r\n        eveniet sint totam perspiciatis molestias eum quae odit. Amet dolorum\r\n        quam ipsam ad doloremque veniam, reiciendis eveniet, provident\r\n        perspiciatis, libero nobis.\r\n      </p>\r\n    </div>\r\n  </ion-col>\r\n\r\n  <ion-col>\r\n    <div class=\"ion-text-wrap\">\r\n      <h2 class=\"heading\">Content 3</h2>\r\n      <p>\r\n        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ac vehicula\r\n        lorem.\r\n      </p>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam at autem\r\n        neque dolores distinctio aut?\r\n      </p>\r\n    </div>\r\n  </ion-col>\r\n\r\n  <ion-col>\r\n    <div class=\"ion-text-wrap\">\r\n      <h2 class=\"heading\">Content 4</h2>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid atque\r\n        ipsa, molestias debitis similique excepturi est minus nostrum saepe id!\r\n      </p>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum suscipit\r\n        architecto labore, inventore deserunt illo nesciunt quos consectetur non\r\n        voluptatem rem ab officiis! Doloremque a enim amet voluptas, mollitia\r\n        expedita?\r\n      </p>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis\r\n        eveniet sint totam perspiciatis molestias eum quae odit. Amet dolorum\r\n        quam ipsam ad doloremque veniam, reiciendis eveniet, provident\r\n        perspiciatis, libero nobis.\r\n      </p>\r\n    </div>\r\n  </ion-col>\r\n\r\n  <ion-col>\r\n    <div class=\"ion-text-wrap\">\r\n      <h2 class=\"heading\">Content 5</h2>\r\n      <p>\r\n        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ac vehicula\r\n        lorem.\r\n      </p>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam at autem\r\n        neque dolores distinctio aut?\r\n      </p>\r\n    </div>\r\n  </ion-col>\r\n\r\n  <ion-col>\r\n    <div class=\"ion-text-wrap\">\r\n      <h2 class=\"heading\">Content 6</h2>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid atque\r\n        ipsa, molestias debitis similique excepturi est minus nostrum saepe id!\r\n      </p>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum suscipit\r\n        architecto labore, inventore deserunt illo nesciunt quos consectetur non\r\n        voluptatem rem ab officiis! Doloremque a enim amet voluptas, mollitia\r\n        expedita?\r\n      </p>\r\n      <p>\r\n        Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis\r\n        eveniet sint totam perspiciatis molestias eum quae odit. Amet dolorum\r\n        quam ipsam ad doloremque veniam, reiciendis eveniet, provident\r\n        perspiciatis, libero nobis.\r\n      </p>\r\n    </div>\r\n  </ion-col>\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "TOq4":
    /*!*********************************************************!*\
      !*** ./src/app/privacy-policy/privacy-policy.module.ts ***!
      \*********************************************************/

    /*! exports provided: PrivacyPolicyPageModule */

    /***/
    function TOq4(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PrivacyPolicyPageModule", function () {
        return PrivacyPolicyPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _privacy_policy_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./privacy-policy-routing.module */
      "yO/6");
      /* harmony import */


      var _privacy_policy_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./privacy-policy.page */
      "qTUc");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @ngx-translate/core */
      "sYmb");

      var PrivacyPolicyPageModule = function PrivacyPolicyPageModule() {
        _classCallCheck(this, PrivacyPolicyPageModule);
      };

      PrivacyPolicyPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _privacy_policy_routing_module__WEBPACK_IMPORTED_MODULE_5__["PrivacyPolicyPageRoutingModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"]],
        declarations: [_privacy_policy_page__WEBPACK_IMPORTED_MODULE_6__["PrivacyPolicyPage"]]
      })], PrivacyPolicyPageModule);
      /***/
    },

    /***/
    "qTUc":
    /*!*******************************************************!*\
      !*** ./src/app/privacy-policy/privacy-policy.page.ts ***!
      \*******************************************************/

    /*! exports provided: PrivacyPolicyPage */

    /***/
    function qTUc(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PrivacyPolicyPage", function () {
        return PrivacyPolicyPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_privacy_policy_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./privacy-policy.page.html */
      "Grmv");
      /* harmony import */


      var _privacy_policy_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./privacy-policy.page.scss */
      "wyFE");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var PrivacyPolicyPage = /*#__PURE__*/function () {
        function PrivacyPolicyPage() {
          _classCallCheck(this, PrivacyPolicyPage);
        }

        _createClass(PrivacyPolicyPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return PrivacyPolicyPage;
      }();

      PrivacyPolicyPage.ctorParameters = function () {
        return [];
      };

      PrivacyPolicyPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-privacy-policy',
        template: _raw_loader_privacy_policy_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_privacy_policy_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PrivacyPolicyPage);
      /***/
    },

    /***/
    "wyFE":
    /*!*********************************************************!*\
      !*** ./src/app/privacy-policy/privacy-policy.page.scss ***!
      \*********************************************************/

    /*! exports provided: default */

    /***/
    function wyFE(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".bottom-bar {\n  position: fixed;\n  width: 100%;\n  bottom: 0;\n  background-color: transparent;\n  z-index: 999;\n}\n\n.heading {\n  color: #42e695;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3ByaXZhY3ktcG9saWN5LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLDZCQUFBO0VBQ0EsWUFBQTtBQUNGOztBQUVBO0VBQ0UsY0FBQTtBQUNGIiwiZmlsZSI6InByaXZhY3ktcG9saWN5LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ib3R0b20tYmFyIHtcclxuICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgYm90dG9tOiAwO1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gIHotaW5kZXg6IDk5OTtcclxufVxyXG5cclxuLmhlYWRpbmcge1xyXG4gIGNvbG9yOiAjNDJlNjk1O1xyXG59XHJcbiJdfQ== */";
      /***/
    },

    /***/
    "yO/6":
    /*!*****************************************************************!*\
      !*** ./src/app/privacy-policy/privacy-policy-routing.module.ts ***!
      \*****************************************************************/

    /*! exports provided: PrivacyPolicyPageRoutingModule */

    /***/
    function yO6(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PrivacyPolicyPageRoutingModule", function () {
        return PrivacyPolicyPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _privacy_policy_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./privacy-policy.page */
      "qTUc");

      var routes = [{
        path: '',
        component: _privacy_policy_page__WEBPACK_IMPORTED_MODULE_3__["PrivacyPolicyPage"]
      }];

      var PrivacyPolicyPageRoutingModule = function PrivacyPolicyPageRoutingModule() {
        _classCallCheck(this, PrivacyPolicyPageRoutingModule);
      };

      PrivacyPolicyPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], PrivacyPolicyPageRoutingModule);
      /***/
    }
  }]);
})();
//# sourceMappingURL=privacy-policy-privacy-policy-module-es5.js.map