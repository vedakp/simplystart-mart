(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["account-settings-account-settings-module"],{

/***/ "Adv9":
/*!***********************************************************!*\
  !*** ./src/app/account-settings/account-settings.page.ts ***!
  \***********************************************************/
/*! exports provided: AccountSettingsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccountSettingsPage", function() { return AccountSettingsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_account_settings_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./account-settings.page.html */ "HwpE");
/* harmony import */ var _account_settings_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./account-settings.page.scss */ "SNH0");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let AccountSettingsPage = class AccountSettingsPage {
    constructor() {
        this.enablePush = true;
    }
    ngOnInit() {
    }
};
AccountSettingsPage.ctorParameters = () => [];
AccountSettingsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-account-settings',
        template: _raw_loader_account_settings_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_account_settings_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], AccountSettingsPage);



/***/ }),

/***/ "HwpE":
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/account-settings/account-settings.page.html ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>{{ 'Account Settings' | translate }}</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-list>\r\n    <ion-item class=\"animate__animated animate__slideInUp animate__faster\">\r\n      <ion-label>{{ 'App Push Notifications' | translate }}</ion-label>\r\n      <ion-toggle [(ngModel)]=\"enablePush\"></ion-toggle>\r\n    </ion-item>\r\n\r\n    <ion-item class=\"animate__animated animate__slideInUp animate__faster\" routerLink=\"/terms-and-conditions\">\r\n      <ion-label>{{ 'Terms and conditions' | translate }}</ion-label>\r\n    </ion-item>\r\n\r\n    <ion-item class=\"animate__animated animate__slideInUp animate__faster\" routerLink=\"/privacy-policy\">\r\n      <ion-label>{{ 'Privacy policy' | translate }}</ion-label>\r\n    </ion-item>\r\n\r\n    <ion-item class=\"animate__animated animate__slideInUp animate__faster\" routerLink=\"/refund-policy\">\r\n      <ion-label>{{ 'Refund policy' | translate }}</ion-label>\r\n    </ion-item>\r\n\r\n    <ion-item class=\"animate__animated animate__slideInUp animate__faster\" routerLink=\"/about\">\r\n      <ion-label>{{ 'About' | translate }}</ion-label>\r\n    </ion-item>\r\n  </ion-list>\r\n</ion-content>\r\n\r\n<div class=\"bottom-bar\">\r\n  <ion-grid>\r\n    <ion-button size=\"large\" expand=\"full\" color=\"danger\">{{ 'Delete my account' | translate }}</ion-button>\r\n  </ion-grid>\r\n</div>\r\n");

/***/ }),

/***/ "SNH0":
/*!*************************************************************!*\
  !*** ./src/app/account-settings/account-settings.page.scss ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".bottom-bar {\n  position: fixed;\n  width: 100%;\n  bottom: 0;\n  background-color: transparent;\n  z-index: 999;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL2FjY291bnQtc2V0dGluZ3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZUFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsNkJBQUE7RUFDQSxZQUFBO0FBQ0YiLCJmaWxlIjoiYWNjb3VudC1zZXR0aW5ncy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYm90dG9tLWJhciB7XHJcbiAgcG9zaXRpb246IGZpeGVkO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGJvdHRvbTogMDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICB6LWluZGV4OiA5OTk7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ "ktQK":
/*!*************************************************************!*\
  !*** ./src/app/account-settings/account-settings.module.ts ***!
  \*************************************************************/
/*! exports provided: AccountSettingsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccountSettingsPageModule", function() { return AccountSettingsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _account_settings_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./account-settings-routing.module */ "mWxe");
/* harmony import */ var _account_settings_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./account-settings.page */ "Adv9");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");








let AccountSettingsPageModule = class AccountSettingsPageModule {
};
AccountSettingsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _account_settings_routing_module__WEBPACK_IMPORTED_MODULE_5__["AccountSettingsPageRoutingModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"]
        ],
        declarations: [_account_settings_page__WEBPACK_IMPORTED_MODULE_6__["AccountSettingsPage"]]
    })
], AccountSettingsPageModule);



/***/ }),

/***/ "mWxe":
/*!*********************************************************************!*\
  !*** ./src/app/account-settings/account-settings-routing.module.ts ***!
  \*********************************************************************/
/*! exports provided: AccountSettingsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccountSettingsPageRoutingModule", function() { return AccountSettingsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _account_settings_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./account-settings.page */ "Adv9");




const routes = [
    {
        path: '',
        component: _account_settings_page__WEBPACK_IMPORTED_MODULE_3__["AccountSettingsPage"]
    }
];
let AccountSettingsPageRoutingModule = class AccountSettingsPageRoutingModule {
};
AccountSettingsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AccountSettingsPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=account-settings-account-settings-module-es2015.js.map